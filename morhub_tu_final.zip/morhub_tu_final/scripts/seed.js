// Loads the prototype's sample hospital, departments, doctors and demo accounts.
// Runs only on an empty database (no hospitals yet).  Usage: npm run seed
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('../backend/config/database');

const DEMO_PASSWORD = 'Demo@1234';
const DEPTS = [
  ['ortho','ศัลยกรรมกระดูก','Orthopedics','bone'], ['med','อายุรกรรม','Internal Medicine','stethoscope'],
  ['surg','ศัลยกรรมทั่วไป','General Surgery','scissors'], ['ped','กุมารเวช','Pediatrics','smile'],
  ['ob','สูติ-นรีเวช','Obstetrics & Gynecology','heart'], ['ent','หู คอ จมูก','ENT','ear'],
  ['eye','จักษุ','Ophthalmology','eye'], ['psy','จิตเวช','Psychiatry','brain']
];
// [title, name, dept, room, years, weekdays, sessions, capacity]
const DOCS = [
  ['นพ.','ธนา วงศ์สว่าง','med','อาคาร A ชั้น 3 ห้อง 304',12,[1,2,4],[['08:00','12:00'],['13:00','16:00']],3],
  ['พญ.','ปรียา ศรีสุข','med','อาคาร A ชั้น 3 ห้อง 306',9,[1,3,5],[['09:00','12:00']],2],
  ['นพ.','กิตติ รัตนา','ortho','อาคาร B ชั้น 2 ห้อง 201',15,[2,3,5],[['13:00','17:00']],2],
  ['พญ.','มัลลิกา ใจดี','ped','อาคาร C ชั้น 1 ห้อง 105',7,[1,2,3,4,5],[['08:00','12:00'],['13:00','16:00']],4],
  ['นพ.','ศุภชัย พงษ์ไพร','ent','อาคาร B ชั้น 3 ห้อง 310',10,[2,4],[['09:00','12:00'],['13:00','15:00']],2],
  ['พญ.','วริษา แก้วมณี','ob','อาคาร C ชั้น 2 ห้อง 214',11,[1,3,5],[['08:30','12:00']],3],
  ['นพ.','อนุชา ภูพิงค์','med','อาคารหลัก ชั้น 2 ห้อง 21',14,[1,2,3,4,5],[['08:00','12:00']],3],
  ['พญ.','สุนิสา ล้านนา','ped','อาคารเด็ก ชั้น 1 ห้อง 3',8,[1,3,5],[['09:00','12:00'],['13:00','15:30']],3],
  ['นพ.','ชัยวัฒน์ ดอยสุเทพ','ortho','อาคารหลัก ชั้น 3 ห้อง 32',16,[2,4,6],[['08:00','12:00']],2],
  ['พญ.','เพ็ญศรี นิมมาน','eye','อาคารหลัก ชั้น 1 ห้อง 12',6,[1,4],[['13:00','16:00']],2],
  ['นพ.','วีระพงษ์ อีสานดี','surg','อาคาร 1 ชั้น 2 ห้อง 5',18,[1,2,3,4,5],[['08:00','12:00']],2],
  ['พญ.','กนกวรรณ ขอนแก่น','med','อาคาร 1 ชั้น 1 ห้อง 8',10,[2,4,6],[['08:00','12:00'],['13:00','16:00']],3],
  ['นพ.','ธีรพล สายธาร','psy','อาคาร 2 ชั้น 2 ห้อง 4',9,[3,5],[['13:00','17:00']],1],
  ['พญ.','ณิชา อันดามัน','ob','อาคาร A ชั้น 2 ห้อง 9',12,[1,2,4],[['09:00','12:00']],2],
  ['นพ.','ปกรณ์ ทะเลใส','ent','อาคาร A ชั้น 3 ห้อง 14',11,[3,5,6],[['10:00','15:00']],2],
  ['พญ.','รัชนีกร เกาะงาม','eye','อาคาร B ชั้น 1 ห้อง 2',7,[1,2,3],[['08:30','12:00']],2]
];
// [role, name, email, phone, status, extra]
const ACCOUNTS = [
  ['admin','ผู้ดูแลระบบ MorHub TU','admin@morhubtu.co.th','02-999-0000','active'],
  ['staff','สมศักดิ์ ช่างเทค','tech@morhubtu.co.th','02-926-0001','active',{ unit: 'เวชระเบียน' }],
  ['staff','อรุณี วงศ์ล้านนา','tech2@morhubtu.co.th','02-926-0002','active',{ unit: 'เวชระเบียน' }],
  ['staff','ปรีชา สายสยาม','tech3@morhubtu.co.th','02-926-0003','active',{ unit: 'IT' }],
  ['staff','ศิริพร ใหม่เมือง','siriporn@morhubtu.co.th','02-926-0005','pending',{ unit: 'คลินิกเด็ก' }],
  ['patient','สมชาย ใจดี','somchai@mail.com','081-234-5678','active',{ dob: '1990-05-14', allergy: 'Penicillin' }],
  ['patient','วิภา สุขสันต์','wipa@mail.com','089-111-2222','active',{ dob: '1985-11-02' }],
  ['patient','ประเสริฐ มั่นคง','prasert@mail.com','086-333-4444','active',{ dob: '1972-03-21' }],
  ['patient','นภัสสร แสงทอง','napat@mail.com','082-555-6666','active',{ dob: '1998-08-30', allergy: 'อาหารทะเล' }],
  ['patient','อดิศร เจริญสุข','adisorn@mail.com','091-777-8888','active',{ dob: '1965-01-09' }]
];

(async () => {
  const connection = await db.getConnection();
  try {
    const [[{ n }]] = await connection.execute('SELECT COUNT(*) AS n FROM hospitals');
    if (n) { console.log('Database already has data; seed skipped.'); return; }
    await connection.beginTransaction();
    const [h] = await connection.execute(
      'INSERT INTO hospitals (hospital_name,province,address,phone,opening_hours) VALUES (?,?,?,?,?)',
      ['โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ','ปทุมธานี','95 หมู่ 7 ถ.พหลโยธิน ต.คลองหนึ่ง อ.คลองหลวง ปทุมธานี 12120','02-926-9999','ผู้ป่วยนอก จ-ศ 08:00-16:00']
    );
    const deptId = {};
    for (const [code, th, en, icon] of DEPTS) {
      const [r] = await connection.execute('INSERT INTO departments (dept_code,dept_name_th,dept_name_en,icon) VALUES (?,?,?,?)', [code, th, en, icon]);
      deptId[code] = r.insertId;
    }
    for (const [title, name, dept, room, years, weekdays, sessions, cap] of DOCS) {
      const [r] = await connection.execute(
        'INSERT INTO doctors (hospital_id,department_id,title,full_name,room,experience_years,slot_capacity) VALUES (?,?,?,?,?,?,?)',
        [h.insertId, deptId[dept], title, name, room, years, cap]
      );
      for (const w of weekdays) for (const [s, e] of sessions) {
        await connection.execute('INSERT INTO doctor_schedules (doctor_id,weekday,start_time,end_time) VALUES (?,?,?,?)', [r.insertId, w, s, e]);
      }
    }
    const hash = await bcrypt.hash(DEMO_PASSWORD, 12);
    for (const [role, name, email, phone, status, extra = {}] of ACCOUNTS) {
      const [r] = await connection.execute(
        'INSERT INTO accounts (role,full_name,email,password_hash,phone,status) VALUES (?,?,?,?,?,?)', [role, name, email, hash, phone, status]
      );
      if (role === 'staff') await connection.execute('INSERT INTO staff (staff_id,hospital_id,work_unit) VALUES (?,?,?)', [r.insertId, h.insertId, extra.unit || null]);
      if (role === 'patient') {
        await connection.execute('INSERT INTO patients (patient_id,hn,date_of_birth,allergies) VALUES (?,?,?,?)',
          [r.insertId, `HN ${100000 + r.insertId}`, extra.dob || null, extra.allergy || null]);
      }
    }
    await connection.commit();
    console.log(`Seeded 1 hospital, ${DEPTS.length} departments, ${DOCS.length} doctors, ${ACCOUNTS.length} accounts.`);
    console.log(`Demo password for every account: ${DEMO_PASSWORD}  (admin@morhubtu.co.th, tech@morhubtu.co.th, somchai@mail.com ...)`);
  } catch (err) {
    await connection.rollback();
    console.error('Seed failed:', err.message);
    process.exitCode = 1;
  } finally { connection.release(); await db.end(); }
})();
