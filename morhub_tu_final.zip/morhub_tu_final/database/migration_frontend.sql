-- MorHub TU additive migration: columns used by the web frontend.
-- Run after morhub_tu_schema.sql and migration_features.sql. Does NOT drop anything.
USE morhub_tu;

-- Doctor profile page: photo, short headline, education (Thai + English)
ALTER TABLE doctors
  ADD COLUMN photo        MEDIUMTEXT   NULL,
  ADD COLUMN headline     VARCHAR(150) NULL,
  ADD COLUMN education_th TEXT         NULL,
  ADD COLUMN education_en TEXT         NULL;

-- Profile photos (stored as small JPEG data URLs, resized in the browser)
ALTER TABLE accounts  ADD COLUMN photo MEDIUMTEXT NULL;
ALTER TABLE hospitals ADD COLUMN photo MEDIUMTEXT NULL;

-- Report attachments are sent from the browser as data URLs
ALTER TABLE report_files
  MODIFY COLUMN file_path VARCHAR(500) NULL,
  ADD COLUMN data_url LONGTEXT NULL;

-- Admin "nudge" flag on overdue booking requests
ALTER TABLE appointments ADD COLUMN nudged BOOLEAN NOT NULL DEFAULT FALSE;
