-- MorHub TU additive migration: the admin is the middle step between patient and hospital.
-- Run after the other migrations. Does NOT drop any table or data.
USE morhub_tu;

-- Where an appointment is waiting for the admin:
--   'request' : patient's booking request, waiting for the admin to forward it to the hospital
--   'reply'   : hospital's answer (confirm / propose / decline), waiting for the admin to release it to the patient
--   'visit'   : patient confirmed they came to the visit, waiting for the admin to forward it to the hospital
--   NULL      : nothing waiting for the admin
ALTER TABLE appointments ADD COLUMN admin_gate ENUM('request','reply','visit') NULL;
-- When the patient confirmed they came; the hospital sends results and medicine only after this
ALTER TABLE appointments ADD COLUMN visited_at DATETIME NULL;

-- Reports (diagnosis + medicine) reach the patient only after the admin approves them
ALTER TABLE medical_reports ADD COLUMN admin_ok BOOLEAN NOT NULL DEFAULT FALSE;
UPDATE medical_reports SET admin_ok = TRUE;   -- reports that already exist stay visible

-- The server sends status notifications itself (after the admin step);
-- this trigger from "new v1.sql" would message the patient directly and twice.
DROP TRIGGER IF EXISTS trg_appt_after_status_update;
