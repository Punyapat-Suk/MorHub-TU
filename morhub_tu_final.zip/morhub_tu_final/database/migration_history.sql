-- MorHub TU additive migration: "clear history" per account.
-- Clearing only hides items from that account's own lists; no appointment, report or complaint is deleted.
USE morhub_tu;

CREATE TABLE IF NOT EXISTS history_clears (
  account_id  INT UNSIGNED NOT NULL,
  kind        ENUM('notifications','appointments','tickets') NOT NULL,
  cleared_at  DATETIME     NOT NULL,                 -- items finished up to this moment are hidden
  PRIMARY KEY (account_id, kind),
  CONSTRAINT fk_history_clears_account FOREIGN KEY (account_id) REFERENCES accounts(account_id) ON DELETE CASCADE
) ENGINE=InnoDB;
