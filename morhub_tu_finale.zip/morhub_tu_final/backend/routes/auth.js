const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');
const { asyncHandler, httpError, checkPhoto } = require('../utils/http');
const { authenticate } = require('../middleware/auth');
const { notify } = require('../services/notify');

const WALKIN = '%@walkin.morhub.local';
const digitsOf = s => String(s || '').replace(/\D/g, '');

// role: 'patient' (default) or 'staff' — a staff sign-up waits for admin approval.
router.post('/register', asyncHandler(async (req, res) => {
  const { full_name, email, password, phone, hn, date_of_birth, gender, allergies, work_unit } = req.body;
  const role = req.body.role === 'staff' ? 'staff' : 'patient';
  if (!full_name || !email || !password || !phone) throw httpError(400, 'กรอกข้อมูลให้ครบทุกช่อง', 'Please fill in every field');
  if (!/^\S+@\S+\.\S+$/.test(email)) throw httpError(400, 'รูปแบบอีเมลไม่ถูกต้อง', 'Invalid email format');
  if (String(password).length < 8) throw httpError(400, 'รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร', 'Password must be at least 8 characters');
  const name = String(full_name).trim(), mail = String(email).trim().toLowerCase(), hash = await bcrypt.hash(password, 12);
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    let accountId;
    // A patient booked earlier by staff as a walk-in claims that record by registering with the same phone.
    const [walkin] = role === 'patient' && digitsOf(phone).length >= 9 ? await connection.execute(
      `SELECT account_id FROM accounts WHERE role='patient' AND email LIKE ? AND REGEXP_REPLACE(phone,'[^0-9]','')=? LIMIT 1 FOR UPDATE`,
      [WALKIN, digitsOf(phone)]
    ) : [[]];
    if (walkin.length) {
      accountId = walkin[0].account_id;
      await connection.execute('UPDATE accounts SET full_name=?, email=?, password_hash=? WHERE account_id=?', [name, mail, hash, accountId]);
    } else {
      const [result] = await connection.execute(
        `INSERT INTO accounts (role, full_name, email, password_hash, phone, status) VALUES (?, ?, ?, ?, ?, ?)`,
        [role, name, mail, hash, phone, role === 'staff' ? 'pending' : 'active']
      );
      accountId = result.insertId;
      if (role === 'staff') {
        await connection.execute('INSERT INTO staff (staff_id, hospital_id, work_unit) VALUES (?, ?, ?)', [accountId, req.body.hospital_id || 1, work_unit || null]);
        await notify('admin', `${name} ขอสร้างบัญชีเจ้าหน้าที่`, 'accts', null, connection);
      } else {
        await connection.execute(
          `INSERT INTO patients (patient_id, hn, date_of_birth, gender, allergies) VALUES (?, ?, ?, ?, ?)`,
          [accountId, hn || `HN ${100000 + accountId}`, date_of_birth || null, gender || null, allergies || null]
        );
      }
    }
    await connection.commit();
    res.status(201).json(role === 'staff'
      ? { success: true, pending: true, message: 'ส่งคำขอสร้างบัญชีเจ้าหน้าที่แล้ว รอผู้ดูแลระบบอนุมัติ', message_en: 'Staff account request sent. Please wait for administrator approval', account_id: accountId }
      : { success: true, message: 'สมัครสมาชิกสำเร็จ', message_en: 'Registration successful', account_id: accountId });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

// Log in with email, or with the phone number on the account
router.post('/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) throw httpError(400, 'กรุณาระบุอีเมลและรหัสผ่าน', 'Please provide email and password');
  const login = String(email).trim().toLowerCase();
  const [rows] = login.includes('@')
    ? await db.execute(`SELECT account_id, role, full_name, password_hash, status FROM accounts WHERE email = ? LIMIT 1`, [login])
    : await db.execute(
      `SELECT account_id, role, full_name, password_hash, status FROM accounts
       WHERE ? <> '' AND REGEXP_REPLACE(phone,'[^0-9]','') = ? AND email NOT LIKE ? LIMIT 1`, [digitsOf(login), digitsOf(login), WALKIN]);
  const account = rows[0];
  if (!account || !(await bcrypt.compare(password, account.password_hash))) throw httpError(401, 'อีเมล/เบอร์โทร หรือรหัสผ่านไม่ถูกต้อง', 'Incorrect email/phone or password');
  if (account.status === 'pending') throw httpError(403, 'บัญชีนี้รอผู้ดูแลระบบอนุมัติ เมื่ออนุมัติแล้วจึงจะเข้าสู่ระบบได้', 'This account is awaiting administrator approval. You can log in once approved');
  if (account.status !== 'active') throw httpError(403, 'บัญชีนี้ถูกระงับ กรุณาติดต่อผู้ดูแลระบบ', 'This account is suspended. Please contact the administrator');
  const token = jwt.sign(
    { account_id: account.account_id, role: account.role, full_name: account.full_name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );
  res.json({ success: true, token });
}));

router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const [rows] = await db.execute(
    `SELECT a.account_id, a.role, a.full_name, a.email, a.phone, a.status, a.must_change_pw, a.photo, a.created_at,
            s.hospital_id, s.work_unit, p.hn, p.date_of_birth, p.gender, p.allergies
     FROM accounts a LEFT JOIN staff s ON s.staff_id=a.account_id LEFT JOIN patients p ON p.patient_id=a.account_id
     WHERE a.account_id = ?`, [req.user.account_id]
  );
  if (!rows.length) throw httpError(404, 'ไม่พบบัญชี', 'Account not found');
  if (rows[0].status !== 'active') throw httpError(403, 'บัญชีนี้ถูกระงับ กรุณาติดต่อผู้ดูแลระบบ', 'This account is suspended. Please contact the administrator');
  res.json({ success: true, user: { ...rows[0], act_by: req.user.act_by || null } });
}));

// Edit own profile. Email, HN and hospital are not editable here.
router.patch('/me', authenticate, asyncHandler(async (req, res) => {
  const { full_name, phone, photo, date_of_birth, allergies, work_unit } = req.body;
  if (full_name !== undefined && !String(full_name).trim()) throw httpError(400, 'กรุณากรอกชื่อ', 'Please enter a name');
  checkPhoto(photo);
  const id = req.user.account_id;
  if (full_name !== undefined || phone !== undefined || photo !== undefined) {
    await db.execute('UPDATE accounts SET full_name=COALESCE(?,full_name), phone=COALESCE(?,phone), photo=IF(?,?,photo) WHERE account_id=?',
      [full_name === undefined ? null : String(full_name).trim(), phone ?? null, photo !== undefined, photo || null, id]);
  }
  if (req.user.role === 'patient' && (date_of_birth !== undefined || allergies !== undefined)) {
    await db.execute('UPDATE patients SET date_of_birth=IF(?,?,date_of_birth), allergies=IF(?,?,allergies) WHERE patient_id=?',
      [date_of_birth !== undefined, date_of_birth || null, allergies !== undefined, allergies || null, id]);
  }
  if (req.user.role === 'staff' && work_unit !== undefined) await db.execute('UPDATE staff SET work_unit=? WHERE staff_id=?', [work_unit || null, id]);
  res.json({ success: true, message: 'บันทึกแล้ว', message_en: 'Saved' });
}));

router.patch('/change-password', authenticate, asyncHandler(async (req, res) => {
  if (req.user.act_by) throw httpError(403, 'ขณะใช้งานแทนผู้อื่น เปลี่ยนรหัสผ่านไม่ได้', 'Cannot change the password while acting as another user');
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password || String(new_password).length < 8) throw httpError(400, 'กรุณาระบุรหัสผ่านเดิมและรหัสผ่านใหม่อย่างน้อย 8 ตัวอักษร', 'Please provide current password and a new password of at least 8 characters');
  const [rows] = await db.execute('SELECT password_hash FROM accounts WHERE account_id = ?', [req.user.account_id]);
  if (!rows.length || !(await bcrypt.compare(current_password, rows[0].password_hash))) throw httpError(400, 'รหัสผ่านเดิมไม่ถูกต้อง', 'Current password is incorrect');
  await db.execute('UPDATE accounts SET password_hash = ?, must_change_pw = FALSE WHERE account_id = ?', [await bcrypt.hash(new_password, 12), req.user.account_id]);
  await db.execute(`INSERT INTO audit_logs (event_type, actor_account_id, target_account_id) VALUES ('pw_changed', ?, ?)`, [req.user.account_id, req.user.account_id]);
  res.json({ success: true, message: 'เปลี่ยนรหัสผ่านสำเร็จ', message_en: 'Password changed successfully' });
}));
module.exports = router;
