const hhmm = t => String(t).slice(0, 5);
const router = require('express').Router();
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate, allowRoles } = require('../middleware/auth');
const { notify, staffHospital } = require('../services/notify');

const WALKIN_DOMAIN = '@walkin.morhub.local';
const fmtTh = (date, time) => `${date} ${String(time).slice(0, 5)}`;

// Public: how many seats are taken per doctor/date/time (no personal data).
// A proposed appointment also holds the slot it was offered.
router.get('/slots', asyncHandler(async (req, res) => {
  const [rows] = await db.execute(
    `SELECT doctor_id, appt_date AS date, TIME_FORMAT(appt_time,'%H:%i') AS time, COUNT(*) AS used FROM (
       SELECT doctor_id, appt_date, appt_time FROM appointments
        WHERE status <> 'cancelled' AND appt_date >= CURDATE() - INTERVAL 1 DAY
       UNION ALL
       SELECT p.new_doctor_id, p.new_date, p.new_time FROM reschedule_proposals p
         JOIN appointments a ON a.appointment_id=p.appointment_id
        WHERE p.response='waiting' AND a.status='proposed' AND p.new_date >= CURDATE() - INTERVAL 1 DAY
     ) x GROUP BY doctor_id, appt_date, appt_time`
  );
  res.json({ success: true, data: rows });
}));

router.use(authenticate);

// Loads an appointment and checks the caller may manage it (staff: same hospital).
async function loadAppt(req, id, connection = db, lock = false) {
  const [rows] = await connection.execute(
    `SELECT a.*, TIME_FORMAT(a.appt_time,'%H:%i') AS hhmm, d.hospital_id, d.title, d.full_name AS doctor_name
     FROM appointments a JOIN doctors d ON d.doctor_id=a.doctor_id WHERE a.appointment_id=?${lock ? ' FOR UPDATE' : ''}`, [id]
  );
  if (!rows.length) throw httpError(404, 'ไม่พบนัดหมาย', 'Appointment not found');
  const appt = rows[0];
  if (req.user.role === 'patient' && appt.patient_id !== req.user.account_id) throw httpError(403, 'ไม่มีสิทธิ์จัดการนัดนี้', 'You are not allowed to manage this appointment');
  if (req.user.role === 'staff' && Number(await staffHospital(req.user.account_id, connection)) !== Number(appt.hospital_id)) {
    throw httpError(403, 'ไม่มีสิทธิ์จัดการนัดนี้', 'You are not allowed to manage this appointment');
  }
  // The hospital only sees a request after the admin forwards it
  if (req.user.role === 'staff' && appt.admin_gate === 'request') throw httpError(404, 'ไม่พบนัดหมาย', 'Appointment not found');
  return appt;
}
const doctorOf = async (connection, id) => (await connection.execute('SELECT title, full_name FROM doctors WHERE doctor_id=?', [id]))[0][0];
async function seatsLeft(connection, doctorId, date, time) {
  const [[{ cap }]] = await connection.execute('SELECT slot_capacity AS cap FROM doctors WHERE doctor_id=?', [doctorId]);
  const [[{ used }]] = await connection.execute(
    `SELECT (SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND appt_date=? AND appt_time=? AND status<>'cancelled')
          + (SELECT COUNT(*) FROM reschedule_proposals p JOIN appointments a ON a.appointment_id=p.appointment_id
              WHERE p.new_doctor_id=? AND p.new_date=? AND p.new_time=? AND p.response='waiting' AND a.status='proposed') AS used`,
    [doctorId, date, time, doctorId, date, time]
  );
  return cap - used;
}
async function noshow90(connection, patientId) {
  const [[{ n }]] = await connection.execute(
    `SELECT COUNT(*) AS n FROM appointments WHERE patient_id=? AND status='noshow' AND appt_date >= CURDATE() - INTERVAL 90 DAY`, [patientId]
  );
  return n;
}
async function hasClash(connection, patientId, date, time) {
  const [rows] = await connection.execute(
    `SELECT 1 FROM appointments WHERE patient_id=? AND appt_date=? AND appt_time=? AND status IN ('pending','upcoming') LIMIT 1`,
    [patientId, date, time]
  );
  return rows.length > 0;
}

router.get('/', asyncHandler(async (req, res) => {
  let sql = `SELECT a.appointment_id, a.patient_id, a.doctor_id, a.appt_date, TIME_FORMAT(a.appt_time,'%H:%i') AS appt_time,
                    a.symptom_note, a.status, a.is_follow_up, a.follow_up_of, a.cancelled_by, a.cancel_reason, a.nudged, a.admin_gate, a.visited_at,
                    a.confirmed_by, UNIX_TIMESTAMP(a.created_at)*1000 AS created_ms, UNIX_TIMESTAMP(a.updated_at)*1000 AS updated_ms,
                    d.hospital_id, ac.full_name AS patient_name, ac.phone AS patient_phone, ac.email AS patient_email,
                    ac.status AS patient_status, p.hn, p.date_of_birth, p.allergies,
                    rp.new_doctor_id, rp.new_date, TIME_FORMAT(rp.new_time,'%H:%i') AS new_time, rp.reason AS proposal_reason,
                    UNIX_TIMESTAMP(rp.proposed_at)*1000 AS proposed_ms, pa.full_name AS proposed_by_name,
                    EXISTS (SELECT 1 FROM reschedule_proposals x WHERE x.appointment_id=a.appointment_id AND x.response='accepted') AS changed
             FROM appointments a JOIN doctors d ON d.doctor_id=a.doctor_id
             JOIN patients p ON p.patient_id=a.patient_id JOIN accounts ac ON ac.account_id=a.patient_id
             LEFT JOIN reschedule_proposals rp ON rp.appointment_id=a.appointment_id AND rp.response='waiting'
             LEFT JOIN accounts pa ON pa.account_id=rp.proposed_by`;
  const params = [];
  if (req.user.role === 'patient') { sql += ' WHERE a.patient_id=?'; params.push(req.user.account_id); }
  else if (req.user.role === 'staff') {
    const hospitalId = await staffHospital(req.user.account_id);
    if (!hospitalId) throw httpError(403, 'ไม่พบข้อมูลเจ้าหน้าที่', 'Staff record not found');
    sql += ` WHERE d.hospital_id=? AND (a.admin_gate IS NULL OR a.admin_gate<>'request')`; params.push(hospitalId);
  }
  sql += ' ORDER BY a.appt_date DESC, a.appt_time DESC LIMIT 2000';
  const [rows] = await db.execute(sql, params);
  rows.forEach(r => { if (String(r.patient_email).endsWith(WALKIN_DOMAIN)) r.patient_email = ''; });
  // Until the admin releases the hospital's answer, the patient still sees a pending request
  if (req.user.role === 'patient') rows.filter(r => r.admin_gate === 'reply').forEach(r => Object.assign(r, {
    status: 'pending', admin_gate: null, cancelled_by: null, cancel_reason: null, confirmed_by: null,
    new_doctor_id: null, new_date: null, new_time: null, proposal_reason: null, proposed_ms: null, proposed_by_name: null
  }));
  res.json({ success: true, data: rows });
}));

// Patient sends a booking request
router.post('/', allowRoles('patient'), asyncHandler(async (req, res) => {
  const { doctor_id, appt_date, appt_time, symptom_note, is_follow_up, follow_up_of } = req.body;
  if (!doctor_id || !appt_date || !appt_time) throw httpError(400, 'กรุณาระบุแพทย์ วันที่ และเวลา', 'Please provide doctor, date and time');
  if (!String(symptom_note || '').trim()) throw httpError(400, 'กรุณาระบุอาการหรือเหตุผลที่มาพบ', 'Please describe your symptoms or reason for visit');
  if (new Date(`${appt_date}T${hhmm(appt_time)}:00`) < new Date()) throw httpError(400, 'ไม่สามารถจองวันเวลาที่ผ่านมาแล้ว', 'Cannot book a date/time in the past');
  if (await noshow90(db, req.user.account_id) >= 3) throw httpError(403, 'จองไม่ได้ชั่วคราว เพราะพลาดนัดครบ 3 ครั้งใน 90 วัน กรุณาติดต่อโรงพยาบาล', 'Booking is temporarily unavailable due to 3 missed appointments in 90 days. Please contact the hospital');
  if (await hasClash(db, req.user.account_id, appt_date, appt_time)) throw httpError(409, 'คุณมีนัดอื่นในวันและเวลาเดียวกันแล้ว', 'You already have another appointment at that time');
  const [result] = await db.execute(
    `INSERT INTO appointments (patient_id, doctor_id, appt_date, appt_time, symptom_note, is_follow_up, follow_up_of, admin_gate)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'request')`,
    [req.user.account_id, doctor_id, appt_date, appt_time, String(symptom_note).trim(), Boolean(is_follow_up), follow_up_of || null]
  );
  const d = await doctorOf(db, doctor_id);
  await notify('admin', `คำขอจองใหม่จาก ${req.user.full_name} · ${d.title}${d.full_name} ${fmtTh(appt_date, appt_time)} · รอส่งต่อให้โรงพยาบาล`, 'requests', result.insertId);
  res.status(201).json({ success: true, message: 'ส่งคำขอนัดหมายแล้ว รอแอดมินตรวจสอบ', message_en: 'Appointment request submitted. Waiting for admin review', appointment_id: result.insertId, status: 'pending' });
}));

// Staff books on behalf of a patient (found by HN/phone, or registered as a walk-in). Confirmed immediately.
router.post('/staff-book', allowRoles('staff'), asyncHandler(async (req, res) => {
  const { doctor_id, appt_date, appt_time, symptom_note, name, phone, hn, dob, allergies } = req.body;
  const digits = String(phone || '').replace(/\D/g, ''), hnDigits = String(hn || '').replace(/\D/g, '');
  if (!doctor_id || !appt_date || !appt_time) throw httpError(400, 'กรุณาระบุแพทย์ วันที่ และเวลา', 'Please provide doctor, date and time');
  if (String(name || '').trim().length < 2 || digits.length < 9) throw httpError(400, 'กรอกชื่อและเบอร์โทรผู้ป่วย', 'Enter the patient name and phone number');
  if (!String(symptom_note || '').trim()) throw httpError(400, 'กรุณาระบุอาการหรือเหตุผลที่มาพบ', 'Please describe the symptoms or reason for visit');
  const hospitalId = await staffHospital(req.user.account_id);
  const [[d]] = await db.execute('SELECT hospital_id, title, full_name FROM doctors WHERE doctor_id=?', [doctor_id]);
  if (!d || Number(d.hospital_id) !== Number(hospitalId)) throw httpError(403, 'ไม่มีสิทธิ์จัดการแพทย์นี้', 'You cannot manage this doctor');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [found] = await connection.execute(
      `SELECT p.patient_id, ac.email FROM patients p JOIN accounts ac ON ac.account_id=p.patient_id
       WHERE (? <> '' AND REGEXP_REPLACE(p.hn,'[^0-9]','')=?) OR REGEXP_REPLACE(ac.phone,'[^0-9]','')=? LIMIT 1`,
      [hnDigits, hnDigits, digits]
    );
    let patientId;
    if (found.length) {
      patientId = found[0].patient_id;
      if (await noshow90(connection, patientId) >= 3) throw httpError(403, 'ผู้ป่วยรายนี้พลาดนัดครบ 3 ครั้งใน 90 วัน จองไม่ได้ชั่วคราว', 'This patient has missed 3 appointments in the last 90 days and cannot book for now');
      if (await hasClash(connection, patientId, appt_date, appt_time)) throw httpError(409, 'ผู้ป่วยมีนัดอื่นในวันและเวลาเดียวกันแล้ว', 'The patient already has another appointment at the same date and time');
      await connection.execute(
        'UPDATE patients SET allergies=COALESCE(allergies,?), date_of_birth=COALESCE(date_of_birth,?) WHERE patient_id=?',
        [allergies || null, dob || null, patientId]
      );
    } else {
      // Walk-in: an account nobody can log in to until the patient registers with the same phone
      const [acc] = await connection.execute(
        `INSERT INTO accounts (role,full_name,email,password_hash,phone,status) VALUES ('patient',?,?,?,?,'active')`,
        [String(name).trim(), `walkin-${crypto.randomUUID()}${WALKIN_DOMAIN}`, await bcrypt.hash(crypto.randomBytes(24).toString('hex'), 10), phone]
      );
      patientId = acc.insertId;
      await connection.execute('INSERT INTO patients (patient_id,hn,date_of_birth,allergies) VALUES (?,?,?,?)',
        [patientId, `HN ${100000 + patientId}`, dob || null, allergies || null]);
    }
    const [result] = await connection.execute(
      `INSERT INTO appointments (patient_id,doctor_id,appt_date,appt_time,symptom_note,status,confirmed_by,confirmed_at)
       VALUES (?,?,?,?,?,'upcoming',?,NOW())`,
      [patientId, doctor_id, appt_date, appt_time, String(symptom_note).trim(), req.user.account_id]
    );
    if (found.length && !String(found[0].email).endsWith(WALKIN_DOMAIN)) {
      await notify({ account: patientId }, `นัดหมายของคุณกับ ${d.title}${d.full_name} ${fmtTh(appt_date, appt_time)} ได้รับการยืนยันแล้ว (จองโดยเจ้าหน้าที่)`, 'appts', result.insertId, connection);
    }
    await connection.commit();
    res.status(201).json({ success: true, message: 'จองนัดให้ผู้ป่วยแล้ว นัดได้รับการยืนยัน', message_en: 'Appointment booked for the patient and confirmed', appointment_id: result.insertId, patient_id: patientId });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

router.patch('/:id/cancel', asyncHandler(async (req, res) => {
  const { reason } = req.body;
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const appt = await loadAppt(req, req.params.id, connection, true);
    const byPatient = req.user.role === 'patient', byStaff = req.user.role === 'staff';
    // A decline the admin has not released yet still looks pending to the patient, so they may cancel it
    const unreleasedDecline = byPatient && appt.admin_gate === 'reply' && appt.status === 'cancelled';
    if (['seen','noshow'].includes(appt.status) || (appt.status === 'cancelled' && !unreleasedDecline)) throw httpError(400, 'สถานะนัดหมายนี้ไม่สามารถยกเลิกได้', 'This appointment cannot be cancelled in its current status');
    if (byPatient && new Date(`${appt.appt_date}T${appt.hhmm}:00`) <= new Date()) throw httpError(400, 'ถึงเวลานัดแล้ว ยกเลิกไม่ได้', 'The appointment time has passed; it can no longer be cancelled');
    // A hospital's cancellation waits for the admin before the patient sees it
    await connection.execute(
      `UPDATE appointments SET status='cancelled', cancelled_by=?, cancel_reason=?, cancelled_at=NOW(), admin_gate=? WHERE appointment_id=?`,
      [byPatient ? 'patient' : 'hospital', byPatient ? null : reason || null, byStaff ? 'reply' : null, req.params.id]
    );
    await connection.execute(`UPDATE reschedule_proposals SET response='declined', responded_at=NOW() WHERE appointment_id=? AND response='waiting'`, [req.params.id]);
    const when = fmtTh(appt.appt_date, appt.hhmm), doctor = `${appt.title}${appt.doctor_name}`;
    if (byPatient) {
      // A request the admin never forwarded is only known to the admin
      const to = appt.admin_gate === 'request' ? 'admin' : { hospital: appt.hospital_id };
      await notify(to, `${req.user.full_name} ยกเลิก${appt.status === 'pending' ? 'คำขอจอง' : 'นัด'} ${when} · ${doctor}`, appt.status === 'pending' ? 'requests' : 'patients', appt.appointment_id, connection);
    } else if (byStaff) {
      await notify('admin', `${appt.status === 'pending' ? 'โรงพยาบาลปฏิเสธคำขอจอง' : 'โรงพยาบาลยกเลิกนัด'} ${doctor} ${when} · เหตุผล: ${reason || '-'} · รอส่งให้ผู้ป่วย`, 'requests', appt.appointment_id, connection);
    } else {
      await notify({ account: appt.patient_id }, `${appt.status === 'pending' ? 'คำขอจองถูกปฏิเสธ' : 'นัดถูกยกเลิก'} ${doctor} ${appt.appt_date} · เหตุผล: ${reason || '-'}`, 'appts', appt.appointment_id, connection);
      if (appt.admin_gate !== 'request') await notify({ hospital: appt.hospital_id }, `แอดมินยกเลิกนัด ${when} · ${doctor}`, 'patients', appt.appointment_id, connection);
    }
    await connection.commit();
    res.json({ success: true, message: 'ยกเลิกนัดหมายแล้ว', message_en: 'Appointment cancelled' });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

router.patch('/:id/confirm', allowRoles('staff','admin'), asyncHandler(async (req, res) => {
  const appt = await loadAppt(req, req.params.id);
  if (appt.status !== 'pending') throw httpError(400, 'ยืนยันได้เฉพาะนัดที่รอดำเนินการ', 'Only pending appointments can be confirmed');
  if (new Date(`${appt.appt_date}T${appt.hhmm}:00`) <= new Date()) throw httpError(400, 'เลยเวลานัดแล้ว ยืนยันไม่ได้', 'The time has passed; cannot confirm');
  const byStaff = req.user.role === 'staff';
  if (byStaff) {
    // Stored procedure checks status = pending and that the staff member belongs to this hospital
    await db.execute('CALL sp_confirm_appointment(?, ?)', [req.params.id, req.user.account_id]);
    await db.execute(`UPDATE appointments SET admin_gate='reply' WHERE appointment_id=?`, [req.params.id]);
  } else {
    await db.execute(`UPDATE appointments SET status='upcoming', confirmed_by=NULL, confirmed_at=NOW(),
                      admin_gate=NULL WHERE appointment_id=?`, [req.params.id]);
  }
  const what = `นัดกับ ${appt.title}${appt.doctor_name} ${fmtTh(appt.appt_date, appt.hhmm)}`;
  if (byStaff) await notify('admin', `โรงพยาบาลยืนยัน${what} · รอส่งให้ผู้ป่วย`, 'requests', appt.appointment_id);
  else await notify({ account: appt.patient_id }, `${what} ได้รับการยืนยันแล้ว`, 'appts', appt.appointment_id);
  res.json({ success: true, message: byStaff ? 'ยืนยันนัดแล้ว รอแอดมินส่งให้ผู้ป่วย' : 'ยืนยันนัดหมายสำเร็จ',
    message_en: byStaff ? 'Confirmed. Waiting for the admin to send it to the patient' : 'Appointment confirmed' });
}));

// Staff record the visit outcome: seen / noshow, or back to upcoming if recorded by mistake.
router.patch('/:id/status', allowRoles('staff','admin'), asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['seen','noshow','upcoming'].includes(status)) throw httpError(400, 'สถานะไม่ถูกต้อง', 'Invalid status');
  const appt = await loadAppt(req, req.params.id);
  if (!['upcoming','seen','noshow'].includes(appt.status)) throw httpError(400, 'นัดนี้ยังไม่อยู่ในสถานะที่ตรวจเสร็จได้', 'This appointment cannot be marked as seen yet');
  if (status === 'upcoming') {
    const [linked] = await db.execute('SELECT 1 FROM medical_reports WHERE appointment_id=? LIMIT 1', [req.params.id]);
    if (linked.length) throw httpError(400, 'มีรายงานอ้างอิงนัดนี้แล้ว ย้อนกลับเป็นรอตรวจไม่ได้', 'A report already references this appointment; it cannot go back to waiting');
  } else if (new Date(`${appt.appt_date}T${appt.hhmm}:00`) > new Date()) {
    throw httpError(400, 'ยังไม่ถึงเวลานัด เลือกสถานะนี้ไม่ได้', "The appointment time hasn't come yet; this status can't be selected");
  }
  await db.execute('UPDATE appointments SET status=? WHERE appointment_id=?', [status, req.params.id]);
  if (status === 'noshow') await notify({ account: appt.patient_id }, `บันทึกว่าไม่มาตามนัด ${fmtTh(appt.appt_date, appt.hhmm)} · ${appt.title}${appt.doctor_name}`, 'appts', appt.appointment_id);
  res.json({ success: true, message: 'บันทึกแล้ว', message_en: 'Saved' });
}));
router.patch('/:id/complete', allowRoles('staff','admin'), asyncHandler(async (req, res) => {
  const appt = await loadAppt(req, req.params.id);
  if (appt.status !== 'upcoming') throw httpError(400, 'นัดนี้ยังไม่อยู่ในสถานะที่ตรวจเสร็จได้', 'This appointment cannot be marked as seen yet');
  await db.execute(`UPDATE appointments SET status='seen' WHERE appointment_id=?`, [req.params.id]);
  res.json({ success: true, message: 'บันทึกว่าตรวจแล้ว', message_en: 'Marked as seen' });
}));

// ---- reschedule proposals ----
router.post('/:id/propose', allowRoles('staff'), asyncHandler(async (req, res) => {
  const { doctor_id, date, time, reason } = req.body;
  if (!doctor_id || !date || !time) throw httpError(400, 'เลือกวันที่และเวลาที่ว่างก่อน', 'Choose a free date and time first');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const appt = await loadAppt(req, req.params.id, connection, true);
    if (appt.status !== 'pending') throw httpError(400, 'เสนอเปลี่ยนได้เฉพาะคำขอที่รอยืนยัน', 'Only pending requests can be rescheduled');
    const [[nd]] = await connection.execute('SELECT hospital_id, title, full_name FROM doctors WHERE doctor_id=? AND is_active=1', [doctor_id]);
    if (!nd || Number(nd.hospital_id) !== Number(appt.hospital_id)) throw httpError(403, 'ไม่มีสิทธิ์จัดการแพทย์นี้', 'You cannot manage this doctor');
    if (new Date(`${date}T${hhmm(time)}:00`) <= new Date()) throw httpError(400, 'ไม่สามารถจองวันเวลาที่ผ่านมาแล้ว', 'Cannot book a date/time in the past');
    if (await seatsLeft(connection, doctor_id, date, time) <= 0) throw httpError(409, 'ช่วงเวลานี้เต็มแล้ว', 'This slot is full');
    await connection.execute(
      'INSERT INTO reschedule_proposals (appointment_id,new_doctor_id,new_date,new_time,reason,proposed_by) VALUES (?,?,?,?,?,?)',
      [req.params.id, doctor_id, date, time, reason || null, req.user.account_id]
    );
    await connection.execute(`UPDATE appointments SET status='proposed', admin_gate='reply' WHERE appointment_id=?`, [req.params.id]);
    await notify('admin', `โรงพยาบาลเสนอเปลี่ยนนัดเป็น ${nd.title}${nd.full_name} ${fmtTh(date, time)} · รอส่งให้ผู้ป่วย`, 'requests', appt.appointment_id, connection);
    await connection.commit();
    res.json({ success: true, message: 'ส่งข้อเสนอแล้ว รอแอดมินส่งให้ผู้ป่วย', message_en: 'Proposal sent. Waiting for the admin to send it to the patient' });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

async function openProposal(connection, apptId) {
  const [rows] = await connection.execute(
    `SELECT proposal_id,new_doctor_id,new_date,TIME_FORMAT(new_time,'%H:%i') AS new_time FROM reschedule_proposals
     WHERE appointment_id=? AND response='waiting' ORDER BY proposal_id DESC LIMIT 1 FOR UPDATE`, [apptId]
  );
  if (!rows.length) throw httpError(400, 'ไม่มีข้อเสนอที่รอตอบรับ', 'There is no open proposal');
  return rows[0];
}

router.post('/:id/proposal/:action', asyncHandler(async (req, res) => {
  const { action } = req.params;
  if (!['accept','decline','withdraw'].includes(action)) throw httpError(404, 'ไม่พบ API ที่ร้องขอ', 'API endpoint not found');
  if (action === 'withdraw' ? req.user.role !== 'staff' : req.user.role !== 'patient') throw httpError(403, 'ไม่มีสิทธิ์', 'Permission denied');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const appt = await loadAppt(req, req.params.id, connection, true);
    if (appt.status !== 'proposed') throw httpError(400, 'ไม่มีข้อเสนอที่รอตอบรับ', 'There is no open proposal');
    if (req.user.role === 'patient' && appt.admin_gate === 'reply') throw httpError(400, 'ไม่มีข้อเสนอที่รอตอบรับ', 'There is no open proposal');
    const prop = await openProposal(connection, appt.appointment_id);
    let message, messageEn;
    if (action === 'accept') {
      if (new Date(`${prop.new_date}T${prop.new_time}:00`) <= new Date()) throw httpError(400, 'ข้อเสนอหมดอายุแล้ว', 'Proposal expired');
      await connection.execute(`UPDATE reschedule_proposals SET response='accepted', responded_at=NOW() WHERE proposal_id=?`, [prop.proposal_id]);
      await connection.execute(`UPDATE appointments SET doctor_id=?, appt_date=?, appt_time=?, status='upcoming', confirmed_at=NOW() WHERE appointment_id=?`,
        [prop.new_doctor_id, prop.new_date, prop.new_time, appt.appointment_id]);
      await notify({ hospital: appt.hospital_id }, `${req.user.full_name} ยอมรับนัดใหม่ · ${fmtTh(prop.new_date, prop.new_time)}`, 'patients', appt.appointment_id, connection);
      [message, messageEn] = ['ยอมรับนัดใหม่แล้ว นัดยืนยันเรียบร้อย', 'New appointment accepted and confirmed'];
    } else if (action === 'decline') {
      await connection.execute(`UPDATE reschedule_proposals SET response='declined', responded_at=NOW() WHERE proposal_id=?`, [prop.proposal_id]);
      await connection.execute(`UPDATE appointments SET status='cancelled', cancelled_by='patient', cancel_reason='ไม่ยอมรับข้อเสนอเปลี่ยนนัด', cancelled_at=NOW() WHERE appointment_id=?`, [appt.appointment_id]);
      await notify({ hospital: appt.hospital_id }, `${req.user.full_name} ไม่ยอมรับข้อเสนอเปลี่ยนนัด คำขอถูกยกเลิก`, 'patients', appt.appointment_id, connection);
      [message, messageEn] = ['ปฏิเสธข้อเสนอแล้ว คำขอถูกยกเลิก', 'Proposal declined; the request was cancelled'];
    } else {
      await connection.execute('DELETE FROM reschedule_proposals WHERE proposal_id=?', [prop.proposal_id]);
      await connection.execute(`UPDATE appointments SET status='pending', admin_gate=NULL WHERE appointment_id=?`, [appt.appointment_id]);
      // The patient only knows about the proposal if the admin already released it
      if (appt.admin_gate === 'reply') await notify('admin', 'โรงพยาบาลถอนข้อเสนอเปลี่ยนนัดก่อนส่งถึงผู้ป่วย', 'requests', appt.appointment_id, connection);
      else await notify({ account: appt.patient_id }, 'โรงพยาบาลถอนข้อเสนอเปลี่ยนนัด คำขอของคุณกลับไปรอการยืนยัน', 'appts', appt.appointment_id, connection);
      [message, messageEn] = ['ถอนข้อเสนอแล้ว กลับไปเป็นคำขอที่รอยืนยัน', 'Proposal withdrawn; back to a pending request'];
    }
    await connection.commit();
    res.json({ success: true, message, message_en: messageEn });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

// Patient confirms they came to the visit; the admin forwards it so the hospital sends results and medicine
router.post('/:id/visited', allowRoles('patient'), asyncHandler(async (req, res) => {
  const appt = await loadAppt(req, req.params.id);
  if (appt.status !== 'upcoming' || appt.admin_gate || appt.visited_at) throw httpError(400, 'นัดนี้ยืนยันการมาตรวจไม่ได้', 'This appointment cannot be confirmed as visited');
  await db.execute(`UPDATE appointments SET visited_at=NOW(), admin_gate='visit' WHERE appointment_id=?`, [req.params.id]);
  await notify('admin', `${req.user.full_name} ยืนยันว่ามาตรวจแล้ว · ${appt.title}${appt.doctor_name} ${fmtTh(appt.appt_date, appt.hhmm)} · รอส่งต่อให้โรงพยาบาล`, 'requests', appt.appointment_id);
  res.json({ success: true, message: 'ยืนยันการมาตรวจแล้ว รอแอดมินส่งต่อให้โรงพยาบาล', message_en: 'Visit confirmed. Waiting for the admin to forward it to the hospital' });
}));

// ---- admin is the middle step: patient -> admin -> hospital, hospital -> admin -> patient ----
router.post('/:id/forward', allowRoles('admin'), asyncHandler(async (req, res) => {
  const appt = await loadAppt(req, req.params.id);
  const isRequest = appt.admin_gate === 'request' && appt.status === 'pending', isVisit = appt.admin_gate === 'visit';
  if (!isRequest && !isVisit) throw httpError(400, 'รายการนี้ไม่ได้รอแอดมินส่งต่อ', 'This item is not waiting for the admin');
  const [[pt]] = await db.execute('SELECT full_name FROM accounts WHERE account_id=?', [appt.patient_id]);
  await db.execute('UPDATE appointments SET admin_gate=NULL WHERE appointment_id=?', [req.params.id]);
  const what = `${appt.title}${appt.doctor_name} ${fmtTh(appt.appt_date, appt.hhmm)}`;
  if (isRequest) await notify({ hospital: appt.hospital_id }, `คำขอจองใหม่จาก ${pt.full_name} · ${what}`, 'requests', appt.appointment_id);
  else await notify({ hospital: appt.hospital_id }, `${pt.full_name} มาตรวจแล้ว · ${what} · กรุณาส่งผลตรวจและยา`, 'patients', appt.appointment_id);
  res.json({ success: true, message: 'ส่งต่อให้โรงพยาบาลแล้ว', message_en: 'Forwarded to the hospital' });
}));

router.post('/:id/release', allowRoles('admin'), asyncHandler(async (req, res) => {
  const appt = await loadAppt(req, req.params.id);
  if (appt.admin_gate !== 'reply') throw httpError(400, 'นัดนี้ไม่มีคำตอบที่รอแอดมินส่งให้ผู้ป่วย', 'This appointment has no hospital answer waiting for the admin');
  const doctor = `${appt.title}${appt.doctor_name}`;
  let msg;
  if (appt.status === 'proposed') {
    const [[p]] = await db.execute(
      `SELECT new_doctor_id, new_date, TIME_FORMAT(new_time,'%H:%i') AS new_time FROM reschedule_proposals
       WHERE appointment_id=? AND response='waiting' ORDER BY proposal_id DESC LIMIT 1`, [appt.appointment_id]);
    const nd = await doctorOf(db, p.new_doctor_id);
    msg = `โรงพยาบาลเสนอเปลี่ยนนัดเป็น ${nd.title}${nd.full_name} ${fmtTh(p.new_date, p.new_time)} · กรุณาตอบรับ`;
  } else if (appt.status === 'cancelled') {
    msg = `${appt.confirmed_at ? 'โรงพยาบาลยกเลิกนัด' : 'โรงพยาบาลปฏิเสธคำขอจอง'} ${doctor} ${appt.appt_date} · เหตุผล: ${appt.cancel_reason || '-'}`;
  } else {
    msg = `นัดกับ ${doctor} ${fmtTh(appt.appt_date, appt.hhmm)} ได้รับการยืนยันแล้ว`;
  }
  await db.execute('UPDATE appointments SET admin_gate=NULL WHERE appointment_id=?', [req.params.id]);
  await notify({ account: appt.patient_id }, msg, 'appts', appt.appointment_id);
  res.json({ success: true, message: 'ส่งคำตอบของโรงพยาบาลให้ผู้ป่วยแล้ว', message_en: "Hospital's answer sent to the patient" });
}));

// Admin reminds the hospital about an overdue request
router.post('/:id/nudge', allowRoles('admin'), asyncHandler(async (req, res) => {
  const appt = await loadAppt(req, req.params.id);
  await db.execute('UPDATE appointments SET nudged=1 WHERE appointment_id=?', [req.params.id]);
  await notify({ hospital: appt.hospital_id }, 'แอดมินแจ้งเตือน: มีคำขอจองที่ค้างนาน กรุณายืนยันหรือปฏิเสธ', 'requests', appt.appointment_id);
  res.json({ success: true, message: 'แจ้งเตือนโรงพยาบาลแล้ว', message_en: 'Hospital notified' });
}));
module.exports = router;
