const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate, allowRoles } = require('../middleware/auth');
const { writeAudit } = require('../services/audit');
const { staffHospital } = require('../services/notify');
router.use(authenticate, allowRoles('staff','admin'));

const LIST_SQL = `SELECT a.account_id, a.role, a.full_name, a.email, a.phone, a.status, a.photo,
                         s.hospital_id, s.work_unit, p.hn, p.date_of_birth, p.allergies
                  FROM accounts a LEFT JOIN staff s ON s.staff_id=a.account_id LEFT JOIN patients p ON p.patient_id=a.account_id`;

// Admin sees every account; staff see the staff accounts of their own hospital.
router.get('/', asyncHandler(async (req, res) => {
  const [rows] = req.user.role === 'admin'
    ? await db.execute(`${LIST_SQL} WHERE a.email NOT LIKE '%@walkin.morhub.local' ORDER BY a.account_id`)
    : await db.execute(`${LIST_SQL} WHERE s.hospital_id=? ORDER BY a.account_id`, [await staffHospital(req.user.account_id)]);
  res.json({ success: true, data: rows });
}));

router.post('/', asyncHandler(async (req, res) => {
  const { name, email, phone, password } = req.body;
  const role = req.user.role === 'admin' && req.body.role === 'admin' ? 'admin' : 'staff';
  if (!name || !email || !password) throw httpError(400, 'กรอกข้อมูลให้ครบ', 'Please complete all fields');
  if (!/^\S+@\S+\.\S+$/.test(email)) throw httpError(400, 'รูปแบบอีเมลไม่ถูกต้อง', 'Invalid email format');
  if (String(password).length < 8) throw httpError(400, 'รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร', 'Password must be at least 8 characters');
  const hospitalId = req.user.role === 'staff' ? await staffHospital(req.user.account_id) : (req.body.hid || 1);
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [result] = await connection.execute(
      `INSERT INTO accounts (role,full_name,email,password_hash,phone,status,must_change_pw) VALUES (?,?,?,?,?,'active',TRUE)`,
      [role, String(name).trim(), String(email).trim().toLowerCase(), await bcrypt.hash(password, 12), phone || null]
    );
    if (role === 'staff') await connection.execute('INSERT INTO staff (staff_id,hospital_id,work_unit) VALUES (?,?,?)', [result.insertId, hospitalId, req.body.dpt || null]);
    await connection.commit();
    res.status(201).json({ success: true, message: 'สร้างบัญชีแล้ว', message_en: 'Account created', account_id: result.insertId });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

// Approve a pending account, suspend, or re-enable (admin only)
router.patch('/:id/status', allowRoles('admin'), asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['active','disabled'].includes(status)) throw httpError(400, 'สถานะไม่ถูกต้อง', 'Invalid status');
  if (Number(req.params.id) === req.user.account_id) throw httpError(400, 'ระงับบัญชีของตัวเองไม่ได้', 'You cannot suspend your own account');
  const [rows] = await db.execute('SELECT status FROM accounts WHERE account_id=?', [req.params.id]);
  if (!rows.length) throw httpError(404, 'ไม่พบบัญชี', 'Account not found');
  await db.execute('UPDATE accounts SET status=? WHERE account_id=?', [status, req.params.id]);
  await writeAudit({ eventType: status === 'disabled' ? 'account_disabled' : rows[0].status === 'pending' ? 'account_approved' : 'other',
    actorId: req.user.account_id, targetId: Number(req.params.id) });
  res.json({ success: true, message: status === 'active' ? 'เปิดใช้งานบัญชีแล้ว' : 'ระงับบัญชีแล้ว', message_en: status === 'active' ? 'Account enabled' : 'Account suspended' });
}));

// Reject a pending sign-up request
router.delete('/:id', allowRoles('admin'), asyncHandler(async (req, res) => {
  const [result] = await db.execute(`DELETE FROM accounts WHERE account_id=? AND status='pending'`, [req.params.id]);
  if (!result.affectedRows) throw httpError(400, 'ลบได้เฉพาะบัญชีที่รออนุมัติ', 'Only pending accounts can be rejected');
  res.json({ success: true, message: 'ปฏิเสธและลบคำขอสร้างบัญชีแล้ว', message_en: 'Request rejected and removed' });
}));

// Admin "acts as" a staff or patient account. Short-lived token, logged in audit_logs.
router.post('/:id/act-as', allowRoles('admin'), asyncHandler(async (req, res) => {
  const [rows] = await db.execute('SELECT account_id, role, full_name, status FROM accounts WHERE account_id=?', [req.params.id]);
  const target = rows[0];
  if (!target) throw httpError(404, 'ไม่พบบัญชี', 'Account not found');
  if (target.role === 'admin') throw httpError(400, 'ใช้งานแทนบัญชีแอดมินไม่ได้', 'Cannot act as an admin account');
  if (target.status !== 'active') throw httpError(400, 'บัญชีนี้ถูกระงับหรือรออนุมัติ ใช้งานแทนไม่ได้', 'This account is suspended or awaiting approval; cannot act as it');
  await writeAudit({ eventType: 'act_start', actorId: req.user.account_id, targetId: target.account_id, reason: String(req.body.reason || '').slice(0, 100) || null });
  const token = jwt.sign(
    { account_id: target.account_id, role: target.role, full_name: target.full_name, act_by: req.user.account_id },
    process.env.JWT_SECRET, { expiresIn: '1h' }
  );
  res.json({ success: true, token });
}));
module.exports = router;
