const router = require('express').Router();
const db = require('../config/database');
const { asyncHandler, httpError, checkPhoto } = require('../utils/http');
const { authenticate, allowRoles } = require('../middleware/auth');
const { staffHospital } = require('../services/notify');

router.get('/', asyncHandler(async (req, res) => {
  const [rows] = await db.execute(
    'SELECT hospital_id,hospital_name,province,address,phone,opening_hours,photo FROM hospitals ORDER BY hospital_id'
  );
  res.json({ success: true, data: rows });
}));

router.post('/', authenticate, allowRoles('admin'), asyncHandler(async (req, res) => {
  const { hospital_name, province } = req.body;
  if (!hospital_name) throw httpError(400, 'กรอกชื่อโรงพยาบาล', 'Enter the hospital name');
  const [result] = await db.execute('INSERT INTO hospitals (hospital_name,province) VALUES (?,?)', [String(hospital_name).trim(), province || '']);
  res.status(201).json({ success: true, message: 'เพิ่มโรงพยาบาลแล้ว', message_en: 'Hospital added', hospital_id: result.insertId });
}));

// Staff edit their own hospital's details and photo; the name is admin-only.
router.patch('/:id', authenticate, allowRoles('staff','admin'), asyncHandler(async (req, res) => {
  if (req.user.role === 'staff' && Number(await staffHospital(req.user.account_id)) !== Number(req.params.id)) {
    throw httpError(403, 'ไม่มีสิทธิ์แก้ไขโรงพยาบาลนี้', 'You cannot edit this hospital');
  }
  checkPhoto(req.body.photo);
  const fields = { address: 'address', phone: 'phone', opening_hours: 'opening_hours', photo: 'photo' };
  if (req.user.role === 'admin') fields.hospital_name = 'hospital_name';
  const sets = [], params = [];
  for (const [key, col] of Object.entries(fields)) {
    if (req.body[key] !== undefined) { sets.push(`${col}=?`); params.push(req.body[key] || null); }
  }
  if (!sets.length) throw httpError(400, 'ไม่มีข้อมูลที่จะบันทึก', 'Nothing to update');
  params.push(req.params.id);
  await db.execute(`UPDATE hospitals SET ${sets.join(',')} WHERE hospital_id=?`, params);
  res.json({ success: true, message: 'บันทึกข้อมูลโรงพยาบาลแล้ว', message_en: 'Hospital details saved' });
}));
module.exports = router;
