const router = require('express').Router();
const jwt = require('jsonwebtoken');
const db = require('../config/database');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate, allowRoles } = require('../middleware/auth');
const { notify } = require('../services/notify');

// Logged-in patients and guests can both report a problem.
function optionalUser(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  try { return jwt.verify(header.slice(7), process.env.JWT_SECRET); } catch { return null; }
}

router.post('/', asyncHandler(async (req, res) => {
  const user = optionalUser(req);
  const { topic, message, guest_name, guest_contact, appointment_id } = req.body;
  if (!String(message || '').trim()) throw httpError(400, 'กรอกรายละเอียดปัญหา', 'Please describe the problem');
  if (!user && (!String(guest_name || '').trim() || !String(guest_contact || '').trim())) throw httpError(400, 'กรอกชื่อและช่องทางติดต่อกลับ', 'Please enter your name and contact');
  const patientId = user && user.role === 'patient' ? user.account_id : null;
  await db.execute(
    `INSERT INTO support_tickets (patient_id,guest_name,guest_contact,topic,appointment_id,message) VALUES (?,?,?,?,?,?)`,
    [patientId, user ? user.full_name : String(guest_name).trim(), user ? null : String(guest_contact).trim(),
     topic || null, patientId && appointment_id ? appointment_id : null, String(message).trim()]
  );
  await notify('admin', `เรื่องร้องเรียนใหม่จาก ${user ? user.full_name : String(guest_name).trim()}`, 'issues');
  res.status(201).json({ success: true, message: 'ส่งเรื่องให้ผู้ดูแลระบบแล้ว ขอบคุณที่แจ้งค่ะ', message_en: 'Report sent to the administrator. Thank you' });
}));

router.get('/', authenticate, allowRoles('patient','admin'), asyncHandler(async (req, res) => {
  const mine = req.user.role === 'patient';
  const [rows] = await db.execute(
    `SELECT t.ticket_id, t.patient_id, t.guest_name, t.guest_contact, t.topic, t.appointment_id, t.hospital_id, t.message,
            t.status, t.resolution_note, UNIX_TIMESTAMP(t.created_at)*1000 AS created_ms,
            UNIX_TIMESTAMP(t.resolved_at)*1000 AS resolved_ms, ac.email AS patient_email
     FROM support_tickets t LEFT JOIN accounts ac ON ac.account_id=t.patient_id
     ${mine ? 'WHERE t.patient_id=?' : ''} ORDER BY t.created_at DESC LIMIT 500`, mine ? [req.user.account_id] : []
  );
  res.json({ success: true, data: rows });
}));

router.patch('/:id/resolve', authenticate, allowRoles('admin'), asyncHandler(async (req, res) => {
  const note = String(req.body.note || '').trim() || null;
  const [rows] = await db.execute('SELECT patient_id FROM support_tickets WHERE ticket_id=?', [req.params.id]);
  if (!rows.length) throw httpError(404, 'ไม่พบเรื่องร้องเรียน', 'Complaint not found');
  await db.execute(`UPDATE support_tickets SET status='resolved', resolution_note=?, resolved_by=?, resolved_at=NOW() WHERE ticket_id=?`,
    [note, req.user.account_id, req.params.id]);
  if (rows[0].patient_id) await notify({ account: rows[0].patient_id }, 'เรื่องที่คุณแจ้งไว้ดำเนินการแล้ว' + (note ? ': ' + note : ''), 'home');
  res.json({ success: true, message: 'บันทึกการดำเนินการแล้ว', message_en: 'Resolution saved' });
}));
module.exports = router;
