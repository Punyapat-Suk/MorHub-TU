const router = require('express').Router();
const db = require('../config/database');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate, allowRoles } = require('../middleware/auth');
const { notify, staffHospital } = require('../services/notify');
router.use(authenticate);

const WALKIN_DOMAIN = '@walkin.morhub.local';
const MAX_FILES = 6;
const FILE_TYPE = /^(image\/(jpeg|png|webp|gif)|application\/pdf)$/;
const FILE_DATA_URL = /^data:(image\/(jpeg|png|webp|gif)|application\/pdf);base64,[A-Za-z0-9+/=]+$/;

router.get('/', allowRoles('patient','staff','admin'), asyncHandler(async (req, res) => {
  let where, params;
  // The patient only sees reports the admin has approved
  if (req.user.role === 'patient') { where = 'r.patient_id=? AND r.admin_ok=1'; params = [req.user.account_id]; }
  else if (req.user.role === 'staff') { where = 'r.hospital_id=?'; params = [await staffHospital(req.user.account_id)]; }
  else { where = '1=1'; params = []; }
  const [reports] = await db.execute(
    `SELECT r.report_id, r.patient_id, r.hospital_id, r.appointment_id, r.doctor_id, r.visit_date, r.diagnosis, r.advice,
            r.next_appointment_id, r.is_closed, r.seen_by_patient, r.admin_ok, DATE(r.created_at) AS created_date,
            ac.full_name AS created_by_name, n.doctor_id AS next_doctor_id, n.appt_date AS next_date,
            TIME_FORMAT(n.appt_time,'%H:%i') AS next_time
     FROM medical_reports r LEFT JOIN accounts ac ON ac.account_id=r.created_by
     LEFT JOIN appointments n ON n.appointment_id=r.next_appointment_id
     WHERE ${where} ORDER BY r.visit_date DESC, r.report_id DESC`, params
  );
  if (reports.length) {
    const ids = reports.map(r => r.report_id), marks = ids.map(() => '?').join(',');
    const [meds] = await db.execute(`SELECT report_id, drug_name, dosage, duration_days FROM prescriptions WHERE report_id IN (${marks}) ORDER BY prescription_id`, ids);
    const [files] = await db.execute(`SELECT report_id, file_name, mime_type, data_url FROM report_files WHERE report_id IN (${marks}) ORDER BY file_id`, ids);
    reports.forEach(r => {
      r.meds = meds.filter(m => m.report_id === r.report_id);
      r.files = files.filter(f => f.report_id === r.report_id);
    });
  }
  res.json({ success: true, data: reports });
}));

router.post('/', allowRoles('staff'), asyncHandler(async (req, res) => {
  const { patient_id, appointment_id, visit_date, doctor_id, diagnosis, advice, meds = [], files = [], next } = req.body;
  if (!patient_id) throw httpError(400, 'เลือกผู้ป่วยก่อน', 'Choose a patient first');
  if (!String(diagnosis || '').trim()) throw httpError(400, 'กรอกการวินิจฉัยก่อน', 'Enter the diagnosis first');
  if (!visit_date) throw httpError(400, 'ระบุวันที่ของการตรวจ', 'Specify the visit date');
  if (!Array.isArray(files) || files.length > MAX_FILES || files.some(f => !FILE_TYPE.test(f.type) || !FILE_DATA_URL.test(f.url) || !String(f.url).startsWith(`data:${f.type};`))) {
    throw httpError(400, 'ข้ามบางไฟล์ (รับเฉพาะรูป/PDF ไม่เกิน 10 MB รวมไม่เกิน 6 ไฟล์)', 'Only images/PDF, up to 6 files');
  }
  const hospitalId = await staffHospital(req.user.account_id);
  const [known] = await db.execute(
    'SELECT 1 FROM appointments a JOIN doctors d ON d.doctor_id=a.doctor_id WHERE a.patient_id=? AND d.hospital_id=? LIMIT 1',
    [patient_id, hospitalId]
  );
  if (!known.length) throw httpError(403, 'ผู้ป่วยรายนี้ไม่มีนัดกับโรงพยาบาลนี้', 'This patient has no appointments at this hospital');

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    let appt = null;
    if (appointment_id) {
      const [rows] = await connection.execute(
        `SELECT a.appointment_id, a.status, a.doctor_id, a.visited_at, a.admin_gate
         FROM appointments a JOIN doctors d ON d.doctor_id=a.doctor_id
         WHERE a.appointment_id=? AND a.patient_id=? AND d.hospital_id=? FOR UPDATE`, [appointment_id, patient_id, hospitalId]
      );
      if (!rows.length) throw httpError(404, 'ไม่พบนัดหมาย', 'Appointment not found');
      appt = rows[0];
    }
    // Results and medicine follow the patient's own confirmation of the visit, forwarded by the admin.
    // Walk-in patients have no login to confirm with, so the hospital reports for them directly.
    const [[pt]] = await connection.execute('SELECT full_name, email FROM accounts WHERE account_id=?', [patient_id]);
    if (!String(pt.email).endsWith(WALKIN_DOMAIN)) {
      if (!appt) throw httpError(400, 'เลือกนัดที่ผู้ป่วยยืนยันว่ามาตรวจแล้ว', 'Choose the appointment the patient confirmed visiting');
      if (!appt.visited_at || appt.admin_gate) throw httpError(400, 'ผู้ป่วยยังไม่ได้ยืนยันว่ามาตรวจ หรือแอดมินยังไม่ได้ส่งต่อ', 'The patient has not confirmed the visit yet, or the admin has not forwarded it');
    }
    if (appt && appt.status === 'cancelled') throw httpError(400, 'นัดนี้ถูกยกเลิกแล้ว', 'This appointment was cancelled');
    let nextId = null;
    if (next) {
      if (!next.doctor_id || !next.date || !next.time) throw httpError(400, 'ระบุแพทย์ วันที่ และเวลาของนัดต่อให้ครบ', 'Please specify doctor, date and time for the follow-up');
      if (new Date(`${next.date}T${next.time}:00`) <= new Date()) throw httpError(400, 'ช่วงเวลานัดต่อไม่ว่างแล้ว กรุณาเลือกใหม่', 'The follow-up slot is no longer free. Please choose again');
      // The insert trigger enforces the doctor's schedule and slot capacity.
      const [ins] = await connection.execute(
        // Released to the patient together with the report when the admin approves it
        `INSERT INTO appointments (patient_id,doctor_id,appt_date,appt_time,symptom_note,status,is_follow_up,follow_up_of,confirmed_by,confirmed_at,admin_gate)
         VALUES (?,?,?,?,'นัดติดตามผล','upcoming',TRUE,?,?,NOW(),'reply')`,
        [patient_id, next.doctor_id, next.date, next.time, appt ? appt.appointment_id : null, req.user.account_id]
      );
      nextId = ins.insertId;
    }
    const [rep] = await connection.execute(
      `INSERT INTO medical_reports (patient_id,hospital_id,appointment_id,doctor_id,visit_date,diagnosis,advice,next_appointment_id,is_closed,created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [patient_id, hospitalId, appt ? appt.appointment_id : null, doctor_id || (appt ? appt.doctor_id : null), visit_date,
       String(diagnosis).trim(), advice || null, nextId, !nextId, req.user.account_id]
    );
    for (const m of meds.filter(m => String(m.n || '').trim())) {
      await connection.execute('INSERT INTO prescriptions (report_id,drug_name,dosage,duration_days) VALUES (?,?,?,?)',
        [rep.insertId, String(m.n).trim(), String(m.d || '').trim() || '-', parseInt(m.days, 10) || null]);
    }
    for (const f of files) {
      await connection.execute('INSERT INTO report_files (report_id,file_name,mime_type,data_url,file_size_bytes) VALUES (?,?,?,?,?)',
        [rep.insertId, String(f.name).slice(0, 255), f.type, f.url, Math.round(String(f.url).length * 0.75)]);
    }
    await notify('admin', `รายงานผลตรวจและยาใหม่ของ ${pt.full_name}: ${String(diagnosis).trim()} · รออนุมัติ`, 'requests', appt ? appt.appointment_id : null, connection);
    await connection.commit();
    res.status(201).json({ success: true, message: 'ส่งรายงานแล้ว รอแอดมินอนุมัติก่อนส่งถึงผู้ป่วย',
      message_en: 'Report sent. Waiting for admin approval before it reaches the patient', report_id: rep.insertId });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

// Admin approves a report: it (and its follow-up appointment) reaches the patient
router.patch('/:id/approve', allowRoles('admin'), asyncHandler(async (req, res) => {
  const [[r]] = await db.execute(
    `SELECT r.report_id, r.patient_id, r.appointment_id, r.diagnosis, r.admin_ok, r.next_appointment_id,
            n.appt_date AS next_date, TIME_FORMAT(n.appt_time,'%H:%i') AS next_time
     FROM medical_reports r LEFT JOIN appointments n ON n.appointment_id=r.next_appointment_id WHERE r.report_id=?`, [req.params.id]);
  if (!r) throw httpError(404, 'ไม่พบรายงาน', 'Report not found');
  if (r.admin_ok) throw httpError(400, 'อนุมัติรายงานนี้แล้ว', 'This report is already approved');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    await connection.execute('UPDATE medical_reports SET admin_ok=1 WHERE report_id=?', [r.report_id]);
    // The visit is done; with no follow-up from the doctor, this also ends the treatment
    if (r.appointment_id) await connection.execute(`UPDATE appointments SET status='seen' WHERE appointment_id=? AND status='upcoming'`, [r.appointment_id]);
    await notify({ account: r.patient_id }, `มีผลตรวจและยาใหม่: ${r.diagnosis}${r.next_appointment_id ? '' : ' · การนัดครั้งนี้เสร็จสิ้นแล้ว'}`, 'results', r.appointment_id, connection);
    if (r.next_appointment_id) {
      await connection.execute(`UPDATE appointments SET admin_gate=NULL WHERE appointment_id=? AND admin_gate='reply'`, [r.next_appointment_id]);
      await notify({ account: r.patient_id }, `มีนัดติดตาม ${r.next_date} ${r.next_time} · ดูใบนัดในผลตรวจ`, 'appts', r.next_appointment_id, connection);
    }
    await connection.commit();
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
  res.json({ success: true, message: 'อนุมัติแล้ว ส่งผลตรวจและยาให้ผู้ป่วยแล้ว', message_en: 'Approved. Results and medicine sent to the patient' });
}));

router.patch('/:id/seen', allowRoles('patient'), asyncHandler(async (req, res) => {
  await db.execute('UPDATE medical_reports SET seen_by_patient=1 WHERE report_id=? AND patient_id=?', [req.params.id, req.user.account_id]);
  res.json({ success: true });
}));
module.exports = router;
