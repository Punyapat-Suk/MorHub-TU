const router = require('express').Router();
const db = require('../config/database');
const { asyncHandler, httpError, checkPhoto } = require('../utils/http');
const { authenticate, allowRoles } = require('../middleware/auth');
const { staffHospital, notify } = require('../services/notify');

router.get('/departments', asyncHandler(async (req, res) => {
  const [rows] = await db.execute('SELECT department_id, dept_code, dept_name_th, dept_name_en, icon FROM departments ORDER BY dept_name_th');
  res.json({ success: true, data: rows });
}));
router.get('/', asyncHandler(async (req, res) => {
  const { hospital_id, department_id, q } = req.query;
  let sql = `SELECT d.doctor_id, d.hospital_id, h.hospital_name, d.department_id, dep.dept_code,
                    dep.dept_name_th, dep.dept_name_en, d.title, d.full_name, d.room,
                    d.experience_years, d.slot_minutes, d.slot_capacity,
                    d.photo, d.headline, d.education_th, d.education_en
             FROM doctors d JOIN hospitals h ON h.hospital_id=d.hospital_id
             JOIN departments dep ON dep.department_id=d.department_id WHERE d.is_active=1`;
  const params = [];
  if (hospital_id) { sql += ' AND d.hospital_id=?'; params.push(hospital_id); }
  if (department_id) { sql += ' AND d.department_id=?'; params.push(department_id); }
  if (q) { sql += ' AND (d.full_name LIKE ? OR dep.dept_name_th LIKE ?)'; params.push(`%${q}%`, `%${q}%`); }
  sql += ' ORDER BY dep.dept_name_th, d.full_name';
  const [rows] = await db.execute(sql, params);
  const [schedules] = await db.execute(
    `SELECT s.doctor_id, s.weekday, TIME_FORMAT(s.start_time,'%H:%i') AS start_time, TIME_FORMAT(s.end_time,'%H:%i') AS end_time
     FROM doctor_schedules s JOIN doctors d ON d.doctor_id=s.doctor_id WHERE d.is_active=1 ORDER BY s.weekday, s.start_time`
  );
  rows.forEach(d => { d.schedules = schedules.filter(s => s.doctor_id === d.doctor_id); });
  res.json({ success: true, data: rows });
}));
router.get('/:id/schedules', authenticate, asyncHandler(async (req, res) => {
  const [rows] = await db.execute(
    `SELECT schedule_id, weekday, start_time, end_time FROM doctor_schedules WHERE doctor_id=? ORDER BY weekday,start_time`, [req.params.id]
  );
  res.json({ success: true, data: rows });
}));

// ---- staff: add / edit / remove doctors of their own hospital ----
const TIME = /^\d{2}:\d{2}$/;
async function doctorHospital(req, doctorId) {
  const [rows] = await db.execute('SELECT hospital_id FROM doctors WHERE doctor_id=? AND is_active=1', [doctorId]);
  if (!rows.length) throw httpError(404, 'ไม่พบแพทย์', 'Doctor not found');
  if (req.user.role === 'staff' && Number(await staffHospital(req.user.account_id)) !== Number(rows[0].hospital_id)) {
    throw httpError(403, 'ไม่มีสิทธิ์จัดการแพทย์นี้', 'You cannot manage this doctor');
  }
  return rows[0].hospital_id;
}
// "นพ.ธนา วงศ์สว่าง" -> ['นพ.', 'ธนา วงศ์สว่าง']
function splitName(name) {
  const m = String(name || '').trim().match(/^(นพ\.|พญ\.)\s*(.*)$/);
  return m ? [m[1], m[2]] : ['', String(name || '').trim()];
}
async function readDoctorBody(body) {
  const [title, fullName] = splitName(body.name);
  if (!fullName) throw httpError(400, 'กรอกชื่อแพทย์ก่อน', "Enter the doctor's name first");
  const [dep] = await db.execute('SELECT department_id FROM departments WHERE dept_code=?', [body.dept]);
  if (!dep.length) throw httpError(400, 'ไม่พบแผนก', 'Department not found');
  const weekdays = [...new Set((body.wd || []).map(Number))].filter(w => w >= 0 && w <= 6);
  if (!weekdays.length) throw httpError(400, 'เลือกวันที่ตรวจอย่างน้อย 1 วัน', 'Choose at least 1 clinic day');
  const sessions = (body.sessions || []).filter(([s, e]) => TIME.test(s) && TIME.test(e) && s < e);
  if (!sessions.length) throw httpError(400, 'ตั้งเวลาตรวจช่วงที่ 1 ให้ถูกต้อง', 'Set a valid time for session 1');
  checkPhoto(body.img);
  return {
    title, fullName, departmentId: dep[0].department_id, weekdays, sessions,
    room: body.room || null, exp: parseInt(body.exp, 10) || null,
    cap: Math.min(20, Math.max(1, parseInt(body.cap, 10) || 1)),
    photo: body.img || null, headline: body.title || null,
    eduTh: body.eduTh ?? null, eduEn: body.edu ?? null
  };
}
async function writeSchedules(connection, doctorId, d) {
  await connection.execute('DELETE FROM doctor_schedules WHERE doctor_id=?', [doctorId]);
  for (const w of d.weekdays) for (const [s, e] of d.sessions) {
    await connection.execute('INSERT INTO doctor_schedules (doctor_id,weekday,start_time,end_time) VALUES (?,?,?,?)', [doctorId, w, s, e]);
  }
}

router.post('/', authenticate, allowRoles('staff','admin'), asyncHandler(async (req, res) => {
  const d = await readDoctorBody(req.body);
  const hospitalId = req.user.role === 'staff' ? await staffHospital(req.user.account_id) : req.body.hid;
  if (!hospitalId) throw httpError(400, 'กรุณาระบุโรงพยาบาล', 'Please provide a hospital');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [result] = await connection.execute(
      `INSERT INTO doctors (hospital_id,department_id,title,full_name,room,experience_years,slot_capacity,photo,headline,education_th,education_en)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [hospitalId, d.departmentId, d.title, d.fullName, d.room, d.exp, d.cap, d.photo, d.headline, d.eduTh, d.eduEn]
    );
    await writeSchedules(connection, result.insertId, d);
    await connection.commit();
    res.status(201).json({ success: true, message: 'บันทึกข้อมูลแพทย์แล้ว', message_en: 'Doctor saved', doctor_id: result.insertId });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

router.put('/:id', authenticate, allowRoles('staff','admin'), asyncHandler(async (req, res) => {
  const hospitalId = await doctorHospital(req, req.params.id);
  const d = await readDoctorBody(req.body);
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    await connection.execute(
      `UPDATE doctors SET department_id=?,title=?,full_name=?,room=?,experience_years=?,slot_capacity=?,photo=?,headline=?,
         education_th=COALESCE(?,education_th),education_en=COALESCE(?,education_en) WHERE doctor_id=?`,
      [d.departmentId, d.title, d.fullName, d.room, d.exp, d.cap, d.photo, d.headline, d.eduTh, d.eduEn, req.params.id]
    );
    await writeSchedules(connection, req.params.id, d);
    // Future active appointments that no longer fit the new weekly schedule
    const [[{ n }]] = await connection.execute(
      `SELECT COUNT(*) AS n FROM appointments a WHERE a.doctor_id=? AND a.status IN ('pending','upcoming')
         AND TIMESTAMP(a.appt_date,a.appt_time) > NOW()
         AND NOT EXISTS (SELECT 1 FROM doctor_schedules s WHERE s.doctor_id=a.doctor_id
           AND s.weekday=DAYOFWEEK(a.appt_date)-1 AND a.appt_time>=s.start_time AND a.appt_time<s.end_time)`,
      [req.params.id]
    );
    if (n) await notify({ hospital: hospitalId }, `ตารางของ ${d.title}${d.fullName} เปลี่ยนแล้ว มี ${n} นัดที่ไม่ตรงกับตารางใหม่ กรุณาตรวจสอบและเสนอเปลี่ยนนัด`, 'patients', null, connection);
    await connection.commit();
    res.json({ success: true, message: 'บันทึกข้อมูลแพทย์แล้ว', message_en: 'Doctor saved', conflicts: n });
  } catch (e) { await connection.rollback(); throw e; }
  finally { connection.release(); }
}));

// Soft delete: past appointments and reports keep pointing at the doctor row.
router.delete('/:id', authenticate, allowRoles('staff','admin'), asyncHandler(async (req, res) => {
  await doctorHospital(req, req.params.id);
  const [active] = await db.execute(
    `SELECT 1 FROM appointments WHERE doctor_id=? AND status IN ('pending','upcoming','proposed') LIMIT 1`, [req.params.id]
  );
  if (active.length) throw httpError(400, 'ลบไม่ได้ เพราะยังมีนัดหมายที่รอยืนยันหรือรอตรวจ', 'Cannot delete: there are pending or waiting appointments');
  await db.execute('UPDATE doctors SET is_active=0 WHERE doctor_id=?', [req.params.id]);
  res.json({ success: true, message: 'ลบแพทย์แล้ว', message_en: 'Doctor deleted' });
}));
module.exports = router;
