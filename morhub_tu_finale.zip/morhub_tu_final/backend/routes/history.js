const router = require('express').Router();
const db = require('../config/database');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate } = require('../middleware/auth');
router.use(authenticate);

// What each role may clear. Clearing hides items from the caller's own lists; nothing is deleted.
const KINDS = { notifications: ['patient','staff','admin'], appointments: ['patient'], tickets: ['patient','admin'] };

router.get('/', asyncHandler(async (req, res) => {
  const [rows] = await db.execute('SELECT kind, UNIX_TIMESTAMP(cleared_at)*1000 AS ms FROM history_clears WHERE account_id=?', [req.user.account_id]);
  res.json({ success: true, data: Object.fromEntries(rows.map(r => [r.kind, Number(r.ms)])) });
}));

router.post('/:kind/clear', asyncHandler(async (req, res) => {
  const roles = KINDS[req.params.kind];
  if (!roles) throw httpError(404, 'ไม่พบ API ที่ร้องขอ', 'API endpoint not found');
  if (!roles.includes(req.user.role)) throw httpError(403, 'ไม่มีสิทธิ์', 'Permission denied');
  await db.execute(
    'INSERT INTO history_clears (account_id, kind, cleared_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE cleared_at=NOW()',
    [req.user.account_id, req.params.kind]
  );
  res.json({ success: true, message: 'ล้างประวัติแล้ว', message_en: 'History cleared' });
}));
module.exports = router;
