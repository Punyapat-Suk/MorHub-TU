function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
// message = Thai (shown in UI), messageEn = English
function httpError(status, message, messageEn) {
  const error = new Error(message);
  error.status = status;
  error.messageEn = messageEn;
  return error;
}
// Photos are rendered into <img src="...">, so only accept real base64 image data URLs.
const IMAGE_DATA_URL = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
function checkPhoto(value) {
  if (value && !IMAGE_DATA_URL.test(value)) throw httpError(400, 'รูปภาพไม่ถูกต้อง', 'Invalid image');
}
module.exports = { asyncHandler, httpError, checkPhoto };
