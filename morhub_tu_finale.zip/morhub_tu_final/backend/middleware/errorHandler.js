function notFound(req, res) {
  res.status(404).json({ success: false, message: 'ไม่พบ API ที่ร้องขอ', message_en: 'API endpoint not found' });
}
// Messages raised by the booking trigger (SIGNAL SQLSTATE '45000') in morhub_tu_latest_schema.sql
const TRIGGER_EN = {
  'แพทย์ไม่ได้ออกตรวจในวัน/เวลานี้': 'The doctor is not on duty at this date/time',
  'แพทย์งดออกตรวจในวันนี้': 'The doctor is on leave this day',
  'ช่องเวลานี้เต็มแล้ว': 'This slot is full'
};
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  if (err.type === 'entity.too.large') err.status = 413;
  const status = err.status || (err.code === 'ER_DUP_ENTRY' ? 409 : err.code === 'ER_SIGNAL_EXCEPTION' ? 400 : 500);
  let message = err.message, message_en = err.messageEn || err.message;
  if (status === 500) { message = 'เกิดข้อผิดพลาดภายในระบบ'; message_en = 'Internal server error'; }
  else if (status === 413) { message = 'ไฟล์มีขนาดใหญ่เกินไป'; message_en = 'Upload is too large'; }
  else if (err.code === 'ER_SIGNAL_EXCEPTION') { message = err.sqlMessage; message_en = TRIGGER_EN[err.sqlMessage] || err.sqlMessage; }
  else if (err.code === 'ER_DUP_ENTRY') { message = 'ข้อมูลนี้มีอยู่ในระบบแล้ว'; message_en = 'This record already exists'; }
  if (process.env.NODE_ENV !== 'production') console.error(err);
  res.status(status).json({ success: false, message, message_en });
}
module.exports = { notFound, errorHandler };
