const db = require('../config/database');

// target: { account: id } | { hospital: id } | 'admin'
async function notify(target, message, linkTab = null, appointmentId = null, connection = db) {
  const type = target === 'admin' ? 'admin' : target.account ? 'account' : 'hospital';
  await connection.execute(
    `INSERT INTO notifications (target_type,target_account_id,target_hospital_id,message,link_tab,appointment_id)
     VALUES (?,?,?,?,?,?)`,
    [type, target.account || null, target.hospital || null, message, linkTab, appointmentId]
  );
}

// Hospital of a staff account (null for admin / unknown)
async function staffHospital(accountId, connection = db) {
  const [rows] = await connection.execute('SELECT hospital_id FROM staff WHERE staff_id=?', [accountId]);
  return rows.length ? rows[0].hospital_id : null;
}

module.exports = { notify, staffHospital };
