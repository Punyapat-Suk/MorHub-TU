const db = require('../config/database');

// Sends an in-app reminder once per appointment, one day before the visit.
async function createAppointmentReminders() {
  const [result] = await db.execute(
    `INSERT INTO notifications (target_type,target_account_id,message,link_tab,appointment_id)
     SELECT 'account',a.patient_id,
       CONCAT('เตือน: คุณมีนัดหมายในวันพรุ่งนี้ เวลา ',TIME_FORMAT(a.appt_time,'%H:%i'),' น.'),
       'appts',a.appointment_id
     FROM appointments a
     WHERE a.status='upcoming' AND a.admin_gate IS NULL
       AND a.appt_date=DATE_ADD(CURDATE(),INTERVAL 1 DAY)
       AND NOT EXISTS (
         SELECT 1 FROM notifications n WHERE n.target_type='account'
           AND n.target_account_id=a.patient_id AND n.appointment_id=a.appointment_id
           AND n.message LIKE 'เตือน: คุณมีนัดหมายในวันพรุ่งนี้%'
       )`
  );
  return result.affectedRows;
}
// Alerts the admin and the hospital once when a booking request has waited more than 24 hours.
async function createStaleRequestAlerts() {
  const [rows] = await db.execute(
    `SELECT a.appointment_id, a.admin_gate, d.hospital_id, ac.full_name,
            TIMESTAMPDIFF(HOUR,a.created_at,NOW()) AS hours
     FROM appointments a JOIN doctors d ON d.doctor_id=a.doctor_id JOIN accounts ac ON ac.account_id=a.patient_id
     WHERE a.status='pending' AND a.created_at < NOW() - INTERVAL 24 HOUR
       AND NOT EXISTS (SELECT 1 FROM notifications n WHERE n.target_type='admin'
         AND n.appointment_id=a.appointment_id AND n.message LIKE 'คำขอจองค้างนาน%')`
  );
  for (const r of rows) {
    await db.execute(`INSERT INTO notifications (target_type,message,link_tab,appointment_id) VALUES ('admin',?,'requests',?)`,
      [`คำขอจองค้างนาน: ${r.full_name} รอมา ${r.hours} ชม.`, r.appointment_id]);
    // The hospital has not received a request the admin has not forwarded yet
    if (r.admin_gate === 'request') continue;
    await db.execute(`INSERT INTO notifications (target_type,target_hospital_id,message,link_tab,appointment_id) VALUES ('hospital',?,?,'requests',?)`,
      [r.hospital_id, `คำขอจองของ ${r.full_name} ค้างเกิน 24 ชม. กรุณายืนยันหรือปฏิเสธ`, r.appointment_id]);
  }
  return rows.length;
}
function startReminderJob() {
  const run = () => Promise.all([createAppointmentReminders(), createStaleRequestAlerts()])
    .catch(err => console.error('Reminder job failed:',err.message));
  run();
  setInterval(run, 15 * 60 * 1000);
}
module.exports = { createAppointmentReminders, createStaleRequestAlerts, startReminderJob };
