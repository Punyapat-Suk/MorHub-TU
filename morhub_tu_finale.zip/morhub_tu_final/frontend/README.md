# MorHub TU frontend — where to find things

Served by the backend at http://localhost:3000 (see the main README). No build step: plain HTML, CSS and JavaScript.

```
frontend/
├── index.html            page shell: loads the CSS and JS files below, in order
└── assets/
    ├── css/              styles, applied in file order (later files override earlier ones)
    └── js/               scripts, loaded in file order (they share one global scope)
```

## I want to change…

| What | File |
| --- | --- |
| Colours, fonts, light/dark mode tokens | css/01-base.css, css/09-theme.css |
| Buttons, cards, tags, pop-up sheet, bottom nav | css/02-components.css |
| Desktop / tablet layout | css/03-responsive.css |
| Login / register page look | css/04-home-auth.css |
| Calendar picker, footer | css/06-landing-calendar-footer.css |
| Top menu, account dropdown, sidebar | css/10-navigation.css |
| Doctor page, Find a Doctor, hospital page | css/11-pages.css |
| Departments, icons, date helpers | js/01-data.js |
| Login and sign-up | js/04-auth.js |
| Patient home, booking, my appointments, results | js/05-patient.js |
| Any pop-up (booking form, report, decline, propose…) | js/06-popups.js |
| Profile pages | js/07-profile.js |
| Staff: doctors, requests, patients, send report | js/08-staff.js |
| Admin: accounts, complaints, all appointments | js/09-admin.js |
| Menus per role, page shell | js/10-layout.js |
| Top bar, search, sidebar, `render()` | js/11-navigation.js |
| Thai / English text | js/12-language.js |
| Talking to the backend (API calls, data mapping, start-up) | js/13-api.js |

## Rules when editing

- **Keep the load order.** Files are numbered because order matters: a later CSS file overrides an earlier one, and a JS file can only use, while it loads, what earlier files defined.
- **13-api.js loads last.** It replaces the old localStorage functions in 03-storage.js and the actions that change data with calls to `/api`. To change what a button saves, look in 13-api.js first.
- **Text from the API is HTML-escaped in 13-api.js** before the screens show it. Keep it that way; the screens insert text with `innerHTML`.
