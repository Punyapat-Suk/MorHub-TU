/* Old localStorage storage, notifications, slot helpers, toast (storage parts are replaced by 13-api.js) */
/* ===== persistence: data shared across tabs (localStorage), login per tab (sessionStorage) ===== */
const KEY='morhubtu_data_v1',SKEY='morhubtu_session_v2';let STORE_OK=true,lastRaw='',pendingRemote=false;
function snapshot(){return {HOSPS,ACCTS,DOCS,BOOKS,REPORTS,TICKETS,NOTIFS,_bid,_rid,_tid,_nid}}
function saveData(){
  if(!STORE_OK)return;
  try{const raw=JSON.stringify({v:1,d:snapshot()});if(raw===lastRaw)return;localStorage.setItem(KEY,raw);lastRaw=raw}
  catch(e){if(!S.quotaWarned){S.quotaWarned=true;setTimeout(()=>toast('พื้นที่เก็บข้อมูลเต็ม ไฟล์แนบขนาดใหญ่อาจไม่ถูกบันทึก ลองแนบรูปให้น้อยลง'),0)}}
}
function loadData(){
  if(!STORE_OK)return false;
  try{
    const raw=localStorage.getItem(KEY);if(!raw||raw===lastRaw)return false;
    const o=JSON.parse(raw);const d=o&&o.d;
    if(!d||!['HOSPS','ACCTS','DOCS','BOOKS','REPORTS','TICKETS','NOTIFS'].every(k=>Array.isArray(d[k])))return false;
    HOSPS=d.HOSPS;ACCTS=d.ACCTS;DOCS=d.DOCS;BOOKS=d.BOOKS;REPORTS=d.REPORTS;TICKETS=d.TICKETS;NOTIFS=d.NOTIFS;
    _bid=d._bid;_rid=d._rid;_tid=d._tid;_nid=d._nid;lastRaw=raw;return true;
  }catch(e){return false}
}
function saveSession(){try{if(S.user)sessionStorage.setItem(SKEY,JSON.stringify({uid:S.user.id,tab:S.tab,view:S.view,imp:S.imp||null}));else sessionStorage.removeItem(SKEY)}catch(e){}}
function restoreSession(){
  try{const o=JSON.parse(sessionStorage.getItem(SKEY)||'null');if(!o)return;
    const a=ACCTS.find(x=>x.id===o.uid);if(!a||!a.on||a.pending)return;
    if(o.imp){const ad=ACCTS.find(x=>x.id===o.imp.adminId);if(!ad||ad.role!=='admin'||!ad.on)return;S.imp=o.imp}
    S.user=a;S.role=a.role;S.tab=NAVS[a.role].some(t=>t[0]===o.tab)?o.tab:NAVS[a.role][0][0];S.view=o.view||'card';
  }catch(e){}
}
const typing=()=>{const e=document.activeElement;return !!(e&&/^(INPUT|TEXTAREA|SELECT)$/.test(e.tagName))};
function applyRemote(){
  if(!loadData())return;
  if(S.user){const a=ACCTS.find(x=>x.id===S.user.id);S.user=a||null;if(!a)S.role=null}
  if(!S.user&&S.auth)return;
  if(typing()){pendingRemote=true;return}
  render();
}
function resetData(){try{localStorage.removeItem(KEY);sessionStorage.removeItem(SKEY)}catch(e){}location.reload()}
function initStore(){
  try{localStorage.setItem('medhub_probe','1');localStorage.removeItem('medhub_probe')}catch(e){STORE_OK=false}
  if(STORE_OK){if(!loadData())saveData()}
  DOCS.forEach(d=>{if(!d.eduSeeded&&d.edu===undefined&&d.eduTh===undefined){const e=eduFor(d);d.edu=e.en;d.eduTh=e.th}d.eduSeeded=true});saveData();
  ACCTS.forEach(a=>{if(a.name&&a.name.includes('MedHub'))a.name=a.name.replace('MedHub','MorHub');if(a.co&&a.co.includes('MedHub'))a.co=a.co.replace('MedHub','MorHub')});
  restoreSession();
  window.addEventListener('storage',e=>{if(e.key===KEY)applyRemote()});
  setInterval(()=>{if(S.user&&S.role==='admin'&&S.tab==='requests'&&!S.sheet&&!typing())render()},20000);
  setInterval(()=>{if(checkStale()&&!typing())render()},60000);
  window.addEventListener('focus',applyRemote);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)applyRemote()});
  document.addEventListener('focusout',()=>{if(pendingRemote)setTimeout(()=>{if(!typing()){pendingRemote=false;render()}},60)});
}
function notify(to,text,tab,extra){NOTIFS.push({id:_nid++,to,text,tab:tab||'',at:Date.now(),readBy:[],...(extra||{})})}
function fillAt(){
  BOOKS.forEach((b,i)=>{if(b.at)return;const t=apptAt(b).getTime();b.at=Math.min(t-(3+i%4)*864e5,Date.now()-(12+i)*36e5)});
}
function checkStale(){
  let n=0;
  BOOKS.forEach(b=>{
    if(!isStale(b)||b.staleNoti)return;
    b.staleNoti=true;n++;
    const d=doc(b.doc),p=acct(b.pt);
    notify('admin',`คำขอจองค้างนาน: ${p.name} รอมา ${waitH(b)} ชม.`,'requests',{rq:'stale'});
    notify('h:'+d.hid,`คำขอจองของ ${p.name} ค้างเกิน 24 ชม. กรุณายืนยันหรือปฏิเสธ`,'requests');
  });
  return n;
}
function myNotifs(){const u=S.user;return NOTIFS.filter(n=>n.to==='u:'+u.id||(u.role==='tech'&&n.to==='h:'+u.hid)||(u.role==='admin'&&n.to==='admin')).sort((a,b)=>b.at-a.at)}
const unreadN=()=>myNotifs().filter(n=>!n.readBy.includes(S.user.id)).length;
function openNotifs(){S.sheet={t:'notifs'};render()}
function readN(id){const n=NOTIFS.find(x=>x.id===id);if(!n.readBy.includes(S.user.id))n.readBy.push(S.user.id);S.sheet=null;if(n.rq&&S.role==='admin')S.rqS=n.rq;if(n.tab)go(n.tab);else render()}
function readAll(){myNotifs().forEach(n=>{if(!n.readBy.includes(S.user.id))n.readBy.push(S.user.id)});render()}
const hospTel=id=>{const h=HOSPS.find(x=>x.id===id);return h&&h.tel?' · โทร '+h.tel:''};
function schedConflicts(d){return BOOKS.filter(b=>b.doc===d.id&&['pending','upcoming'].includes(b.status)&&!isPast(b)&&(!d.wd.includes(new Date(b.date+'T00:00').getDay())||!slotTimes(d,'all').includes(b.time))).length}
const slotOf=b=>b.status==='proposed'&&b.prop?b.prop:b;
const isStale=b=>b.status==='pending'&&b.at&&(Date.now()-b.at)>24*36e5;
const waitH=b=>Math.floor((Date.now()-b.at)/36e5);
const ago=ms=>{const h=Math.floor((Date.now()-ms)/36e5);return h<1?'เมื่อสักครู่':h<24?h+' ชม.ที่แล้ว':Math.floor(h/24)+' วันที่แล้ว'};
const pTag=b=>{
  if(b.status==='pending')return isPast(b)?'<span class="tag bad">ไม่ได้รับการยืนยัน</span>':`<span class="tag amber">${b.gate==='request'?'รอแอดมินตรวจสอบ':'รอโรงพยาบาลยืนยัน'}</span>`;
  if(b.status==='proposed')return isPast(b.prop)?'<span class="tag bad">ข้อเสนอหมดอายุ</span>':'<span class="tag amber">โรงพยาบาลเสนอเปลี่ยนนัด</span>';
  if(b.status==='upcoming'&&b.visited)return `<span class="tag amber">${b.gate==='visit'?'ยืนยันมาตรวจแล้ว · รอแอดมิน':'รอผลตรวจและยาจากโรงพยาบาล'}</span>`;
  if(b.status==='upcoming')return isPast(b)?'<span class="tag amber">รอสถานะจากโรงพยาบาล</span>':'<span class="tag ok">ยืนยันแล้ว</span>';
  return stTag(b)};
const noshowAll=pt=>BOOKS.filter(b=>b.pt===pt&&b.status==='noshow').length;
const noshow90=pt=>BOOKS.filter(b=>b.pt===pt&&b.status==='noshow'&&b.date>=addDays(-90)).length;

function slotTimes(d,per){
  const ts=[];
  [[d.s1,d.e1],[d.s2,d.e2]].forEach(([a,b])=>{ if(!a||!b)return; for(let m=toM(a);m+30<=toM(b);m+=30){ if(per==='am'&&m>=720)continue; if(per==='pm'&&m<720)continue; if(/^\d\d:\d\d$/.test(per)&&fm(m)!==per)continue; ts.push(fm(m)) } });
  return [...new Set(ts)].sort();
}
function slots(d,date,per){
  const wd=new Date(date+'T00:00').getDay(); if(!d.wd.includes(wd))return [];
  const cap=d.cap||1;
  return slotTimes(d,per).map(t=>{const used=BOOKS.filter(b=>{if(b.status==='cancelled')return false;const o=slotOf(b);return o.doc===d.id&&o.date===date&&o.time===t}).length;const left=Math.max(cap-used,0);return {t,left,free:left>0}});
}
let toastT=null;
function toast(m){
  S.toast=m;
  let el=document.getElementById('toastEl');
  if(!el){el=document.createElement('div');el.id='toastEl';el.className='toast';el.setAttribute('role','status');document.body.appendChild(el)}
  el.textContent=m;
  clearTimeout(toastT);toastT=setTimeout(()=>{S.toast=null;const e=document.getElementById('toastEl');if(e)e.remove()},2000);
}

