/* Top bar, About Us menu, doctor schedule page, hospital page, site search, sidebar, render() */
/* ---------- top bar: About Us, Doctor Schedule, search ---------- */
const topLinksOn=()=>!S.user||S.role==='patient'||S.role==='tech';
function aboutMenu(){
  const it=(i,l,fn)=>`<button role="menuitem" class="pm-item" onclick="${fn}">${ic(i,20)}<span>${l}</span></button>`;
  return `<div class="pscrim" onclick="toggleAbout()"></div><div class="pmenu amenu" role="menu">${it('building','ข้อมูลโรงพยาบาล',"S.aboutOpen=false;openHospPage()")}${it('calendar','วิธีการจอง',"S.aboutOpen=false;openInfo('howto')")}${it('file-text','คำถามที่พบบ่อย',"S.aboutOpen=false;openInfo('faq')")}</div>`;
}
const aboutInner=()=>`<button class="tbtn" onclick="toggleAbout()" aria-haspopup="menu" aria-expanded="${!!S.aboutOpen}">เกี่ยวกับเรา<span class="chev">${ic('chevron-down',16)}</span></button>`+(S.aboutOpen?aboutMenu():'');
function toggleAbout(){S.aboutOpen=!S.aboutOpen;document.querySelectorAll('.aboutw').forEach(e=>{e.innerHTML=aboutInner()})}
const onSchedule=()=>!!S.docPage;
const topLinks=()=>topLinksOn()?`<div class="toplinks"><div class="aboutw">${aboutInner()}</div><button class="tbtn ${onSchedule()?'on':''}" onclick="goSchedule()">ตารางแพทย์</button></div>`:'';
const searchBtn=()=>topLinksOn()?`<button class="searchbtn ${S.searchPage?'on':''}" onclick="openSearch()" aria-label="ค้นหา" title="ค้นหา">${ic('search',20)}</button>`:'';
function goSchedule(){
  S.aboutOpen=false;S.searchPage=false;S.hospPage=false;
  S.sheet=null;S.menuOpen=false;if(S.user){S.tab='home'}S.sub=null;S.docPage=true;S.dq='';S.dd='';S.backTo=null;render();window.scrollTo(0,0);
}
function dpList(){
  const q=(S.dq||'').trim().toLowerCase(),sel=S.dd||'';
  return DOCS.filter(d=>(!sel||d.dept===sel)&&(!q||srMatch(d,q))).sort((a,b)=>DEPTS.findIndex(x=>x.id===a.dept)-DEPTS.findIndex(x=>x.id===b.dept)||a.name.localeCompare(b.name,'th'));
}
function dpOut(){
  const l=dpList();
  const cards=l.map(d=>{const i=Math.max(0,DEPTS.findIndex(x=>x.id===d.dept));return `<article class="dcard"><div class="dphoto" style="--h:${196+i*7}">${d.img?`<img class="dimg" src="${d.img}" alt="${d.name}">`:ic('user',76)}</div><b>${d.name}</b><span class="small">${dept(d.dept).n}</span><button class="btn sm dinfo" onclick="dpOpen(${d.id})">ข้อมูลแพทย์</button></article>`}).join('');
  return `<div class="spcount">${l.length} ผลลัพธ์</div>${l.length?`<div class="dcards">${cards}</div>`:'<div class="empty">ไม่พบผลการค้นหา</div>'}`;
}
function dpRowHtml(){const sel=S.dd||'';return `<button class="dept ${!sel?'on':''}" onclick="dpDept('')"><i>${ic('grid',26)}</i>ทั้งหมด</button>`+DEPTS.map(d=>`<button class="dept ${sel===d.id?'on':''}" style="${dStyle(d.id)}" onclick="dpDept('${d.id}')"><i>${ic(d.ic,26)}</i>${d.n}</button>`).join('')}
function dpRefresh(){const o=document.getElementById('dp_out');if(o)o.innerHTML=dpOut();const r=document.getElementById('dpRow');if(r)r.innerHTML=dpRowHtml()}
function dpDept(id){S.dd=id;dpRefresh()}
function dpOpen(id){S.backTo='doc';openDoc(id)}
function doctorPage(){
  if(S.docForm)return docFormView();
  return `<div class="spage dpage"><h1>ค้นหาแพทย์</h1><div class="spbox"><input id="dp_q" type="search" placeholder="ค้นหาด้วยชื่อ หรือสาขา" value="${(S.dq||'').replace(/"/g,'&quot;')}" oninput="S.dq=this.value;dpRefresh()" autocomplete="off">${ic('search',22)}</div>
   <div class="dpbar"><span></span><b class="small">หรือเลือกตามบริการ</b>${S.user&&S.role==='tech'?`<button class="btn dpadd" onclick="startAddDoc()">${ic('plus',16)} เพิ่มแพทย์</button>`:'<span></span>'}</div><div class="dgrid" id="dpRow">${dpRowHtml()}</div><div id="dp_out">${dpOut()}</div></div>`;
}
function openHospPage(){S.aboutOpen=false;S.sheet=null;S.searchPage=false;S.hospPage=true;S.docPage=false;render();window.scrollTo(0,0)}
function hospitalPage(){
  const h=HOSPS[0],hue=(170+h.id*15)%360,docs=DOCS.filter(d=>d.hid===h.id);
  const row=(i,l,v)=>`<div class="hrow"><span class="hic">${i}</span><div><div class="small">${l}</div><div>${v||'—'}</div></div></div>`;
  const tiles=DEPTS.map(d=>{const n=docs.filter(x=>x.dept===d.id).length;return `<button class="dtile" style="${dStyle(d.id)}" onclick="srDept('${d.id}')">${ic(d.ic,26)}<b>${d.n}</b><span class="small">${LANG==='en'?n+(n===1?' doctor':' doctors'):'แพทย์ '+n+' ท่าน'}</span></button>`}).join('');
  return `<div class="hpage">${hospHero(h,S.user&&S.role==='tech'?'tech':'view')}
   <h2>แผนกและบริการ</h2><div class="dtiles">${tiles}</div>
</div>`;
}
function howSteps(){
  const it=[['เลือกแผนก','เลือกแผนกและวันที่ ปฏิทินจะกดได้เฉพาะวันที่มีแพทย์ตรวจ'],['เลือกวันและช่วงเวลาที่ว่าง','เลือกเวลาที่ว่าง ดูข้อมูลได้โดยไม่ต้องเข้าสู่ระบบ'],['เข้าสู่ระบบเพื่อส่งคำขอจอง','เข้าสู่ระบบหรือสมัครสมาชิกเพื่อยืนยันการส่งคำขอ'],['รอโรงพยาบาลยืนยันนัด','โรงพยาบาลอาจเสนอเปลี่ยนแพทย์หรือวันนัด คุณจะได้รับแจ้งเตือน'],['พบแพทย์และรับผลตรวจ','หลังตรวจ โรงพยาบาลส่งผลตรวจ ยา และใบนัดต่อ (ถ้ามี) ให้ในแอป']];
  return `<div class="steps vsteps">${it.map(([t,d],i)=>`<div><b>${i+1}</b><div><div>${t}</div><div class="small">${d}</div></div></div>`).join('')}</div>`;
}
function openSearch(){S.aboutOpen=false;S.sheet=null;S.searchPage=true;S.hospPage=false;S.docPage=false;S.srq='';render();window.scrollTo(0,0);setTimeout(()=>{const i=document.getElementById('sp_q');if(i)i.focus()},60)}
const SR_INFO=[['hospital','building','ข้อมูลโรงพยาบาล','ที่อยู่ เบอร์โทร เวลาทำการ hospital address phone hours contact location'],['howto','calendar','วิธีการจอง','จอง นัด ขั้นตอน how to book appointment steps'],['faq','file-text','คำถามที่พบบ่อย','ถามตอบ faq question help'],['privacy','key','ข้อมูลและความเป็นส่วนตัว','pdpa privacy data security']];
function searchPage(){
  return `<div class="spage"><h1>ค้นหาทั้งเว็บไซต์</h1><div class="spbox"><input id="sp_q" type="search" placeholder="ค้นหาแพทย์ แผนก บริการ และอื่น ๆ..." value="${(S.srq||'').replace(/"/g,'&quot;')}" oninput="S.srq=this.value;spRefresh()" autocomplete="off">${ic('search',22)}</div><div id="sp_out">${spResults()}</div></div>`;
}
function spRefresh(){const e=document.getElementById('sp_out');if(e)e.innerHTML=spResults()}
function spPt(id){S.searchPage=false;S.hospPage=false;S.docPage=false;go('patients');openPt(id)}
function spResults(){
  const q=(S.srq||'').trim().toLowerCase(),staff=S.user&&S.role==='tech',en=t=>LANG==='en'?tx(t):'';
  if(!q)return '';
  const docs=DOCS.filter(d=>srMatch(d,q)),depts=DEPTS.filter(d=>[d.n,en(d.n)].join(' ').toLowerCase().includes(q)),info=SR_INFO.filter(x=>[x[2],en(x[2]),x[3]].join(' ').toLowerCase().includes(q));
  const pts=staff?myPatients().filter(e=>[e.p.name,en(e.p.name),e.p.hn||'',e.p.phone||''].join(' ').toLowerCase().includes(q)):[];
  const total=docs.length+depts.length+info.length+pts.length;
  const row=(av,title,sub,tag,fn)=>`<div class="lrow click" style="cursor:pointer" onclick="${fn}"><div class="av">${av}</div><div class="lm"><b>${title}</b>${sub?`<div class="small">${sub}</div>`:''}</div><div class="lr">${tag?`<span class="tag">${tag}</span>`:''}<span aria-hidden="true">›</span></div></div>`;
  const grp=(t,l)=>l.length?`<h2>${t} (${l.length})</h2><div class="lrows">${l.join('')}</div>`:'';
  if(!total)return `<div class="spcount">0 ผลลัพธ์</div><div class="empty">ไม่พบผลการค้นหา</div>`;
  return `<div class="spcount">${total} ผลลัพธ์</div>`
   +grp('แพทย์',docs.map(d=>row(docAv(d),d.name,dept(d.dept).n,'ดูตารางและจอง',`srOpen(${d.id})`)))
   +grp('แผนกและบริการ',depts.map(d=>row(ic(d.ic,20),d.n,'','',`srDept('${d.id}')`)))
   +grp('ข้อมูลทั่วไป',info.map(x=>row(ic(x[1],20),x[2],'','',x[0]==='hospital'?'openHospPage()':`openInfo('${x[0]}')`)))
   +grp('รายชื่อผู้ป่วย',pts.map(e=>row(initial(e.p.name),e.p.name,[e.p.hn,e.p.phone].filter(Boolean).join(' · '),'',`spPt(${e.id})`)));
}
const srMatch=(d,q)=>{const dn=dept(d.dept).n;return [d.name,dn,LANG==='en'?tx(d.name):'',LANG==='en'?tx(dn):''].join(' ').toLowerCase().includes(q)};
function srList(){
  const q=((document.getElementById('sr_in')||{}).value||'').trim().toLowerCase();
  const l=q?DOCS.filter(d=>srMatch(d,q)):[];
  if(!q)return '';
  return l.length?`<div class="lrows" style="margin:10px 0 0">${l.slice(0,8).map(d=>`<div class="lrow click" style="cursor:pointer" onclick="srOpen(${d.id})"><div class="av">${docAv(d)}</div><div class="lm"><b>${d.name}</b><div class="small">${dept(d.dept).n}</div></div><div class="lr"><span class="tag">${S.user&&S.role==='tech'?'ดูตารางงาน':'ดูตารางและจอง'}</span></div></div>`).join('')}</div>${l.length>8?`<div class="small" style="margin-top:8px;text-align:center">${l.length} รายการ</div>`:''}`:'<div class="empty">ไม่พบผลการค้นหา</div>';
}
function srRefresh(){const e=document.getElementById('sr_out');if(e)e.innerHTML=srList()}
function srOpen(id){S.searchPage=false;S.hospPage=false;S.docPage=false;
  S.sheet=null;S.f.dept='';if(S.user)S.tab='home';S.sub=null;openDoc(id)}
function srDept(id){S.searchPage=false;S.hospPage=false;S.docPage=false;
  S.sheet=null;S.menuOpen=false;if(S.user)S.tab='home';S.sub=null;S.docPage=true;S.dq='';S.dd=id;S.backTo=null;render();window.scrollTo(0,0);return}
function srDeptOld(id){
  S.sheet=null;S.sub=null;S.f.dept=id;if(S.user)S.tab='home';render();setTimeout(()=>{const l=document.getElementById('homeList');if(l)l.scrollIntoView({behavior:'smooth',block:'start'})},80)}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&S.aboutOpen)toggleAbout()});

let DOTS={};
const menuPages=r=>NAVS[r].filter(([k])=>k!=='home'&&k!=='profile');
function editProfile(){go('profile');S.editProfile=true;render()}
const editOn=()=>S.tab==='profile';
function goHome(){
  S.searchPage=false;S.hospPage=false;S.docPage=false;
  if(!S.user){S.sub=null;S.sheet=null;render();window.scrollTo(0,0);return}
  go(NAVS[S.role][0][0]);
}
function sideHtml(){
  const u=S.user,r=S.role,col=!!S.sideCol;
  if(col)return `<span class="sidehandle" role="button" tabindex="0" aria-label="ขยายเมนู" title="ขยายเมนู" onclick="toggleSide()" onkeydown="if(event.key==='Enter'||event.key===' ')toggleSide()">${ic('chevron-right',16)}</span>`;
  const items=menuPages(r).map(([k,i,l])=>`<button class="sidebtn ${S.tab===k?'on':''}" onclick="go('${k}')" title="${l}">${ic(i,20)}<span>${l}</span>${DOTS[k]?`<em class="dot">${DOTS[k]}</em>`:''}</button>`).join('');
  return `<div class="sp">${avatarHtml(u,col?36:48)}<div class="spt"><b>${u.name}</b><small>${ROLES[u.role]}</small></div><button class="sidetoggle" onclick="toggleSide()" aria-label="${col?'ขยายเมนู':'ย่อเมนู'}" title="${col?'ขยายเมนู':'ย่อเมนู'}">${ic(col?'chevron-right':'chevron-left',18)}</button></div>${items}<div class="side-sep"></div><button class="sidebtn ${editOn()?'on':''}" onclick="editProfile()" title="แก้ไขโปรไฟล์">${ic('settings',20)}<span>แก้ไขโปรไฟล์</span></button><button class="sidebtn pm-out" onclick="logout()" title="ออกจากระบบ">${ic('power',20)}<span>ออกจากระบบ</span></button>`;
}
function toggleSide(){
  S.sideCol=!S.sideCol;try{localStorage.setItem('morhubtu_side',S.sideCol?'1':'0')}catch(e){}
  const a=document.querySelector('.side'),sh=document.querySelector('.shell');
  if(a){a.classList.toggle('col',S.sideCol);a.innerHTML=sideHtml()}
  if(sh)sh.classList.toggle('sc',S.sideCol);
}
function profBtn(){return `<button class="prof ${S.tab==='profile'?'on':''}" onclick="profClick()" aria-haspopup="menu" aria-expanded="${!!S.menuOpen}" aria-label="บัญชีของฉัน: ${S.user.name}">${avatarHtml(S.user,26)}<span class="pn1">${S.user.name.split(' ')[0]}</span><span class="pn2">${S.user.name}</span><span class="chev">${ic('chevron-down',16)}</span></button>`}
function profMenu(){
  const r=S.role,u=S.user;
  const items=menuPages(r).map(([k,i,l])=>`<button role="menuitem" class="pm-item ${S.tab===k?'on':''}" onclick="go('${k}')">${ic(i,20)}<span>${l}</span>${DOTS[k]?`<em class="dot">${DOTS[k]}</em>`:''}</button>`).join('');
  return `<div class="pscrim" onclick="toggleProfMenu()"></div><div class="pmenu" role="menu"><div class="pm-head"><b>${u.name}</b><span>${ROLES[u.role]}${u.hid?' · '+hn(u.hid):''}</span></div>${items}<div class="pm-sep"></div><button role="menuitem" class="pm-item ${editOn()?'on':''}" onclick="editProfile()">${ic('settings',20)}<span>แก้ไขโปรไฟล์</span></button><button role="menuitem" class="pm-item pm-out" onclick="logout()">${ic('power',20)}<span>ออกจากระบบ</span></button></div>`;
}
const profInner=()=>profBtn()+(S.menuOpen?profMenu():'');
function profClick(){if(innerWidth>=900)toggleProfMenu();else go('profile')}
function toggleProfMenu(){S.menuOpen=!S.menuOpen;document.querySelectorAll('.profw').forEach(e=>{e.innerHTML=profInner()})}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&S.menuOpen)toggleProfMenu()});
function render(){
  fillAt();checkStale();saveData();saveSession();
  const a=document.getElementById('app');a.classList.toggle('imp',!!S.imp);
  if(!S.user||!S.user.on){
    S.user=null;S.role=null;
    a.innerHTML=S.auth?loginView()+`<div class="langw langpos">${langInner()}</div>`:guestBar()+guestBody()+sheetView();return}
  const r=S.role,dots={};
  if(r==='patient'){dots.results=unseen();dots.appts=BOOKS.filter(b=>b.pt===S.user.id&&b.status==='proposed'&&!isPast(b.prop)).length}
  if(r==='tech'){dots.requests=myBooks().filter(b=>b.status==='pending').length;dots.patients=0}
  if(r==='admin'){dots.accts=ACCTS.filter(x=>x.pending).length;dots.requests=BOOKS.filter(isStale).length;dots.issues=TICKETS.filter(t=>t.status==='open').length}
  DOTS=dots;const un=unreadN(),tabs=NAVS[r].map(([k,i,l])=>k==='profile'?`<button class="prof ${S.tab===k?'on':''}" onclick="go('profile')" aria-label="บัญชีของฉัน: ${S.user.name}">${avatarHtml(S.user,26)}<span class="pn1">${S.user.name.split(' ')[0]}</span><span class="pn2">${S.user.name}</span></button>`:`<button class="${S.tab===k?'on':''}" onclick="go('${k}')"><i>${ic(i,22)}</i>${l}${dots[k]?`<em class="dot">${dots[k]}</em>`:''}</button>`);
  const bell=`<button class="bellbtn" onclick="openNotifs()" aria-label="การแจ้งเตือน"><i>${ic('bell',20)}</i>${un?`<em class="dot">${un}</em>`:''}</button>`;
  a.innerHTML=impBar()+body()+sheetView()+`<div class="langw langf">${langInner()}</div><button class="bell-f" onclick="openNotifs()" aria-label="การแจ้งเตือน">${ic('bell',20)}${un?`<em class="dot">${un}</em>`:''}</button><nav class="nv${NAVS[r].length}"><div class="brand" role="button" tabindex="0" aria-label="${APP_NAME}" onclick="goHome()" onkeydown="if(event.key==='Enter'||event.key===' ')goHome()"><span class="bl">${ic('heart-plus',22)}</span>${APP_NAME}</div>${topLinks()}${tabs.slice(0,-1).join('')}${searchBtn()}${bell}<div class="langw navlang">${langInner()}</div><div class="profw">${profInner()}</div></nav>`;
}

