/* Admin: requests overview, all appointments, accounts, complaints, act-as */
/* ================= ADMIN ================= */
/* Admin is the middle step: patient -> admin -> hospital, hospital -> admin -> patient,
   patient's "I visited" -> admin -> hospital, report -> admin -> patient */
function adminInbox(){
  const held=new Set(REPORTS.filter(r=>!r.ok&&r.next).map(r=>r.next.bk));   // follow-ups go out with their report
  const rq=BOOKS.filter(b=>b.gate==='request'&&b.status==='pending').sort((a,b)=>(a.at||0)-(b.at||0));
  const rp=BOOKS.filter(b=>b.gate==='reply'&&!held.has(b.id)).sort((a,b)=>(a.at||0)-(b.at||0));
  const vs=BOOKS.filter(b=>b.gate==='visit').sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time));
  const rs=REPORTS.filter(r=>!r.ok).sort((a,b)=>a.id-b.id);
  const f=S.ibF||'request';
  const st=(k,n,t)=>`<div class="stat ${n?'warnc':''} ${f===k?'sel':''}" role="button" tabindex="0" style="cursor:pointer" onclick="S.ibF='${k}';render()"><b>${n}</b><span class="small">${t}</span></div>`;
  const head=b=>{const d=doc(b.doc);return `<div style="display:flex;justify-content:space-between;gap:8px"><b>${acct(b.pt).name}</b><span class="small">${b.at?ago(b.at):''}</span></div><div class="small" style="margin-top:2px">${d.name} · ${dept(d.dept).n} · ${hn(d.hid)}</div><div class="small">นัด ${fmtD(b.date)} ${b.time}</div>`};
  const answer=b=>b.status==='proposed'&&b.prop?['amber',`โรงพยาบาลเสนอเวลาใหม่: ${doc(b.prop.doc).name} ${fmtD(b.prop.date)} ${b.prop.time}${b.prop.reason?' · '+b.prop.reason:''}`]
    :b.status==='cancelled'?['bad',`โรงพยาบาลปฏิเสธ/ยกเลิก · เหตุผล: ${b.reason||'-'}`]:['ok','โรงพยาบาลยืนยันนัดแล้ว'];
  const btns=h=>`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">${h}</div>`;
  const rqCard=b=>`<div class="card">${head(b)}${b.note?`<p class="small" style="margin-top:6px">อาการ: ${b.note}</p>`:''}${btns(`<button class="btn sm" onclick="fwdReq(${b.id})">${ic('check',15)} ส่งต่อให้ รพ.</button><button class="btn danger sm" onclick="S.sheet={t:'decline',id:${b.id}};render()">ปฏิเสธ</button>`)}</div>`;
  const rpCard=b=>{const [c,t]=answer(b);return `<div class="card">${head(b)}<div class="chips" style="margin-top:8px"><span class="tag ${c}">${t}</span></div>${btns(`<button class="btn sm" onclick="releaseReply(${b.id})">${ic('check',15)} ส่งให้ผู้ป่วย</button>`)}</div>`};
  const vsCard=b=>`<div class="card">${head(b)}<div class="chips" style="margin-top:8px"><span class="tag ok">ผู้ป่วยยืนยันว่ามาตรวจแล้ว</span></div>${btns(`<button class="btn sm" onclick="fwdReq(${b.id})">${ic('check',15)} ส่งต่อให้ รพ. เพื่อส่งผลตรวจและยา</button>`)}</div>`;
  const rsCard=r=>{const d=r.doc?doc(r.doc):null;return `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><b>${acct(r.pt).name}</b><span class="small">วันที่ตรวจ ${fmtD(r.vdate)}</span></div><div class="small">${d?d.name+' · ':''}${hn(r.hid)} · ส่งโดย ${r.by||'-'}</div><p style="margin-top:6px">การวินิจฉัย: ${r.dx}</p><div class="small">ยา: ${r.meds.length?r.meds.map(m=>m.n+(m.d?' ('+m.d+')':'')).join(', '):'ไม่มี'}${r.next?` · นัดติดตาม ${fmtD(r.next.date)} ${r.next.time}`:''}</div>${btns(`<button class="btn sm" onclick="approveReport(${r.id})">${ic('check',15)} อนุมัติและส่งให้ผู้ป่วย</button><button class="btn sec sm" onclick="S.sheet={t:'report',id:${r.id}};render()">ดูรายงานเต็ม</button>`)}</div>`};
  const [l,card,empty]={request:[rq,rqCard,'ไม่มีคำขอใหม่จากผู้ป่วย'],reply:[rp,rpCard,'ไม่มีคำตอบจากโรงพยาบาลที่รอส่ง'],visit:[vs,vsCard,'ไม่มีผู้ป่วยที่ยืนยันมาตรวจรอส่งต่อ'],report:[rs,rsCard,'ไม่มีรายงานที่รออนุมัติ']}[f];
  return `<h2 style="margin-top:6px">รอแอดมินดำเนินการ</h2><div class="stats">${st('request',rq.length,'คำขอใหม่ → ส่งต่อ รพ.')}${st('reply',rp.length,'คำตอบ รพ. → ส่งผู้ป่วย')}${st('visit',vs.length,'มาตรวจแล้ว → ส่งต่อ รพ.')}${st('report',rs.length,'ผลตรวจ/ยา → อนุมัติ')}</div>`+
    (l.length?l.map(card).join(''):`<div class="empty">${empty}</div>`)+'<h2>คำขอที่อยู่กับโรงพยาบาล</h2>';
}
function adminRequests(){
  const L=S.view==='list',hf=S.rqH||'',sf=S.rqS||'all';
  const open=BOOKS.filter(b=>['pending','proposed'].includes(b.status)&&!b.gate);
  const cP=open.filter(b=>b.status==='pending').length,cR=open.filter(b=>b.status==='proposed').length,cS=open.filter(isStale).length;
  let l=open.filter(b=>sf==='all'||(sf==='stale'?isStale(b):b.status===sf)).filter(b=>!hf||String(doc(b.doc).hid)===hf);
  l.sort((a,b)=>(isStale(b)?1:0)-(isStale(a)?1:0)||(a.at||0)-(b.at||0));
  const wait=b=>b.at?`รอมา ${waitH(b)<1?'< 1':waitH(b)} ชม.`:'';
  const tags=b=>`${stTag(b)}${isStale(b)?'<span class="tag bad">ค้างเกิน 24 ชม.</span>':''}`;
  const sub=b=>{const d=doc(b.doc),x=b.status==='proposed'&&b.prop?` → เสนอ ${doc(b.prop.doc).name} ${fmtD(b.prop.date)} ${b.prop.time}`:'';return `${d.name} · ${dept(d.dept).n} · ${fmtD(b.date)} ${b.time}${x}`};
  const card=b=>`<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><b>${acct(b.pt).name}</b><span class="small">${wait(b)}</span></div><div class="small" style="margin-top:2px">${sub(b)}</div><div class="chips" style="margin-top:8px">${tags(b)}</div></div>`;
  const rowL=b=>`<div class="lrow wrap"><div class="av">${initial(acct(b.pt).name)}</div><div class="lm"><b>${acct(b.pt).name}</b><div class="small">${sub(b)}</div><div class="small">${wait(b)}</div></div><div class="lr">${tags(b)}</div></div>`;
  const st=(n,t,k,c)=>`<div class="stat ${c||''}" role="button" tabindex="0" style="cursor:pointer" onclick="S.rqS='${k}';render()"><b>${n}</b><span class="small">${t}</span></div>`;
  return `<div class="top"><h1>คำขอ/นัดหมาย</h1></div>${adminInbox()}
  <div class="stats">${st(cP,'รอ รพ.ยืนยัน','pending')}${st(cR,'รอผู้ป่วยตอบรับ','proposed')}${st(cS,'ค้างเกิน 24 ชม.','stale',cS?'alert':'')}</div>
  <div class="pad" style="margin-top:10px"><div class="seg">${[['all','ทั้งหมด',''],['pending','รอ รพ.('+cP+')',''],['proposed','รอผู้ป่วย('+cR+')',''],['stale','ค้างนาน('+cS+')','hot']].map(([k,v,c])=>`<button class="${c} ${sf===k?'on':''}" onclick="S.rqS='${k}';render()">${v}</button>`).join('')}</div></div>
  <div class="pad lhead2"><span class="small">${l.length} รายการ · อัปเดตอัตโนมัติ ${new Date().toLocaleTimeString(LOC(),{hour:'2-digit',minute:'2-digit'})}</span>${viewToggle()}</div>`+
  (l.length?(L?`<div class="lrows">${l.map(rowL).join('')}</div>`:l.map(card).join('')):'<div class="empty">ไม่มีคำขอจองที่ค้างอยู่</div>')+allAppointments();
}
function setViewR(v){S.viewR=v;render()}
const AP_ST=[['all','ทั้งหมด',()=>true],['upcoming','รอตรวจ',b=>b.status==='upcoming'],['seen','ตรวจแล้ว',b=>b.status==='seen'],['noshow','ไม่มาตามนัด',b=>b.status==='noshow'],['cancelled','ยกเลิกแล้ว',b=>b.status==='cancelled'],['wait','รอยืนยัน',b=>b.status==='pending'||b.status==='proposed']];
const apBase=()=>{const hf=S.rqH||'';return BOOKS.filter(b=>!hf||String(doc(b.doc).hid)===hf)};
const AP_SORT={
  in_desc:['เข้ามาล่าสุด',(a,b)=>(b.at||0)-(a.at||0)||b.id-a.id],
  in_asc:['เข้ามาเก่าสุด',(a,b)=>(a.at||0)-(b.at||0)||a.id-b.id],
  d_desc:['วันนัดล่าสุด',(a,b)=>b.date.localeCompare(a.date)||b.time.localeCompare(a.time)],
  d_asc:['วันนัดเก่าสุด',(a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time)]
};
function apList(){
  const f=S.apS||'all',q=(S.apQ||'').trim().toLowerCase().split(/\s+/).filter(Boolean),fn=(AP_ST.find(x=>x[0]===f)||AP_ST[0])[2],so=(AP_SORT[S.apO]||AP_SORT.in_desc)[1];
  return apBase().filter(fn).filter(b=>{if(!q.length)return true;const t=bkText(b)+' '+hn(doc(b.doc).hid).toLowerCase();return q.every(k=>t.includes(k))}).sort(so);
}
function setAp(k){S.apS=k;S.apP=1;render()}
function apBoxHtml(){
  const base=apBase(),f=S.apS||'all',l=apList(),per=10,pages=Math.max(1,Math.ceil(l.length/per)),page=Math.min(Math.max(1,S.apP||1),pages),show=l.slice((page-1)*per,page*per),L=S.viewR==='list';
  const items=AP_ST.map(([k,v,fn])=>[k,v+'('+base.filter(fn).length+')']);
  const card=b=>{const d=doc(b.doc);return `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><b>${acct(b.pt).name}</b>${stTag(b)}</div><div class="small">${d.name} · ${dept(d.dept).n}</div><div class="small">นัด ${fmtD(b.date)} ${b.time}</div>${b.at?`<div class="small">จองเมื่อ ${ago(b.at)}</div>`:''}</div>`};
  const rowL=b=>{const d=doc(b.doc);return `<div class="lrow wrap"><div class="av">${initial(acct(b.pt).name)}</div><div class="lm"><b>${acct(b.pt).name}</b><div class="small">${d.name} · นัด ${fmtD(b.date)} ${b.time}</div>${b.at?`<div class="small">จองเมื่อ ${ago(b.at)}</div>`:''}</div><div class="lr">${stTag(b)}</div></div>`};
  return `<div class="pills" style="padding-left:0;padding-right:0">${items.map(([k,v])=>`<button class="pill ${f===k?'on':''}" onclick="setAp('${k}')">${v}</button>`).join('')}</div>
  <div class="small" style="margin:6px 0 10px">${l.length?`แสดง ${(page-1)*per+1}–${(page-1)*per+show.length} จาก ${l.length} รายการ`:'0 รายการ'} · ${(AP_SORT[S.apO]||AP_SORT.in_desc)[0]}</div>`+
  (show.length?(L?`<div class="lrows" style="margin:0 0 12px">${show.map(rowL).join('')}</div>`:`<div class="cards">${show.map(card).join('')}</div>`):'<div class="empty">ไม่พบนัดหมายตามเงื่อนไขที่เลือก</div>')+
  pagerHtml(page,pages);
}
function pagerHtml(page,pages,fn='goAp'){
  if(pages<=1)return '';
  const nums=[];for(let i=1;i<=pages;i++){if(i===1||i===pages||Math.abs(i-page)<=1)nums.push(i);else if(nums[nums.length-1]!=='…')nums.push('…')}
  return `<div class="pager" role="navigation" aria-label="เลือกหน้า"><button ${page<=1?'disabled':''} onclick="goAp(${page-1})" aria-label="หน้าก่อน">‹</button>${nums.map(n=>n==='…'?'<span class="pe">…</span>':`<button class="${n===page?'on':''}" onclick="goAp(${n})" ${n===page?'aria-current="page"':''}>${n}</button>`).join('')}<button ${page>=pages?'disabled':''} onclick="goAp(${page+1})" aria-label="หน้าถัดไป">›</button></div>`;
}
function goAp(n){S.apP=n;refreshAp();const e=document.getElementById('apTools');if(e)e.scrollIntoView({block:'start',behavior:'smooth'})}
function refreshAp(){const e=document.getElementById('apBox');if(e)e.innerHTML=apBoxHtml()}
const FUNNEL='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4-2v-4z"/></svg>';
function apfHtml(){
  const cur=S.apO||'in_desc',opt=(k)=>`<button class="opt ${cur===k?'on':''}" onclick="pickSort('${k}')"><span>${AP_SORT[k][0]}</span>${cur===k?'<span aria-hidden="true">✓</span>':''}</button>`;
  return `<button class="fbtn" onclick="toggleApMenu()" aria-label="ตัวกรอง" aria-expanded="${!!S.apMenu}">${FUNNEL}${cur!=='in_desc'?'<i class="fdot"></i>':''}</button>`+
  (S.apMenu?`<div class="apscrim" onclick="toggleApMenu()"></div><div class="apmenu" role="menu"><div class="gl">ตามการจอง</div>${opt('in_desc')}${opt('in_asc')}<div class="gl">ตามวันนัด</div>${opt('d_desc')}${opt('d_asc')}</div>`:'');
}
function toggleApMenu(){S.apMenu=!S.apMenu;const e=document.getElementById('apf');if(e)e.innerHTML=apfHtml()}
function pickSort(k){S.apO=k;S.apP=1;S.apMenu=false;const e=document.getElementById('apf');if(e)e.innerHTML=apfHtml();refreshAp()}
function allAppointments(){
  return `<div class="lhead"><h2>นัดหมายทั้งหมด</h2>${viewToggleR()}</div>
  <div class="pad aptools" id="apTools"><input id="ap_q" type="search" placeholder="ค้นหา ชื่อผู้ป่วย แพทย์ โรงพยาบาล วันที่ ฯลฯ" value="${S.apQ||''}" oninput="S.apQ=this.value;S.apP=1;refreshAp()" autocomplete="off">
   <div class="apf" id="apf">${apfHtml()}</div></div>
  <div id="apBox" class="apbox">${apBoxHtml()}</div>`;
}
function nudgeHosp(id){const b=BOOKS.find(x=>x.id===id);b.nudged=true;notify('h:'+doc(b.doc).hid,`แอดมินแจ้งเตือน: คำขอของ ${acct(b.pt).name} ค้างมา ${waitH(b)} ชม.`,'requests');render();toast('แจ้งเตือนโรงพยาบาลแล้ว')}
function enterAs(id){
  const a=ACCTS.find(x=>x.id===id);if(!a||S.role!=='admin')return;
  if(a.role==='admin'){toast('ใช้งานแทนบัญชีแอดมินไม่ได้');return}
  if(!a.on||a.pending){toast('บัญชีนี้ถูกระงับหรือรออนุมัติ ใช้งานแทนไม่ได้');return}
  S.imp={adminId:S.user.id};S.user=a;S.role=a.role;S.tab='home';
  S.sub=null;S.sheet=null;S.docForm=null;S.reportBk=null;S.ptView=null;S.acctHosp=null;S.editProfile=false;S.f={hosp:'',dept:'',date:'',time:'all'};
  render();window.scrollTo(0,0);
}
function exitImp(){
  const ad=S.imp&&ACCTS.find(x=>x.id===S.imp.adminId);S.imp=null;
  if(!ad){logout();return}
  S.user=ad;S.role='admin';S.tab='accts';S.sub=null;S.sheet=null;S.docForm=null;S.reportBk=null;S.ptView=null;render();window.scrollTo(0,0);
}
const impBar=()=>S.imp&&S.user?`<div class="impbar">${ic('eye',16)} กำลังใช้งานแทน <b>${S.user.name}</b> (${ROLES[S.user.role]})<button onclick="exitImp()">กลับสู่แอดมิน</button></div>`:'';
function approveAcct(id){if(S.role!=='admin')return;const a=ACCTS.find(x=>x.id===id);a.pending=false;a.on=true;render();toast('อนุมัติบัญชีแล้ว เข้าสู่ระบบได้ทันที')}
function rejectAcct(id){if(S.role!=='admin')return;ACCTS=ACCTS.filter(x=>x.id!==id);render();toast('ปฏิเสธและลบคำขอสร้างบัญชีแล้ว')}
const acctSub=a=>`${ROLES[a.role]}${a.dpt?' · '+a.dpt:''}`;
const acctAct=a=>a.pending?`<div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end"><button class="btn sm" onclick="approveAcct(${a.id})">อนุมัติ</button><button class="btn danger sm" onclick="rejectAcct(${a.id})">ปฏิเสธ</button></div>`:`<div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;align-items:center">${a.role!=='admin'&&a.on?`<button class="btn sec sm" onclick="enterAs(${a.id})">ใช้งานแทน</button>`:''}<button class="tag ${a.on?'ok':'bad'}" onclick="togAcct(${a.id})">${a.on?'ใช้งานอยู่ · ระงับ':'ระงับอยู่ · เปิดใช้'}</button></div>`;
const acctCard=a=>`<div class="card"><div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start"><div><h3>${a.name}</h3><div class="small">${acctSub(a)}</div><div class="small">${a.email}${a.phone?' · '+a.phone:''}</div></div>${a.pending?'<span class="tag amber">รออนุมัติ</span>':''}</div><div style="margin-top:10px;display:flex;justify-content:flex-end">${acctAct(a)}</div></div>`;
const acctRow=a=>`<div class="lrow wrap"><div class="av">${initial(a.name)}</div><div class="lm"><b>${a.name}</b><div class="small">${acctSub(a)} · ${a.email}</div></div><div class="lr">${acctAct(a)}</div></div>`;
function hospStats(h){
  const hb=BOOKS.filter(b=>doc(b.doc).hid===h.id),c=st=>hb.filter(b=>b.status===st).length,ns=c('noshow'),done=c('seen');
  return {docs:DOCS.filter(d=>d.hid===h.id).length,staff:ACCTS.filter(a=>a.hid===h.id&&!a.pending).length,pa:ACCTS.filter(a=>a.hid===h.id&&a.pending).length,pend:c('pending'),stale:hb.filter(isStale).length,up:c('upcoming'),seen:done,ns,rate:ns+done?Math.round(ns*100/(ns+done)):0};
}
const hospChips=h=>{const x=hospStats(h);return `<span class="tag">แพทย์ ${x.docs}</span><span class="tag">เจ้าหน้าที่ ${x.staff}</span>${x.pa?`<span class="tag amber">รออนุมัติ ${x.pa}</span>`:''}<span class="tag amber">คำขอรอยืนยัน ${x.pend}</span>${x.stale?`<span class="tag bad">ค้างเกิน 24 ชม. ${x.stale}</span>`:''}<span class="tag">ไม่มาตามนัด ${x.rate}%</span>`};
const docAv=d=>d.img?`<img class="dimg" src="${d.img}" alt="${d.name}">`:initial(d.name);
const avatarHtml=(u,sz)=>u.photo?`<img class="ava" src="${u.photo}" alt="${u.name}" style="width:${sz}px;height:${sz}px">`:`<span class="ava" style="width:${sz}px;height:${sz}px;font-size:${Math.round(sz*.45)}px">${initial(u.name)}</span>`;
async function setMyPhoto(inp){
  const f=inp.files[0];inp.value='';if(!f)return;
  if(!f.type.startsWith('image/')){toast('เลือกไฟล์รูปภาพ');return}
  const url=await readImg(f,400,.8);if(!url){toast('อ่านรูปไม่สำเร็จ');return}
  S.user.photo=url;render();toast('อัปเดตรูปโปรไฟล์แล้ว');
}
function delMyPhoto(){delete S.user.photo;render()}
const photoBtns=u=>`<div><label class="pbtn">${ic('camera',16)} ${u.photo?'เปลี่ยนรูป':'เพิ่มรูป'}<input type="file" accept="image/*" hidden onchange="setMyPhoto(this)"></label>${u.photo?'<button class="link" style="margin:6px 0 0" onclick="delMyPhoto()">ลบรูป</button>':''}</div>`;
function readImg(f,dim,q){return new Promise(res=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,dim/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',q))};im.onerror=()=>res(null);im.src=r.result};r.onerror=()=>res(null);r.readAsDataURL(f)})}
async function setHospImg(inp,id){
  const f=inp.files[0];inp.value='';if(!f)return;
  if(!f.type.startsWith('image/')){toast('เลือกไฟล์รูปภาพ');return}
  const url=await readImg(f,900,.78);if(!url){toast('อ่านรูปไม่สำเร็จ');return}
  HOSPS.find(h=>h.id===id).img=url;render();toast('อัปเดตรูปโรงพยาบาลแล้ว');
}
function hospHero(h,mode){
  const x=hospStats(h),hue=(170+h.id*15)%360,tech=mode==='tech',view=mode==='view';
  const st=(n,t,c)=>`<div class="stat ${c||''}"><b>${n}</b><span class="small">${t}</span></div>`;
  const row=(i,l,v)=>`<div class="hrow"><span class="hic">${i}</span><div><div class="small">${l}</div><div>${v||'—'}</div></div></div>`;
  const hf=[['addr','ที่อยู่',h.addr],['tel','เบอร์โทรโรงพยาบาล',h.tel],['hours','เวลาทำการ',h.hours]];
  const infoBlock=tech&&S.editHosp
    ?hf.map(([k,l,v])=>`<label>${l}</label><input class="hf" data-k="${k}" value="${v||''}">`).join('')+`<label>ชื่อโรงพยาบาล · แก้ไขได้ผ่านแอดมิน</label><input value="${h.n}" readonly><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn sm" onclick="saveHosp()">บันทึกข้อมูลโรงพยาบาล</button><button class="btn sec sm" onclick="S.editHosp=false;render()">ยกเลิก</button></div>`
    :`<div class="hrows">${row(ic('map-pin',18),'ที่อยู่',h.addr)}${row(ic('phone',18),'เบอร์โทร',h.tel)}${row(ic('clock',18),'เวลาทำการ',h.hours)}</div>${tech?`<button class="btn sec sm" style="margin-top:10px" onclick="S.editHosp=true;render()">แก้ไขข้อมูลโรงพยาบาล</button>`:''}`;
  return `<div class="hhero"><div class="himg" style="--hue:${hue}">${h.img?`<img src="${h.img}" alt="${h.n}">`:'<div class="hph">'+ic('building',64)+'</div>'}${view?'':`<label class="himgbtn"><input type="file" accept="image/*" hidden onchange="setHospImg(this,${h.id})">${ic('camera',16)} ${h.img?'เปลี่ยนรูป':'เพิ่มรูป'}</label>`}</div>
  <div class="hinfo"><h1 class="hname">${h.n}</h1><div class="small">${h.p||''}</div>${view?`<p style="margin:10px 0 12px">โรงพยาบาลมหาวิทยาลัยที่ตั้งอยู่ใน อ.คลองหลวง จ.ปทุมธานี MorHub TU ช่วยให้ค้นหาแพทย์ เลือกเวลา และติดตามนัดหมายได้ในที่เดียว</p>`:''}${infoBlock}
   ${view?'':`<div class="stats hstats">${st(x.docs,'แพทย์')}${st(x.staff,'เจ้าหน้าที่ รพ.')}${st(x.pend,'คำขอรอยืนยัน')}${st(x.stale,'ค้างเกิน 24 ชม.',x.stale?'alert':'')}${st(x.up,'นัดที่ยืนยันแล้ว')}${st(x.seen,'ตรวจแล้ว')}${st(x.rate+'%','ไม่มาตามนัด')}${tech?'':st(x.pa,'บัญชีรออนุมัติ',x.pa?'warnc':'')}</div>`}</div></div>`;
}
function openHospAcct(id){S.acctHosp=id;render();window.scrollTo(0,0)}
function adminHospStaff(){
  const h=HOSPS.find(x=>x.id===S.acctHosp)||{n:'-'},L=S.view==='list';
  const l=ACCTS.filter(a=>a.hid===S.acctHosp).sort((a,b)=>(b.pending?1:0)-(a.pending?1:0));
  return `<div class="top"><button class="back" onclick="S.acctHosp=null;render()" aria-label="ย้อนกลับ">‹</button><h1 style="font-size:18px">โรงพยาบาล</h1></div>
  ${hospHero(h,'admin')}
  <h2>เจ้าหน้าที่ของโรงพยาบาลนี้</h2>
  <div class="pad"><button class="btn" style="margin-top:0" onclick="S.sheet={t:'staff',r:'tech',hid:${S.acctHosp}};render()">+ สร้างบัญชีเจ้าหน้าที่ของโรงพยาบาลนี้</button></div>${vbar('เจ้าหน้าที่ '+l.length+' บัญชี')}`+
  (l.length?(L?`<div class="lrows">${l.map(acctRow).join('')}</div>`:l.map(acctCard).join('')):'<div class="empty">ยังไม่มีเจ้าหน้าที่ของโรงพยาบาลนี้</div>');
}
function adminAccts(){
  if(S.acctHosp)return adminHospStaff();
  const pend=ACCTS.filter(a=>a.pending),f=['hosp','pending','patient','admin'].includes(S.acctF)?S.acctF:'hosp',L=S.view==='list',nr=r=>ACCTS.filter(a=>a.role===r&&!a.pending).length;
  const sus=r=>ACCTS.filter(a=>a.role===r&&!a.pending&&!a.on).length,total=nr('tech')+nr('patient')+nr('admin');
  const sc=(k,n,l,sub,cls)=>`<div class="stat ${cls||''} ${f===k?'sel':''}" role="button" tabindex="0" style="cursor:pointer" onclick="S.acctF='${k}';render()"><b>${n}</b><span class="small">${l}</span>${sub?`<div class="small" style="color:var(--danger)">${sub}</div>`:''}</div>`;
  const tabs=`<h2 style="margin-top:6px">บัญชีทั้งหมด ${total} บัญชี</h2><div class="stats">${sc('hosp',nr('tech'),'บัญชีเจ้าหน้าที่',sus('tech')?'ระงับ '+sus('tech'):'')}${sc('patient',nr('patient'),'บัญชี user',sus('patient')?'ระงับ '+sus('patient'):'')}${sc('admin',nr('admin'),'บัญชี admin',sus('admin')?'ระงับ '+sus('admin'):'')}${sc('pending',pend.length,'รออนุมัติ','',pend.length?'warnc':'')}</div>`;
  let body;
  if(f==='hosp'){
    const st=ACCTS.filter(a=>a.role==='tech').sort((a,b)=>(b.pending?1:0)-(a.pending?1:0));
    body=hospHero(HOSPS[0],'admin')+`<h2>เจ้าหน้าที่ รพ.</h2><div class="pad"><button class="btn" style="margin-top:0" onclick="S.sheet={t:'staff',r:'tech',hid:1};render()">+ สร้างบัญชีเจ้าหน้าที่ของโรงพยาบาลนี้</button></div>${vbar('')}`+(st.length?(L?`<div class="lrows">${st.map(acctRow).join('')}</div>`:st.map(acctCard).join('')):'<div class="empty">ยังไม่มีเจ้าหน้าที่</div>');
  }else{
    const l=ACCTS.filter(a=>f==='pending'?a.pending:a.role===f);
    body=l.length?(L?`<div class="lrows">${l.map(acctRow).join('')}</div>`:l.map(acctCard).join('')):`<div class="empty">${f==='pending'?'ไม่มีบัญชีที่รออนุมัติ':'ไม่มีบัญชี'}</div>`;
  }
  return `<div class="top"><h1>จัดการบัญชี</h1></div>${tabs}${f==='admin'?`<div class="pad" style="margin-top:12px"><button class="btn" style="margin-top:0" onclick="S.sheet={t:'staff',r:'admin'};render()">+ สร้างบัญชีแอดมิน</button></div>`:''}${f==='hosp'?'':vbar(f==='patient'?'บัญชี user (ผู้ป่วย) ทั้งหมด':f==='admin'?'บัญชีแอดมิน':'บัญชีเจ้าหน้าที่ รพ. ที่รอการอนุมัติ')}${body}`;
}
const tname=t=>t.pt?acct(t.pt).name:(t.name||'ผู้เยี่ยมชม');
function adminIssues(){
  const f=S.isF||'open',l=TICKETS.filter(t=>t.status===f).sort((a,b)=>b.at-a.at),n=TICKETS.filter(t=>t.status==='open').length,L=S.view==='list';
  const sub=t=>{const b=BOOKS.find(x=>x.id===t.bk),d=b?doc(b.doc):null;return [t.topic,t.hid?hn(t.hid):'',d?d.name+' · '+fmtD(b.date)+' '+b.time:'',t.pt?'':'ผู้เยี่ยมชม',t.contact||''].filter(Boolean).join(' · ')||'-'};
  const act=t=>t.status==='open'?`<button class="btn sm" onclick="S.sheet={t:'resolve',id:${t.id}};render()">ดำเนินการแล้ว</button>`:`<div class="small">${ic('check',14)} ${t.note||'ดำเนินการแล้ว'}</div>`;
  const card=t=>`<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><b>${tname(t)}</b><span class="small">${ago(t.at)}</span></div><div class="small">${sub(t)}</div><p style="margin-top:8px">${t.text}</p><div style="margin-top:10px">${act(t)}</div></div>`;
  const rowL=t=>`<div class="lrow wrap"><div class="av">${initial(tname(t))}</div><div class="lm"><b>${tname(t)} <span class="small" style="font-weight:400">· ${ago(t.at)}</span></b><div class="small">${sub(t)}</div><div>${t.text}</div></div><div class="lr">${act(t)}</div></div>`;
  return `<div class="top"><h1>เรื่องร้องเรียน</h1></div><div class="stats" style="margin-bottom:12px"><div class="stat ${n?'alert':''}" role="button" tabindex="0" style="cursor:pointer" onclick="S.isF='open';render()"><b>${n}</b><span class="small">เรื่องที่ยังค้างอยู่</span></div></div><div class="pad" style="margin-bottom:12px"><div class="seg">${[['open','ที่ค้างอยู่'+(n?' ('+n+')':'')],['resolved','ดำเนินการแล้ว']].map(([k,v])=>`<button class="${f===k?'on':''}" onclick="S.isF='${k}';render()">${v}</button>`).join('')}</div></div>${vbar(l.length+' รายการ')}`+
  (f==='resolved'&&l.length?`<div class="pad" style="margin-bottom:10px;text-align:right"><button class="link" style="margin:0" onclick="S.sheet={t:'clear',k:'tickets'};render()">ล้างประวัติเรื่องที่ดำเนินการแล้ว</button></div>`:'')+
  (l.length?(L?`<div class="lrows">${l.map(rowL).join('')}</div>`:l.map(card).join('')):'<div class="empty">ไม่มีรายการ</div>');
}
function resolveTicket(id){const t=TICKETS.find(x=>x.id===id);t.status='resolved';t.note=($('rs_n')||'').trim();if(t.pt)notify('u:'+t.pt,'เรื่องที่คุณแจ้งไว้ดำเนินการแล้ว'+(t.note?': '+t.note:''),'home');S.sheet=null;render();toast('บันทึกการดำเนินการแล้ว')}
function togAcct(id){if(S.role!=='admin'){toast('การระงับหรือเปิดใช้บัญชีทำได้โดยผู้ดูแลระบบเท่านั้น');return}const a=ACCTS.find(x=>x.id===id);if(a.id===S.user.id){toast('ระงับบัญชีของตัวเองไม่ได้');return}a.on=!a.on;render();toast(a.on?'เปิดใช้งานบัญชีแล้ว':'ระงับบัญชีแล้ว')}
function addHosp(){const n=($('hp_n')||'').trim();if(!n){toast('กรอกชื่อโรงพยาบาล');return}
  if(HOSPS.some(h=>h.n===n)){toast('มีโรงพยาบาลนี้แล้ว');return}
  HOSPS.push({id:Math.max(0,...HOSPS.map(h=>h.id))+1,n,p:($('hp_p')||'').trim()});S.sheet=null;render();toast('เพิ่มโรงพยาบาลแล้ว')}
function addStaff(){
  const r=S.sheet.r==='admin'?'admin':'tech',n=($('iv_n')||'').trim(),e=($('iv_e')||'').trim(),w=$('iv_w')||'';
  if(!n||!e||!w){toast('กรอกข้อมูลให้ครบ');return}
  if(!/^\S+@\S+\.\S+$/.test(e)){toast('รูปแบบอีเมลไม่ถูกต้อง');return}
  if(w.length<6){toast('รหัสผ่านอย่างน้อย 6 ตัวอักษร');return}
  if(ACCTS.some(a=>a.email.toLowerCase()===e.toLowerCase())){toast('อีเมลนี้ถูกใช้แล้ว');return}
  const id=Math.max(...ACCTS.map(a=>a.id))+1,ph=($('iv_p')||'').trim();
  ACCTS.push(r==='admin'?{id,role:'admin',name:n,email:e,pw:w,phone:ph,co:'MorHub TU',on:true}:{id,role:'tech',name:n,email:e,pw:w,phone:ph,hid:1,dpt:'',on:true});
  S.sheet=null;if(r==='admin')S.acctF='admin';render();toast('สร้างบัญชีแล้ว');
}

