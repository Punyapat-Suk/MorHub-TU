/* Patient screens: home search, calendar, doctor page, booking, my appointments, results */
/* ================= PATIENT ================= */
const ICO_GRID='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>';
const ICO_LIST='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>';
const vt=(cur,on,fnName,a,b,la,lb)=>`<div class="vt" role="group" aria-label="รูปแบบการแสดงผล"><button class="${cur===a?'on':''}" onclick="${fnName}('${a}')" aria-label="${la}" title="${la}">${ICO_GRID}</button><button class="${cur===b?'on':''}" onclick="${fnName}('${b}')" aria-label="${lb}" title="${lb}">${ICO_LIST}</button></div>`;
const viewToggle=()=>vt(S.view==='list'?'list':'card','', 'setView','card','list','การ์ด','ลิสต์');
const viewToggleR=()=>vt(S.viewR==='list'?'list':'card','', 'setViewR','card','list','การ์ด','ลิสต์');
const dvToggle=()=>vt(S.dview==='card'?'card':'table','', 'setDv','card','table','การ์ด','ตาราง');
function setView(v){S.view=v;render()}
const anyF=()=>{const f=S.f;return !!(f.hosp||f.dept||f.date||f.time!=='all')};
function docsFor(){
  const f=S.f,q=f.hosp.trim().toLowerCase();
  return DOCS.filter(d=>(!f.dept||d.dept===f.dept)&&(!q||docMatch(d,q))).map(d=>{
    if(f.date)return {d,s:freeSlots(d,f.date,f.time)};
    return {d,s:null,ok:slotTimes(d,f.time).length>0};
  }).filter(x=>x.s?x.s.length:x.ok);
}
function deptRowHtml(){const f=S.f;
  return `<button class="dept ${!f.dept?'on':''}" onclick="pickDept('')"><i>${ic('grid',26)}</i>ทั้งหมด</button>`+DEPTS.map(d=>`<button class="dept ${f.dept===d.id?'on':''}" style="${dStyle(d.id)}" onclick="pickDept('${d.id}')"><i>${ic(d.ic,26)}</i>${d.n}</button>`).join('');
}
function homeListHtml(){
  const f=S.f,l=docsFor(),L=S.view==='list';
  const head=`<div class="lhead"><h2>${f.date?'แพทย์ที่ว่าง · '+fmtD(f.date):'แพทย์ทั้งหมด'} <span class="small">(${l.length} คน)</span>${anyF()?'<button class="link" onclick="clearF()">ล้างตัวกรอง</button>':''}</h2>${viewToggle()}</div>`;
  const sum=anyF()?`<div class="small" style="margin:-4px 0 10px">${[f.hosp,f.dept?dept(f.dept).n:'',f.date?fmtD(f.date):'',f.time!=='all'?timeLabel(f.time):''].filter(Boolean).join(' · ')}</div>`:'';
  if(!l.length)return head+sum+`<div class="empty">${DOCS.length?'ไม่พบแพทย์ตามเงื่อนไขที่เลือก<br>ลองเปลี่ยนวัน เวลา แผนก หรือโรงพยาบาล':'ยังไม่มีแพทย์ในระบบ'}</div>`;
  if(f.date){
    if(L)return head+sum+`<div class="lrows">${l.map(({d,s})=>`<div class="lrow wrap"><div class="av">${docAv(d)}</div><div class="lm click" onclick="openDoc(${d.id})" style="cursor:pointer"><b>${d.name}</b><div class="small">${dept(d.dept).n}</div></div><div class="chips">${s.map(x=>chipHtml(d,f.date,x)).join('')}</div></div>`).join('')}</div>`;
    return head+sum+`<div class="cards">${l.map(({d,s})=>docCard(d,`<div class="chips">${s.map(x=>chipHtml(d,f.date,x)).join('')}</div>`)).join('')}</div>`;
  }
  if(L)return head+sum+`<div class="lrows">${l.map(({d})=>`<button class="lrow" onclick="openDoc(${d.id})"><div class="av">${docAv(d)}</div><div class="lm"><b>${d.name}</b><div class="small">${dept(d.dept).n}</div></div><div class="lr"><span class="tag">ดูตารางและจอง</span><span aria-hidden="true">›</span></div></button>`).join('')}</div>`;
  return head+sum+`<div class="tiles">${l.map(({d})=>`<button class="tile" onclick="openDoc(${d.id})"><div class="ph">${docAv(d)}</div><b>${d.name}</b><div class="small">${dept(d.dept).n}</div><span class="tag" style="margin-top:8px">ดูตารางและจอง</span></button>`).join('')}</div>`;
}
function refreshHome(){
  const l=document.getElementById('homeList');if(!l){render();return}
  l.innerHTML=homeListHtml();document.getElementById('deptRow').innerHTML=deptRowHtml();
  const sd=document.getElementById('f_dept');if(sd)sd.value=S.f.dept;
  const cb=document.getElementById('calBox');if(cb)cb.innerHTML=calHtml();const db=document.getElementById('dateBtn');if(db)db.innerHTML=dateBtnText();
}
const MON_TH=['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'],MON_EN=['January','February','March','April','May','June','July','August','September','October','November','December'];
const MON=(LANG==='en'?MON_EN:MON_TH).slice();
const p2=n=>String(n).padStart(2,'0');
const dateBtnText=()=>ic('calendar',16)+' '+(S.f.date?fmtD(S.f.date):'เลือกวันที่');
function availSet(){
  const f=S.f,q=f.hosp.trim().toLowerCase(),set=new Set();
  const ds=DOCS.filter(d=>(!f.dept||d.dept===f.dept)&&(!q||docMatch(d,q)));
  for(let i=0;i<90;i++){const date=addDays(i);if(ds.some(d=>freeSlots(d,date,f.time).length))set.add(date)}
  return set;
}
function calHtml(){
  if(!S.calOpen)return '';
  const av=availSet(),dates=[...av].sort();
  if(!dates.length)return `<div class="cal"><div class="small" style="padding:8px">ไม่มีวันที่แพทย์ตรวจตามเงื่อนไขที่เลือก</div><div class="calf"><button class="link" style="margin:0" onclick="toggleCal()">ปิด</button></div></div>`;
  const minM=dates[0].slice(0,7),maxM=dates[dates.length-1].slice(0,7);
  let cm=S.calMonth||minM;if(cm<minM)cm=minM;if(cm>maxM)cm=maxM;
  const [y,m]=cm.split('-').map(Number),n=new Date(y,m,0).getDate(),pad=new Date(y,m-1,1).getDay();
  let cells=WD.map(w=>`<div class="wl">${w}</div>`).join('')+'<div></div>'.repeat(pad);
  for(let d=1;d<=n;d++){const x=`${y}-${p2(m)}-${p2(d)}`,on=av.has(x);cells+=`<button type="button" class="cd ${on?'on':''} ${S.f.date===x?'sel':''}" ${on?`onclick="pickDate('${x}')"`:'disabled'}>${d}</button>`}
  return `<div class="cal"><div class="calh"><button type="button" onclick="calNav(-1)" ${cm<=minM?'disabled':''} aria-label="เดือนก่อน">‹</button><b>${MON[m-1]} ${LANG==='en'?y:y+543}</b><button type="button" onclick="calNav(1)" ${cm>=maxM?'disabled':''} aria-label="เดือนถัดไป">›</button></div>
   <div class="calg">${cells}</div>
   <div class="calf"><button class="link" style="margin:0" onclick="pickDate('')">ล้างวันที่</button><span class="small">วันที่กดได้ = มีแพทย์ตรวจ</span><button class="link" style="margin:0" onclick="toggleCal()">ปิด</button></div></div>`;
}
function toggleCal(){S.calOpen=!S.calOpen;S.calMonth=S.f.date?S.f.date.slice(0,7):null;refreshHome()}
function calNav(d){const av=[...availSet()].sort();let cm=S.calMonth||(av[0]||iso(new Date())).slice(0,7);const [y,m]=cm.split('-').map(Number),t=new Date(y,m-1+d,1);S.calMonth=t.getFullYear()+'-'+p2(t.getMonth()+1);refreshHome()}
function pickDate(v){S.f.date=v;S.calOpen=false;refreshHome()}
function pickDept(id){S.f.dept=S.f.dept===id?'':id;refreshHome()}
function clearF(){S.f={hosp:'',dept:'',date:'',time:'all'};S.calOpen=false;render()}
function homeView(){
  const f=S.f;
  const opts=[['all','ทุกเวลา'],['am','ช่วงเช้า (ก่อน 12:00)'],['pm','ช่วงบ่าย (12:00 เป็นต้นไป)']];
  return `<div class="pgbody"><div class="hero"><div class="hi">${S.user?'สวัสดี คุณ'+S.user.name:'ยินดีต้อนรับ · ดูข้อมูลได้เลย ไม่ต้องเข้าสู่ระบบ'}</div><h1>นัดพบแพทย์ โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ</h1></div>
  <div class="filter">
    <div class="fld full"><label>ชื่อแพทย์</label>
      <input id="f_q" type="search" placeholder="ค้นหาชื่อแพทย์" value="${f.hosp}" oninput="S.f.hosp=this.value;refreshHome()" autocomplete="off"></div>
    <div class="fld"><label>แผนก</label>
      <select id="f_dept" onchange="S.f.dept=this.value;refreshHome()"><option value="">ทุกแผนก</option>${DEPTS.map(d=>`<option value="${d.id}" ${f.dept===d.id?'selected':''}>${d.n}</option>`).join('')}</select></div>
    <div class="fld calwrap"><label>วันที่ (เลือกได้เฉพาะวันที่มีแพทย์ตรวจ)</label>
      <button type="button" class="datebtn" id="dateBtn" onclick="toggleCal()">${dateBtnText()}</button><div id="calBox">${calHtml()}</div></div>
    <div class="fld"><label>เวลา</label>
      <select id="f_time" onchange="S.f.time=this.value;refreshHome()">${opts.map(([v,l])=>`<option value="${v}" ${f.time===v?'selected':''}>${l}</option>`).join('')}</select></div>
    <button class="btn" onclick="doSearch()">ค้นหา</button>
  </div>
  <div class="main">${nsBanner()}<div class="hbar"><h2>เลือกจากแผนก</h2>${S.user&&S.role==='tech'?`<button class="btn dpadd" onclick="addDocFromHome()">${ic('plus',16)} เพิ่มแพทย์</button>`:''}</div>
  <div class="dgrid" id="deptRow">${deptRowHtml()}</div>
  <div id="homeList">${homeListHtml()}</div>
  </div></div>${footerHtml()}`;
}
function joinHosp(){showLogin('register');S.rg={role:'tech'};render()}
function toTop(){window.scrollTo({top:0,behavior:'smooth'})}
function openInfo(k){S.sheet={t:'info',k};render()}
function footerHtml(){
  const role=S.user?S.role:'guest',pt=role==='patient',staff=role==='tech',adm=role==='admin',work=staff||adm;
  const L=(label,fn)=>`<button onclick="${fn}">${label}</button>`;
  const band=work
    ?{t:'ระบบจัดการนัดหมาย โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ',p:adm?[['users','ดูแลบัญชีผู้ใช้'],['inbox','ติดตามคำขอและนัดหมาย'],['megaphone','จัดการเรื่องร้องเรียน']]:[['stethoscope','จัดการตารางแพทย์'],['inbox','ยืนยันคำขอจอง'],['file-text','ส่งรายงานให้ผู้ป่วย']]}
    :{t:'จองนัดพบแพทย์ รพ.ธรรมศาสตร์เฉลิมพระเกียรติ ได้ง่าย',p:[['clock','เลือกเวลาที่ว่างจริง'],['bell','แจ้งเตือนสถานะทันที'],['pill','รับผลตรวจและยาออนไลน์']]};
  const col3=adm?`<h4>เครื่องมือแอดมิน</h4>${L('บัญชี',"go('accts')")}${L('คำขอ/นัดหมาย',"go('requests')")}${L('ร้องเรียน',"go('issues')")}`
    :staff?`<h4>เครื่องมือเจ้าหน้าที่</h4>${L('ตารางแพทย์',"goSchedule()")}${L('คำขอจอง',"go('requests')")}${L('จัดการนัด',"go('patients')")}`
    :`<h4>สำหรับผู้ป่วย</h4>${L('ค้นหาแพทย์','toTop()')}${pt?L('นัดหมายของฉัน',"go('appts')")+L('ผลตรวจและยา',"go('results')"):L('สมัครสมาชิก',"showLogin('register')")+L('เข้าสู่ระบบ',"showLogin('login')")}`;
  const col4=adm?'':`<h4>ช่วยเหลือ</h4>${L(ic('alert',15)+' แจ้งปัญหา','openIssue()')}${pt?L('เรื่องที่แจ้งไว้',"S.sheet={t:'mytickets'};render()"):''}${work?'':L('เข้าสู่ระบบเจ้าหน้าที่ / แอดมิน',"showLogin('login')")}`;
  return `<section class="fband"><div class="fb-in"><h2>${band.t}</h2>
   <div class="fpills">${band.p.map(([i,t])=>`<span>${ic(i,16)} ${t}</span>`).join('')}</div></div></section>
  <footer class="foot2"><div class="f2in">
   <div class="fcol fbrandcol"><div class="fbrand"><span class="bl">${ic('heart-plus',22)}</span>${APP_NAME}</div><p>ระบบจองนัดพบแพทย์ โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ ค้นหา เลือกเวลา และรับผลตรวจพร้อมยาในที่เดียว</p>
    ${work?'':`<button class="fcta" onclick="joinHosp()">ลงทะเบียนเป็นเจ้าหน้าที่โรงพยาบาล ${ic('arrow-right',16)}</button>`}</div>
   <div class="fcol"><h4>เกี่ยวกับ ${APP_NAME}</h4>${L('วิธีการจอง',"openInfo('howto')")}${L('คำถามที่พบบ่อย',"openInfo('faq')")}${L('ข้อมูลและความเป็นส่วนตัว',"openInfo('privacy')")}</div>
   <div class="fcol">${col3}</div>
   ${col4?`<div class="fcol">${col4}</div>`:''}
  </div><div class="fcopy">© ${new Date().getFullYear()} ${APP_NAME} · โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ</div></footer>`;
}
function doSearch(){
  if(!S.f.date){toast('เลือกวันที่เพื่อดูเวลาที่ว่าง');return}
  const l=document.getElementById('homeList');if(l&&l.scrollIntoView)l.scrollIntoView({behavior:'smooth',block:'start'});
}
function openDept(id){S.sub={t:'dept',id};render();window.scrollTo(0,0)}
function openDoc(id){S.searchPage=false;S.hospPage=false;S.docPage=false;S.viewDay=S.f.date||null;S.sub={t:'doc',id,from:S.sub};render();window.scrollTo(0,0)}
function back(){
  if(S.backTo==='doc'){S.backTo=null;S.sub=null;S.docPage=true;render();return}
  S.sub=S.sub&&S.sub.from?S.sub.from:null;render()}
function topBar(t){return `<div class="top"><button class="back" onclick="back()" aria-label="ย้อนกลับ">‹</button><h1 style="font-size:18px">${t}</h1></div>`}
function docCard(d,chipsHtml,clickable=true){
  return `<div class="card"><div class="doc" ${clickable?`onclick="openDoc(${d.id})"`:''}><div class="avatar">${docAv(d)}</div><div><h3>${d.name}</h3><div class="small">${dept(d.dept).n} · ประสบการณ์ ${d.exp}</div><div class="small">${hn(d.hid)}</div><div class="small">${d.room}</div></div></div>${chipsHtml||''}</div>`;
}
const vbar=t=>`<div class="pad lhead2"><span class="small">${t}</span>${viewToggle()}</div>`;
function setDv(v){S.dview=v;render()}
const freeSlots=(d,date,per)=>slots(d,date,per).filter(x=>x.free&&!isPast({date,time:x.t}));
function chipHtml(d,date,x){return `<button class="chip" onclick="askBook(${d.id},'${date}','${x.t}')">${x.t}</button>`}
function resultsView(){
  const f=S.f,q=f.hosp.trim().toLowerCase();
  const list=DOCS.filter(d=>!f.dept||d.dept===f.dept).filter(d=>!q||docMatch(d,q)).map(d=>({d,s:freeSlots(d,f.date,f.time)})).filter(x=>x.s.length);
  return topBar('ผลการค้นหา')+`<div class="pad small" style="margin-bottom:10px">${f.hosp?f.hosp+' · ':''}${f.dept?dept(f.dept).n:'ทุกแผนก'} · ${fmtD(f.date)} · ${timeLabel(f.time)}</div>`+
  (list.length?list.map(({d,s})=>docCard(d,`<div class="chips">${s.map(x=>chipHtml(d,f.date,x)).join('')}</div>`)).join(''):`<div class="empty">ไม่มีแพทย์ว่างตามเงื่อนไขที่เลือก<br>ลองเปลี่ยนวัน เวลา หรือโรงพยาบาล</div>`);
}
function deptView(){
  const id=S.sub.id; const list=id==='all'?DOCS:DOCS.filter(d=>d.dept===id);
  return topBar(id==='all'?'แพทย์ทั้งหมด':dept(id).n)+`<div class="pad small" style="margin-bottom:10px">แตะชื่อแพทย์เพื่อดูตารางและจอง</div>`+
  (list.length?list.map(d=>docCard(d,`<div class="small" style="margin-top:10px">ตรวจวัน ${d.wd.map(w=>WD[w]).join(' ')} · ${schedTxt(d)}</div>`)).join(''):`<div class="empty">ยังไม่มีแพทย์ในแผนกนี้</div>`);
}
const WK=[1,2,3,4,5,6,0];
const EDU_U=[['Faculty of Medicine, Thammasat University','คณะแพทยศาสตร์ มหาวิทยาลัยธรรมศาสตร์'],['Faculty of Medicine, Chulalongkorn University','คณะแพทยศาสตร์ จุฬาลงกรณ์มหาวิทยาลัย'],['Faculty of Medicine Siriraj Hospital, Mahidol University','คณะแพทยศาสตร์ศิริราชพยาบาล มหาวิทยาลัยมหิดล'],['Faculty of Medicine, Chiang Mai University','คณะแพทยศาสตร์ มหาวิทยาลัยเชียงใหม่'],['Faculty of Medicine, Khon Kaen University','คณะแพทยศาสตร์ มหาวิทยาลัยขอนแก่น'],['Faculty of Medicine, Prince of Songkla University','คณะแพทยศาสตร์ มหาวิทยาลัยสงขลานครินทร์']];
const EDU_S={
 med:[['Internal Medicine','อายุรศาสตร์'],['Royal College of Physicians of Thailand','ราชวิทยาลัยอายุรแพทย์แห่งประเทศไทย'],[['Cardiology','โรคหัวใจ'],['Gastroenterology','โรคระบบทางเดินอาหาร'],['Endocrinology and Metabolism','ต่อมไร้ท่อและเมตะบอลิสม'],['Nephrology','โรคไต']]],
 ortho:[['Orthopaedic Surgery','ศัลยศาสตร์ออร์โธปิดิกส์'],['Royal College of Orthopaedic Surgeons of Thailand','ราชวิทยาลัยแพทย์ออร์โธปิดิกส์แห่งประเทศไทย'],[['Sports Medicine','เวชศาสตร์การกีฬา'],['Joint Replacement Surgery','การผ่าตัดเปลี่ยนข้อเทียม'],['Spine Surgery','ศัลยกรรมกระดูกสันหลัง']]],
 surg:[['General Surgery','ศัลยศาสตร์ทั่วไป'],['Royal College of Surgeons of Thailand','ราชวิทยาลัยศัลยแพทย์แห่งประเทศไทย'],[['Minimally Invasive Surgery','การผ่าตัดแบบแผลเล็ก'],['Hepatobiliary Surgery','ศัลยกรรมตับและทางเดินน้ำดี']]],
 ped:[['Pediatrics','กุมารเวชศาสตร์'],['Royal College of Pediatricians of Thailand','ราชวิทยาลัยกุมารแพทย์แห่งประเทศไทย'],[['Neonatology','เวชศาสตร์ทารกแรกเกิด'],['Pediatric Allergy and Immunology','ภูมิแพ้และภูมิคุ้มกันเด็ก']]],
 ob:[['Obstetrics and Gynecology','สูติศาสตร์-นรีเวชวิทยา'],['Royal Thai College of Obstetricians and Gynaecologists','ราชวิทยาลัยสูตินรีแพทย์แห่งประเทศไทย'],[['Maternal-Fetal Medicine','เวชศาสตร์มารดาและทารกในครรภ์'],['Gynecologic Oncology','มะเร็งนรีเวชวิทยา']]],
 ent:[['Otolaryngology','โสต ศอ นาสิกวิทยา'],['Royal College of Otolaryngologists-Head and Neck Surgeons of Thailand','ราชวิทยาลัยโสต ศอ นาสิกแพทย์แห่งประเทศไทย'],[['Rhinology','โรคจมูกและโพรงไซนัส'],['Head and Neck Surgery','ศัลยกรรมศีรษะและคอ']]],
 eye:[['Ophthalmology','จักษุวิทยา'],['Royal College of Ophthalmologists of Thailand','ราชวิทยาลัยจักษุแพทย์แห่งประเทศไทย'],[['Retina and Vitreous','จอประสาทตาและวุ้นตา'],['Glaucoma','ต้อหิน'],['Cornea and External Disease','กระจกตาและโรคตาภายนอก']]],
 psy:[['Psychiatry','จิตเวชศาสตร์'],['Royal College of Psychiatrists of Thailand','ราชวิทยาลัยจิตแพทย์แห่งประเทศไทย'],[['Child and Adolescent Psychiatry','จิตเวชเด็กและวัยรุ่น']]]};
function eduFor(d){
  const sp=EDU_S[d.dept]||EDU_S.med,n=d.id||0,ex=parseInt(d.exp)||10,y1=2026-ex,y2=y1+4,y3=y2+2;
  const u1=EDU_U[n%EDU_U.length],u2=EDU_U[(n+2)%EDU_U.length],fel=sp[2][n%sp[2].length];
  const en=[`${y1} | Doctor of Medicine (M.D.) | ${u1[0]}`,`${y2} | Board Certification in ${sp[0][0]} | ${sp[1][0]}`],th=[`${y1+543} | แพทยศาสตรบัณฑิต | ${u1[1]}`,`${y2+543} | วุฒิบัตรแสดงความรู้ความชำนาญในการประกอบวิชาชีพเวชกรรม สาขา${sp[0][1]} | ${sp[1][1]}`];
  if(y3<=2025){en.push(`${y3} | Fellowship in ${fel[0]} | ${u2[0]}`);th.push(`${y3+543} | ประกาศนียบัตรอนุสาขา${fel[1]} | ${u2[1]}`)}
  return {en:en.reverse().join('\n'),th:th.reverse().join('\n')};
}
const eduText=d=>{const k=LANG==='th'?'eduTh':'edu',o=LANG==='th'?'edu':'eduTh';return d[k]!=null?d[k]:(d[o]!=null?d[o]:'')};
const eduRows=d=>eduText(d).split('\n').map(l=>l.split('|').map(x=>x.trim())).filter(r=>r[0]||r[1]);
function startAddDoc(){S.docForm={s1:'08:00',e1:'12:00',cap:1,wd:[],dept:S.dd||'med'};render();window.scrollTo(0,0)}
function addDocFromHome(){goSchedule();startAddDoc()}
function editDocHere(id){const d=doc(id);S.docForm={...d,wd:[...d.wd],edit:true,eduTxt:eduText(d)};render();window.scrollTo(0,0)}
function docView(){
  if(S.docForm)return docFormView();
  const d=doc(S.sub.id),staff=S.user&&S.role==='tech',dp=dept(d.dept),title=d.title||'แพทย์เฉพาะทาง'+dp.n;
  const chips=[['stethoscope','แผนก',dp.n],['map-pin','ห้องตรวจ',d.room],['clock','ประสบการณ์',d.exp]];
  const ses=[[d.s1,d.e1],[d.s2,d.e2]].filter(x=>x[0]&&x[1]),edu=eduRows(d);
  const cols=WK.map(w=>`<div class="scol"><div class="sh">${WD[w]}</div><div class="sbody">${d.wd.includes(w)?ses.map(([x,y],k)=>`<button class="sblock ${x>='12:00'?'pm':''}" onclick="openSched(${d.id},${w},${k})"><b>${x} - ${y}</b><span>${ic('map-pin',12)} ${d.room}</span><i>${dp.n}</i></button>`).join(''):`<div class="sempty">${ic('calendar',34)}</div>`}</div></div>`).join('');
  return `<div class="dpg"><button class="backlink" onclick="back()">${ic('arrow-left',15)} กลับไปรายชื่อแพทย์</button>
  <div class="dhead"><div class="dpic">${d.img?`<img class="dimg" src="${d.img}" alt="${d.name}">`:ic('user',84)}</div>
   <div class="dtxt"><h1>${d.name}</h1><p class="dsub">${title}</p><div class="dchips">${chips.map(([i,l,v])=>`<div class="dchip"><span class="dci">${ic(i,20)}</span><div><div class="small">${l}</div><b>${v||'—'}</b></div></div>`).join('')}</div></div>
   ${staff?`<button class="editicon" onclick="editDocHere(${d.id})" aria-label="แก้ไข" title="แก้ไข">${ic('pencil',20)}</button>`:''}</div>
  ${edu.length?`<details class="edu" open><summary><b>ประวัติการศึกษา</b><span class="chev">${ic('chevron-down',20)}</span></summary>${edu.map(r=>`<div class="erow"><b class="ey">${r[0]||''}</b><div>${r[1]||''}</div><div class="small">${r[2]||''}</div></div>`).join('')}</details>`:''}
  <h2 class="schh">ตารางตรวจ</h2><div class="sgridw"><div class="sgrid">${cols}</div></div>
  <p class="small" style="margin-top:10px">กดที่ช่วงเวลาเพื่อเลือกวันและเวลา แล้วจอง</p></div>`;
}
function openSched(id,w,k){S.sheet={t:'sched',id,w,k,date:null};render()}
function schedDates(d,w,k){
  const x=[[d.s1,d.e1],[d.s2,d.e2]].filter(y=>y[0]&&y[1])[k]||[d.s1,d.e1],out=[];
  for(let i=0;i<90&&out.length<8;i++){const dt=addDays(i);if(new Date(dt+'T00:00').getDay()!==w)continue;const f=freeSlots(d,dt,'all').filter(z=>z.t>=x[0]&&z.t<x[1]);if(f.length)out.push({dt,f})}
  return {win:x,out};
}
function askBook(id,date,time){
  if(!S.user){S.pending={id,date,time};S.sheet={t:'needlogin',id,date,time};render();return}
  if(S.role==='admin'){toast('ต้องเข้าสู่ระบบด้วยบัญชีคนไข้หรือเจ้าหน้าที่ จึงจะจองได้');return}
  if(S.role==='patient'&&noshow90(S.user.id)>=3){toast('จองไม่ได้ชั่วคราว เพราะพลาดนัดครบ 3 ครั้งใน 90 วัน กรุณาติดต่อโรงพยาบาล');return}
  S.sheet={t:'book',id,date,time};render()}
function nsBanner(){if(!S.user)return '';const n=noshow90(S.user.id);if(!n)return '';
  return `<div class="card warn"><b>${n>=3?'ระงับการจองชั่วคราว':'คุณพลาดนัด '+n+' ครั้งในรอบ 90 วัน'}</b><div class="small" style="color:inherit;opacity:.85;margin-top:2px">${n>=3?'พลาดนัดครบ 3 ครั้ง จึงจองนัดใหม่ไม่ได้ชั่วคราว กรุณาติดต่อโรงพยาบาล':'หากพลาดนัดครบ 3 ครั้ง ระบบจะระงับการจองชั่วคราว ถ้าไปไม่ได้ กรุณายกเลิกนัดล่วงหน้า'}</div></div>`}
const digitsOf=x=>String(x||'').replace(/\D/g,'');
function bkFind(phone,hnIn){const p=digitsOf(phone),h=digitsOf(hnIn);return ACCTS.find(a=>a.role==='patient'&&((h&&digitsOf(a.hn)===h)||(p.length>=9&&digitsOf(a.phone)===p)))}
function bkLookup(){
  const a=bkFind($('bk_pp'),$('bk_ph')),e=document.getElementById('bk_hint');if(!e)return;
  if(!a){e.style.display='none';return}
  e.innerHTML=`${ic('check-circle',16)} พบผู้ป่วยในระบบ: ${a.name} · ${a.hn}`;e.style.display='';
  const set=(id,v)=>{const x=document.getElementById(id);if(x&&!x.value&&v)x.value=v};
  set('bk_pn',a.name);set('bk_ph',a.hn);set('bk_pd',a.dob);set('bk_pa',a.allergy);
}
function confirmStaffBook(){
  const s=S.sheet,d=doc(s.id),name=($('bk_pn')||'').trim(),phone=($('bk_pp')||'').trim(),hnIn=($('bk_ph')||'').trim(),dob=$('bk_pd')||'',allergy=($('bk_pa')||'').trim(),note=($('bk_note')||'').trim()||'-';
  const miss=[];if(name.length<2)miss.push(['bk_pn']);
  if(!phone)miss.push(['bk_pp']);else if(digitsOf(phone).length<9)miss.push(['bk_pp',LANG==='en'?'Invalid phone number':'เบอร์โทรไม่ถูกต้อง']);
  if(note==='-')miss.push(['bk_note']);
  if(miss.length){markReq(miss);return}
  const x=slots(d,s.date,'all').find(y=>y.t===s.time);
  if(!x||!x.free){S.sheet=null;render();toast('ช่วงเวลานี้เต็มแล้ว กรุณาเลือกใหม่');return}
  let pt=bkFind(phone,hnIn);
  if(pt&&noshow90(pt.id)>=3){toast('ผู้ป่วยรายนี้พลาดนัดครบ 3 ครั้งใน 90 วัน จองไม่ได้ชั่วคราว');return}
  if(pt&&BOOKS.some(b=>b.pt===pt.id&&b.date===s.date&&b.time===s.time&&['upcoming','pending'].includes(b.status))){toast('ผู้ป่วยมีนัดอื่นในวันและเวลาเดียวกันแล้ว');return}
  if(!pt){const id=Math.max(...ACCTS.map(a=>a.id))+1;pt={id,role:'patient',name,email:'',pw:'',phone,dob,hn:'HN '+(100000+id),allergy,on:true,walkin:true};ACCTS.push(pt)}
  else{if(allergy&&!pt.allergy)pt.allergy=allergy;if(dob&&!pt.dob)pt.dob=dob}
  BOOKS.push({id:_bid++,doc:s.id,pt:pt.id,date:s.date,time:s.time,status:'upcoming',note,at:Date.now(),src:'staff'});
  if(pt.email)notify('u:'+pt.id,`นัดหมายของคุณกับ ${d.name} ${fmtD(s.date)} ${s.time} ได้รับการยืนยันแล้ว (จองโดยเจ้าหน้าที่)`,'appts');
  S.sheet=null;S.sub=null;go('patients');openPt(pt.id);toast('จองนัดให้ผู้ป่วยแล้ว นัดได้รับการยืนยัน');
}
const apptKV=(d,date,time,x={})=>{const rows=[];if(x.pt)rows.push(['ผู้ป่วย',x.pt]);rows.push(['ชื่อแพทย์',d.name],['แผนก',dept(d.dept).n],['วันที่',fmtD(date)],['เวลา',time+' น.'],['สถานที่',d.room]);if(x.note!==undefined)rows.push(['อาการ',x.note||'-']);
  return `<div class="apptinfo">${rows.map(([l,v],i)=>`<div class="kv"${i===rows.length-1?' style="border:0"':''}><span>${l}</span><span${l==='อาการ'?' style="text-align:right;max-width:65%"':''}>${v}</span></div>`).join('')}</div>`};
/* required fields: red frame + asterisk + message, cleared as soon as the person types */
const reqMsg=m=>m||(LANG==='en'?'This field is required':'จำเป็นต้องกรอกช่องนี้');
function markReq(list){
  let first=null;
  list.forEach(([id,msg])=>{const e=document.getElementById(id);if(!e)return;
    e.classList.add('err');const lb=e.previousElementSibling;
    if(lb&&lb.tagName==='LABEL'&&!lb.querySelector('.req'))lb.insertAdjacentHTML('beforeend',' <em class="req">*</em>');
    let m=e.nextElementSibling;if(!m||!m.classList.contains('emsg')){e.insertAdjacentHTML('afterend','<div class="emsg"></div>');m=e.nextElementSibling}
    m.textContent=reqMsg(msg);if(!first)first=e});
  if(first){first.scrollIntoView({block:'center',behavior:'smooth'});first.focus({preventScroll:true})}
  return !!first;
}
function clearReq(e){e.classList.remove('err');const lb=e.previousElementSibling;if(lb&&lb.tagName==='LABEL'){const r=lb.querySelector('.req');if(r){if(r.previousSibling&&r.previousSibling.nodeType===3&&r.previousSibling.nodeValue.endsWith(' '))r.previousSibling.nodeValue=r.previousSibling.nodeValue.trimEnd();r.remove()}}const m=e.nextElementSibling;if(m&&m.classList.contains('emsg'))m.remove()}
document.addEventListener('input',e=>{if(e.target.classList&&e.target.classList.contains('err'))clearReq(e.target)});
document.addEventListener('change',e=>{if(e.target.classList&&e.target.classList.contains('err'))clearReq(e.target)});
function confirmBook(){
  if(S.role==='tech')return confirmStaffBook();
  const s=S.sheet,d=doc(s.id),uid=S.user.id;
  const x=slots(d,s.date,'all').find(y=>y.t===s.time);
  if(!x||!x.free){S.sheet=null;toast('ช่วงเวลานี้เต็มแล้ว กรุณาเลือกใหม่');return}
  if(BOOKS.some(b=>b.pt===uid&&b.date===s.date&&b.time===s.time&&['upcoming','pending'].includes(b.status))){toast('คุณมีนัดอื่นในวันและเวลาเดียวกันแล้ว');return}
  const note=($('bk_note')||'').trim();if(!note){markReq([['bk_note']]);return}
  BOOKS.push({id:_bid++,doc:s.id,pt:uid,date:s.date,time:s.time,status:'pending',note,at:Date.now()});
  notify('h:'+d.hid,`คำขอจองใหม่จาก ${S.user.name} · ${d.name} ${fmtD(s.date)} ${s.time}`,'requests');
  S.sheet=null;S.sub=null;S.tab='appts';render();window.scrollTo(0,0);toast('ส่งคำขอจองแล้ว รอโรงพยาบาลยืนยัน');
}
// Once the confirmed appointment reaches the patient, they confirm they came; the admin then forwards it to the hospital for results and medicine
const visitBtn=b=>b.status==='upcoming'&&!b.visited&&!b.gate
  ?`<div style="margin-top:10px"><button class="btn sm" onclick="confirmVisit(${b.id})">${ic('check',15)} ยืนยันว่ามาตรวจแล้ว</button></div>`:'';
function apptsView(){
  const mine=BOOKS.filter(b=>b.pt===S.user.id).sort((a,b)=>b.date.localeCompare(a.date)||b.time.localeCompare(a.time));
  const act=b=>['upcoming','pending','proposed'].includes(b.status)&&!isPast(slotOf(b)),L=S.view==='list';
  // Finished appointments the patient cleared from their history stay hidden
  const gone=b=>['seen','noshow','cancelled'].includes(b.status)&&CLEARED.appointments&&b.upd&&b.upd<=CLEARED.appointments;
  const up=mine.filter(act).reverse(), past=mine.filter(b=>!act(b)&&!gone(b));
  const tags=b=>`${pTag(b)}${b.fu?'<span class="tag">นัดติดตาม</span>':''}${b.changedFrom?'<span class="tag">เปลี่ยนนัดแล้ว</span>':''}`;
  const extras=b=>`${b.status==='proposed'?propHtml(b):''}${b.status==='cancelled'&&b.by==='hospital'?`<div class="small" style="margin-top:6px">เหตุผล: ${b.reason||'-'}</div>`:''}${act(b)&&b.status!=='proposed'?`<div style="margin-top:8px"><button class="btn danger sm" onclick="cancelBk(${b.id})">ยกเลิกนัด</button></div>`:''}${visitBtn(b)}${linkedBtn(b)}`;
  const row=b=>{const d=doc(b.doc);return `<div class="card"><div class="doc"><div class="avatar">${docAv(d)}</div><div style="flex:1"><h3>${d.name}</h3><div class="small">${dept(d.dept).n}${hospTel(d.hid)}</div><div class="small">${d.room}</div><div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap"><span class="tag">${fmtD(b.date)} ${b.time} น.</span>${tags(b)}</div>${b.status==='proposed'?propHtml(b):''}${b.status==='cancelled'&&b.by==='hospital'?`<div class="small" style="margin-top:6px">เหตุผล: ${b.reason||'-'}</div>`:''}</div></div>
   ${act(b)&&b.status!=='proposed'?`<div style="margin-top:10px"><button class="btn danger sm" onclick="cancelBk(${b.id})">ยกเลิกนัด</button></div>`:''}${visitBtn(b)}${linkedBtn(b)}</div>`};
  const rowL=b=>{const d=doc(b.doc),x=extras(b);return `<div class="lrow wrap"><div class="av">${docAv(d)}</div><div class="lm"><b>${fmtD(b.date)} ${b.time} น.</b><div class="small">${d.name} · ${dept(d.dept).n}</div><div class="small">${hn(d.hid)}${hospTel(d.hid)}</div></div><div class="lr">${tags(b)}</div>${x?`<div class="lx">${x}</div>`:''}</div>`};
  const sec=(l,empty)=>l.length?(L?`<div class="lrows">${l.map(rowL).join('')}</div>`:l.map(row).join('')):`<div class="empty">${empty}</div>`;
  return `<div class="top"><h1>นัดหมายของฉัน</h1></div>${nsBanner()}${vbar('นัดทั้งหมด '+(up.length+past.length)+' รายการ')}<h2 style="margin-top:6px">กำลังจะถึง</h2>${sec(up,'ไม่มีนัดหมาย ไปที่หน้าแรกเพื่อจองแพทย์')}<div class="lhead"><h2>ประวัติ</h2>${past.some(b=>['seen','noshow','cancelled'].includes(b.status))?`<button class="link" style="margin:0" onclick="S.sheet={t:'clear',k:'appointments'};render()">ล้างประวัติ</button>`:''}</div>${sec(past,'ยังไม่มีประวัติ')}`;
}
function propHtml(b){
  const o=doc(b.doc),n=doc(b.prop.doc),ok=!isPast(b.prop);
  return `<div class="card warn" style="margin:10px 0 0"><b>โรงพยาบาลเสนอเปลี่ยนนัด</b>
   <div class="small" style="color:inherit;margin-top:4px">เดิม: ${o.name} · ${fmtD(b.date)} ${b.time}</div>
   <div class="small" style="color:inherit"><b>ใหม่: ${n.name} · ${fmtD(b.prop.date)} ${b.prop.time} น.</b></div>
   <div class="small" style="color:inherit">${n.room}</div>
   ${b.prop.reason?`<div class="small" style="color:inherit">เหตุผล: ${b.prop.reason}</div>`:''}
   ${ok?`<div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap"><button class="btn sm" onclick="acceptProp(${b.id})">ยอมรับนัดใหม่</button><button class="btn danger sm" onclick="declineProp(${b.id})">ไม่ยอมรับ</button></div>`:''}</div>`;
}
function acceptProp(id){const b=BOOKS.find(x=>x.id===id);if(isPast(b.prop)){toast('ข้อเสนอหมดอายุแล้ว');return}
  b.changedFrom={doc:b.doc,date:b.date,time:b.time};b.doc=b.prop.doc;b.date=b.prop.date;b.time=b.prop.time;delete b.prop;b.status='upcoming';notify('h:'+doc(b.doc).hid,`${acct(b.pt).name} ยอมรับนัดใหม่ · ${doc(b.doc).name} ${fmtD(b.date)} ${b.time}`,'patients');render();toast('ยอมรับนัดใหม่แล้ว นัดยืนยันเรียบร้อย')}
function declineProp(id){const b=BOOKS.find(x=>x.id===id);delete b.prop;b.status='cancelled';b.by='patient';b.reason='ไม่ยอมรับข้อเสนอเปลี่ยนนัด';notify('h:'+doc(b.doc).hid,`${acct(b.pt).name} ไม่ยอมรับข้อเสนอเปลี่ยนนัด คำขอถูกยกเลิก`,'patients');render();toast('ปฏิเสธข้อเสนอแล้ว คำขอถูกยกเลิก')}
function issueHtml(b){
  const t=TICKETS.filter(x=>x.bk===b.id);
  return `${t.map(x=>`<div class="small" style="margin-top:8px">${ic('megaphone',14)} แจ้งปัญหา: ${x.status==='open'?'รอผู้ดูแลระบบตรวจสอบ':'ดำเนินการแล้ว'+(x.note?' — '+x.note:'')}</div>`).join('')}<div style="margin-top:8px"><button class="link" style="margin:0" onclick="S.sheet={t:'issue',bk:${b.id}};render()">แจ้งปัญหาเกี่ยวกับนัดนี้</button></div>`;
}
function openIssue(){S.sheet={t:'issue'};render()}
function submitIssue(){
  const t=($('is_t')||'').trim();if(!t){toast('กรอกรายละเอียดปัญหา');return}
  let name,contact='';
  if(S.user){name=S.user.name;contact=S.user.email}
  else{name=($('is_n')||'').trim();contact=($('is_c')||'').trim();if(!name||!contact){toast('กรอกชื่อและช่องทางติดต่อกลับ');return}}
  TICKETS.push({id:_tid++,pt:S.user?S.user.id:null,name,contact,topic:$('is_k')||'',bk:null,hid:null,text:t,status:'open',at:Date.now()});
  notify('admin',`เรื่องร้องเรียนใหม่จาก ${name}`,'issues');S.sheet=null;render();toast('ส่งเรื่องให้ผู้ดูแลระบบแล้ว ขอบคุณที่แจ้งค่ะ');
}
function cancelBk(id){const b=BOOKS.find(x=>x.id===id);if(isPast(b)){toast('ถึงเวลานัดแล้ว ยกเลิกไม่ได้');render();return}const was=b.status;b.status='cancelled';b.by='patient';notify('h:'+doc(b.doc).hid,`${acct(b.pt).name} ยกเลิก${was==='pending'?'คำขอจอง':'นัด'} ${fmtD(b.date)} ${b.time} · ${doc(b.doc).name}`,was==='pending'?'requests':'patients');render();toast('ยกเลิกนัดแล้ว')}
const linkedRp=b=>REPORTS.filter(r=>r.bk===b.id).sort((x,y)=>y.id-x.id);
const linkedBtn=b=>{const l=linkedRp(b);return l.length?`<div style="margin-top:10px"><button class="btn sec sm" onclick="openReport(${l[0].id})">ดูผลตรวจและยา${l.length>1?' ('+l.length+')':''}</button></div>`:''};
function slipHtml(r){const n=r.next,d=doc(n.doc),p=acct(r.pt);
  return `<div class="slip"><b>${ic('calendar',16)} ใบนัด (นัดติดตามผล)</b>
   <div class="kv"><span>ผู้ป่วย</span><span>${p.name}</span></div><div class="kv"><span>โรงพยาบาล</span><span>${hn(d.hid)}</span></div>
   <div class="kv"><span>ชื่อแพทย์</span><span>${d.name}</span></div><div class="kv"><span>สถานที่</span><span>${d.room}</span></div>
   <div class="kv" style="border:0"><span>วัน-เวลา</span><span><b>${fmtD(n.date)} ${n.time} น.</b></span></div>
   <div class="small">กรุณามาก่อนเวลานัด 15 นาที พร้อมบัตรประชาชนและเลขผู้ป่วย</div></div>`}
function openReport(id){const r=REPORTS.find(x=>x.id===id);if(r&&S.role==='patient')r.seen=true;S.sheet={t:'report',id};render()}
function unseen(){return REPORTS.filter(r=>r.pt===S.user.id&&!r.seen).length}
const rdate=ds=>{const dt=new Date(ds+'T00:00');return `<div class="rdate" aria-label="${fmtD(ds)}"><small>${WD[dt.getDay()]}</small><b>${dt.getDate()}</b><small>${dt.toLocaleDateString(LOC(),{month:'short'})} ${(LANG==='en'?String(dt.getFullYear()):String(dt.getFullYear()+543).slice(2))}</small></div>`};
function resultsTabView(){
  const l=REPORTS.filter(r=>r.pt===S.user.id).sort((a,b)=>b.vdate.localeCompare(a.vdate)||b.id-a.id),L=S.view==='list';
  const sub=r=>{const d=r.doc?doc(r.doc):null;return `${d?d.name:''}`};
  const card=r=>`<div class="card" onclick="openReport(${r.id})" style="cursor:pointer"><div class="rcard">${rdate(r.vdate)}<div style="flex:1;min-width:0"><div style="display:flex;justify-content:space-between;gap:8px"><h3>${r.dx}</h3>${r.seen?'':'<span class="tag bad">ใหม่</span>'}</div><div class="small">${sub(r)}</div><div class="chips">${r.meds.length?r.meds.map(m=>`<span class="tag">${m.n}</span>`).join(''):'<span class="small">ไม่มียาที่สั่ง</span>'}</div>${r.files&&r.files.length?`<div class="small" style="margin-top:8px">${ic('paperclip',14)} ไฟล์แนบ ${r.files.length} ไฟล์</div>`:''}</div></div></div>`;
  const rowL=r=>`<div class="lrow click" style="cursor:pointer" onclick="openReport(${r.id})">${rdate(r.vdate)}<div class="lm"><b>${r.dx}</b><div class="small">${sub(r)}</div></div><div class="lr">${r.seen?'':'<span class="tag bad">ใหม่</span>'}<span class="tag">ยา ${r.meds.length}</span>${r.files&&r.files.length?`<span class="tag">${ic('paperclip',13)} ${r.files.length}</span>`:''}<span aria-hidden="true">›</span></div></div>`;
  return `<div class="top"><h1>ผลตรวจและยา</h1></div>${vbar('เรียงตามวันที่ตรวจ ล่าสุดอยู่บนสุด')}`+
  (l.length?(L?`<div class="lrows">${l.map(rowL).join('')}</div>`:l.map(card).join('')):'<div class="empty">ยังไม่มีผลตรวจ</div>');
}

