/* Page shell: menu per role, go(), page body, guest bar */
/* ================= SHELL ================= */
const NAVS={
 patient:[['home','home','หน้าแรก'],['appts','calendar','นัดหมาย'],['results','pill','ผลตรวจ/ยา'],['profile','user','โปรไฟล์']],
 tech:[['home','home','หน้าแรก'],['requests','inbox','คำขอจอง'],['patients','calendar-check','จัดการนัด'],['profile','building','โปรไฟล์ รพ.']],
 admin:[['accts','users','บัญชี'],['requests','inbox','คำขอ/นัดหมาย'],['issues','megaphone','ร้องเรียน'],['profile','user','โปรไฟล์']],
};
function go(t){S.backTo=null;S.searchPage=false;S.hospPage=false;S.docPage=false;S.menuOpen=false;S.acctHosp=null;S.ptView=null;S.editHosp=false;S.rpQ='';S.tab=t;S.sub=null;S.docForm=null;S.reportBk=null;S.editProfile=false;S.sheet=null;render();window.scrollTo(0,0)}
function rawBody(){
  if(S.docPage)return doctorPage();
  if(S.hospPage)return hospitalPage();
  if(S.searchPage)return searchPage();
  const r=S.role,t=S.tab;
  if(r==='patient'){
    if(S.sub){return {results:resultsView,dept:deptView,doc:docView}[S.sub.t]()}
    return {home:homeView,appts:apptsView,results:resultsTabView,profile:profileView}[t]();
  }
  if(r==='tech'){
    if(S.sub){return {results:resultsView,dept:deptView,doc:docView}[S.sub.t]()}
    return {home:homeView,doctors:techDoctors,requests:techRequests,patients:techPatients,profile:techProfile}[t]();
  }
  return {accts:adminAccts,requests:adminRequests,issues:adminIssues,profile:profileView}[t]();
}
function body(){
  const h=rawBody();
  if(!S.searchPage&&!S.hospPage&&!S.docPage&&(S.role==='patient'||S.role==='tech')&&S.tab==='home'&&!S.sub)return h;
  const single=(S.tab==='profile'&&S.role!=='tech')||S.docForm||S.reportBk||S.ptView;
  const inner=`<main class="main ${single?'single':''}">${h}</main>`,side=S.user&&!S.searchPage&&!S.hospPage&&!S.docPage&&!((S.role==='patient'||S.role==='tech')&&S.tab==='home');
  return `<div class="pgbody">${side?`<div class="shell ${S.sideCol?'sc':''}"><aside class="side ${S.sideCol?'col':''}" aria-label="เมนูบัญชี">${sideHtml()}</aside>${inner}</div>`:inner}</div>`+footerHtml();
}
const guestBar=()=>`<div class="gbar"><div class="brand2" role="button" tabindex="0" aria-label="${APP_NAME}" onclick="goHome()" onkeydown="if(event.key==='Enter'||event.key===' ')goHome()"><span class="bl">${ic('heart-plus',22)}</span>${APP_NAME}</div>${topLinks()}<div class="gb">${searchBtn()}<div class="langw">${langInner()}</div><button class="btn sec sm" onclick="showLogin('login')">เข้าสู่ระบบ</button><button class="btn sm" onclick="showLogin('register')">สมัครสมาชิก</button></div></div>`;
function guestBody(){
  if(S.docPage)return `<div class="pgbody"><main class="main">${doctorPage()}</main></div>${footerHtml()}`;
  if(S.hospPage)return `<div class="pgbody"><main class="main">${hospitalPage()}</main></div>${footerHtml()}`;
  if(S.searchPage)return `<div class="pgbody"><main class="main">${searchPage()}</main></div>${footerHtml()}`;
  if(S.sub){const h={results:resultsView,dept:deptView,doc:docView}[S.sub.t]();return `<div class="pgbody"><main class="main">${h}</main></div>${footerHtml()}`}
  return homeView();
}


try{S.sideCol=localStorage.getItem('morhubtu_side')==='1'}catch(e){}
