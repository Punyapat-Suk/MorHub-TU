/* Hospital staff: manage doctors, doctor form, patients, requests, send report */
/* ================= TECH (ผูกกับ รพ. ของบัญชี) ================= */
const myHid=()=>S.user.hid;
const myDocs=()=>DOCS.filter(d=>d.hid===myHid());
const myBooks=()=>BOOKS.filter(b=>doc(b.doc).hid===myHid());
const hospBanner=()=>`<div class="pad small" style="margin-bottom:8px">${ic('building',15)} ${hn(myHid())}</div>`;
const docCardT=d=>`<div class="card"><div class="doc"><div class="avatar">${docAv(d)}</div><div style="flex:1"><h3>${d.name}</h3><div class="small">${dept(d.dept).n} · ${d.room}</div><div class="small">รับ ${d.cap||1} เคส/30 นาที · ${schedTxt(d)}</div></div></div>
 <div class="wkc">${WD.map((w,i)=>`<span class="${d.wd.includes(i)?'on':''}">${w}</span>`).join('')}</div>
 <div style="display:flex;gap:8px;margin-top:10px"><button class="btn sec sm" onclick="editDoc(${d.id})">แก้ไขตารางงาน</button><button class="btn danger sm" onclick="delDoc(${d.id})">ลบ</button></div></div>`;
function pills(items,cur,fn){return `<div class="pills">${items.map(([k,l,n])=>`<button class="pill ${cur===k?'on':''}" onclick="${fn}('${k}')">${l}${n!==undefined?` <span>${n}</span>`:''}</button>`).join('')}</div>`}
function setTd(k){S.tdept=k;render()}
function newDoc(){S.docForm={s1:'08:00',e1:'12:00',cap:1,wd:[],dept:(S.tdept&&S.tdept!=='all')?S.tdept:'med'};render();window.scrollTo(0,0)}
function editDoc(id){const d=doc(id);S.docForm={...d,wd:[...d.wd],edit:true};render();window.scrollTo(0,0)}
function techDoctors(){
  if(S.docForm)return docFormView();
  const all=myDocs(),sel=S.tdept||'all';
  const l=all.filter(d=>sel==='all'||d.dept===sel).sort((a,b)=>DEPTS.findIndex(x=>x.id===a.dept)-DEPTS.findIndex(x=>x.id===b.dept)||a.name.localeCompare(b.name,'th'));
  const cell=(d,i)=>d.wd.includes(i)?`<td class="on">${[d.s1&&d.e1?d.s1+'–'+d.e1:'',d.s2&&d.e2?d.s2+'–'+d.e2:''].filter(Boolean).join('<br>')}</td>`:`<td class="off">–</td>`;
  let rows='',last='';
  l.forEach(d=>{
    if(sel==='all'&&d.dept!==last){last=d.dept;rows+=`<tr class="grp"><td colspan="9">${dept(d.dept).n}</td></tr>`}
    rows+=`<tr><td class="dn" onclick="editDoc(${d.id})"><b>${d.name}</b><div class="small">${d.room}</div><div class="small">รับ ${d.cap||1} เคส/30 นาที</div></td>${[0,1,2,3,4,5,6].map(i=>cell(d,i)).join('')}
     <td class="act"><button class="ib" onclick="editDoc(${d.id})" aria-label="แก้ไข">${ic('pencil',16)}</button><button class="ib" onclick="delDoc(${d.id})" aria-label="ลบ">${ic('trash',16)}</button></td></tr>`});
  return `<div class="top"><h1>จัดการแพทย์</h1></div>${hospBanner()}
  ${pills([['all','ทุกแผนก',all.length],...DEPTS.map(d=>[d.id,ic(d.ic,16)+' '+d.n,all.filter(x=>x.dept===d.id).length])],sel,'setTd')}
  <div class="pad" style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin:14px 0 10px"><h3>ตารางงานแพทย์ · ${sel==='all'?'ทุกแผนก':dept(sel).n} <span class="small">(${l.length} คน)</span></h3><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end">${dvToggle()}<button class="btn sm" onclick="newDoc()">+ เพิ่มแพทย์${sel==='all'?'':'ในแผนกนี้'}</button></div></div>
  ${l.length?(S.dview==='card'?`<div class="cards">${l.map(docCardT).join('')}</div>`:`<div class="tblwrap"><table class="wk-tbl"><thead><tr><th>แพทย์</th>${WD.map(w=>`<th>${w}</th>`).join('')}<th></th></tr></thead><tbody>${rows}</tbody></table></div><p class="pad small" style="margin-top:8px">แตะชื่อแพทย์หรือปุ่มแก้ไข ${ic('pencil',14)} เพื่อแก้ไขตารางงาน · ช่องสีเขียวคือวันและเวลาที่แพทย์ตรวจ</p>`):`<div class="empty">ยังไม่มีแพทย์${sel==='all'?'':'ในแผนกนี้'}<br>กด "เพิ่มแพทย์" เพื่อเริ่มต้น</div>`}`;
}
function docFormView(){
  const f=S.docForm;
  return `<div class="top"><button class="back" onclick="S.docForm=null;render()" aria-label="ย้อนกลับ">‹</button><h1 style="font-size:18px">${f.edit?'แก้ไขแพทย์':'เพิ่มแพทย์'}</h1></div>
  <div class="card"><div class="dfphoto"><div class="dfp">${f.img?`<img class="dimg" src="${f.img}" alt="">`:ic('user',44)}</div><div class="dfbtns"><label class="btn sec sm">${ic('camera',15)} ${f.img?'เปลี่ยนรูป':'+ เพิ่มรูป'}<input type="file" accept="image/*" hidden onchange="setDocFormImg(this)"></label>${f.img?`<button class="btn sec sm" onclick="rmDocFormImg()">ลบรูป</button>`:''}</div></div>
  <label>โรงพยาบาล · กำหนดโดยบัญชีของคุณ</label><input value="${hn(myHid())}" readonly>
  <label>ชื่อ-นามสกุล</label><input id="df_n" value="${f.name||''}" placeholder="นพ./พญ. ...">
  <label>ตำแหน่ง / คำอธิบายสั้น</label><input id="df_t" value="${f.title||''}" placeholder="แพทย์เฉพาะทาง ...">
  <label>แผนก</label><select id="df_d">${DEPTS.map(d=>`<option value="${d.id}" ${f.dept===d.id?'selected':''}>${d.n}</option>`).join('')}</select>
  <label>ห้องตรวจ</label><input id="df_r" value="${f.room||''}" placeholder="อาคาร ชั้น ห้อง">
  <label>ประวัติการศึกษา (บรรทัดละ 1 รายการ: ปี | วุฒิ | สถาบัน)</label><textarea id="df_ed" rows="4" placeholder="2563 | แพทยศาสตรบัณฑิต | คณะแพทยศาสตร์">${f.eduTxt||''}</textarea>
  <label>ประสบการณ์</label><input id="df_e" value="${f.exp||''}" placeholder="เช่น 10 ปี">
  <label>จำนวนเคสที่รับได้ต่อช่วง 30 นาที</label><input id="df_c" type="number" min="1" max="20" value="${f.cap||1}">
  <label>วันที่ตรวจ</label><div class="wk">${WD.map((w,i)=>`<button class="${(f.wd||[]).includes(i)?'on':''}" onclick="togWd(${i})">${w}</button>`).join('')}</div>
  <label>เวลาตรวจ ช่วงที่ 1 (แบ่งให้จองช่วงละ 30 นาที)</label>
  <div class="row2"><input type="time" step="1800" id="df_s1" value="${f.s1||''}"><input type="time" step="1800" id="df_e1" value="${f.e1||''}"></div>
  <label>เวลาตรวจ ช่วงที่ 2 (ไม่บังคับ เช่น ช่วงบ่าย)</label>
  <div class="row2"><input type="time" step="1800" id="df_s2" value="${f.s2||''}"><input type="time" step="1800" id="df_e2" value="${f.e2||''}"></div>
  <button class="btn" onclick="saveDoc()">บันทึกแพทย์</button>${f.edit?`<button class="btn danger" onclick="S.sheet={t:'deldoc',id:${f.id}};render()">ลบแพทย์</button>`:''}</div>`;
}
function keepForm(){const f=S.docForm;f.title=$('df_t');f.eduTxt=$('df_ed');f.name=$('df_n');f.dept=$('df_d');f.room=$('df_r');f.exp=$('df_e');f.cap=Math.max(1,parseInt($('df_c'))||1);f.s1=$('df_s1');f.e1=$('df_e1');f.s2=$('df_s2');f.e2=$('df_e2')}
function togWd(i){keepForm();const f=S.docForm;f.wd=f.wd||[];f.wd=f.wd.includes(i)?f.wd.filter(x=>x!==i):[...f.wd,i];render()}
async function setDocFormImg(inp){
  const f=inp.files[0];inp.value='';if(!f)return;
  if(!f.type.startsWith('image/')){toast('เลือกไฟล์รูปภาพ');return}
  keepForm();const url=await readImg(f,480,.82);if(!url){toast('อ่านรูปไม่สำเร็จ');return}
  S.docForm.img=url;render();toast('เพิ่มรูปแพทย์แล้ว กด "บันทึกแพทย์" เพื่อยืนยัน');
}
function rmDocFormImg(){keepForm();S.docForm.img='';render()}
function saveDoc(){keepForm();const f=S.docForm;
  if(!f.name){toast('กรอกชื่อแพทย์ก่อน');return}
  if(!f.wd||!f.wd.length){toast('เลือกวันที่ตรวจอย่างน้อย 1 วัน');return}
  if(!f.s1||!f.e1||f.s1>=f.e1){toast('ตั้งเวลาตรวจช่วงที่ 1 ให้ถูกต้อง');return}
  if((f.s2||f.e2)&&(!f.s2||!f.e2||f.s2>=f.e2)){toast('เวลาตรวจช่วงที่ 2 ไม่ถูกต้อง');return}
  const data={img:f.img||'',title:(f.title||'').trim(),name:f.name,dept:f.dept,room:f.room||'-',exp:f.exp||'-',cap:f.cap,wd:f.wd,s1:f.s1,e1:f.e1,s2:f.s2||'',e2:f.e2||''};
  const et=(f.eduTxt||'').trim(),ek=LANG==='th'?'eduTh':'edu';if(et||f[ek]!=null)data[ek]=et;data.eduSeeded=true;
  if(f.edit)Object.assign(DOCS.find(d=>d.id===f.id&&d.hid===myHid()),data);
  else DOCS.push({id:Math.max(0,...DOCS.map(d=>d.id))+1,hid:myHid(),...data});
  let msg='บันทึกข้อมูลแพทย์แล้ว';
  if(f.edit){const n=schedConflicts(doc(f.id));if(n){msg+=` · มี ${n} นัดที่ไม่ตรงกับตารางใหม่ กรุณาตรวจสอบ`;notify('h:'+myHid(),`ตารางของ ${f.name} เปลี่ยนแล้ว มี ${n} นัดที่ไม่ตรงกับตารางใหม่ กรุณาตรวจสอบและเสนอเปลี่ยนนัด`,'patients')}}
  S.tdept=f.dept;S.docForm=null;render();toast(msg)}
function delDoc(id){
  if(BOOKS.some(b=>b.doc===id&&(['pending','upcoming','proposed'].includes(b.status)))){S.sheet=null;render();toast('ลบไม่ได้ เพราะยังมีนัดหมายที่รอยืนยันหรือรอตรวจ');return}
  DOCS=DOCS.filter(d=>d.id!==id);S.sheet=null;S.docForm=null;S.sub=null;S.docPage=true;S.backTo=null;render();window.scrollTo(0,0);toast('ลบแพทย์แล้ว')}
function asc2(a,b){return a.date.localeCompare(b.date)||a.time.localeCompare(b.time)}
function myPatients(){
  const m={};myBooks().forEach(b=>{(m[b.pt]=m[b.pt]||[]).push(b)});
  return Object.entries(m).map(([id,bs])=>({id:+id,p:acct(+id),bs:bs.sort(asc2)}));
}
const needSeen=b=>b.status==='upcoming'&&isPast(b);
function ptFiltered(){
  const toks=(S.ptQ||'').trim().toLowerCase().split(/\s+/).filter(Boolean);
  return myPatients().filter(e=>{
    if(!toks.length)return true;
    const en=LANG==='en'?' || '+e.bs.map(b=>tx(e.p.name)+' '+tx(doc(b.doc).name)+' '+tx(dept(doc(b.doc).dept).n)+' '+tx(b.note||'')).join(' || ').toLowerCase():'';
    const t=e.bs.map(bkText).join(' || ')+' || '+REPORTS.filter(r=>r.pt===e.id).map(r=>r.dx+' '+r.meds.map(m=>m.n).join(' ')).join(' || ').toLowerCase()+en;
    return toks.every(k=>t.includes(k));
  }).sort((a,b)=>a.p.name.localeCompare(b.p.name,'th'));
}
function ptListHtml(){
  const l=ptFiltered(),L=S.view==='list';
  return l.map(({id,p,bs})=>{
    const last=bs[bs.length-1],d=doc(last.doc);
    if(L)return `<div class="lrow click" style="cursor:pointer" onclick="openPt(${id})"><div class="av">${initial(p.name)}</div><div class="lm"><b>${p.name}</b><div class="small">${p.hn||''} · โทร ${p.phone||'-'} · นัด ${bs.length} ครั้ง</div></div><div class="lr"><span aria-hidden="true">›</span></div></div>`;
    return `<div class="card" style="cursor:pointer" onclick="openPt(${id})"><div style="display:flex;justify-content:space-between;gap:8px"><h3>${p.name}</h3><span class="tag">นัด ${bs.length} ครั้ง</span></div>
    <div class="small">${p.hn||''} · โทร ${p.phone||'-'}${p.allergy&&p.allergy!=='-'?' · แพ้: '+p.allergy:''}</div>
    <div class="small">นัดล่าสุด ${fmtD(last.date)} ${last.time} · ${d.name}</div></div>`}).join('')||`<div class="empty">${(S.ptQ||'').trim()?'ไม่พบรายการที่ตรงกับคำค้นหา':'ยังไม่มีผู้ป่วยที่มีนัดกับโรงพยาบาลนี้'}</div>`;
}
function refreshPt(){const l=document.getElementById('ptList');if(!l){render();return}l.innerHTML=ptListHtml();const c=document.getElementById('ptCount');if(c)c.textContent=ptFiltered().length+' คน'}
function setPtF(k){S.ptF=k;render()}
function openPt(id){S.ptView=id;render();window.scrollTo(0,0)}
function techPatients(){
  if(S.reportBk)return techReport();
  if(S.ptView)return ptDetail();
  return `<div class="top" style="justify-content:space-between"><h1>จัดการนัด</h1><button class="btn sm" onclick="startReport(0,0)">${ic('pencil',16)} ส่งรายงาน</button></div>${hospBanner()}${visitedHtml()}
  <div class="pad" style="margin-bottom:10px"><input id="pt_q" type="search" placeholder="ค้นหา ชื่อคนไข้ แพทย์ วันที่ อาการ เบอร์โทร ฯลฯ" value="${S.ptQ||''}" oninput="S.ptQ=this.value;refreshPt()" autocomplete="off"></div>
  <div class="pad lhead2"><span class="small">ผู้ป่วย <span id="ptCount">${ptFiltered().length} คน</span></span>${viewToggle()}</div>
  <div id="ptList" class="${S.view==='list'?'lrows':'cards'}">${ptListHtml()}</div>`;
}
// Patients who confirmed their visit (forwarded by the admin) and still need results and medicine
const needsReport=b=>b.status==='upcoming'&&b.visited&&!b.gate&&!REPORTS.some(r=>r.bk===b.id);
function visitedHtml(){
  const l=BOOKS.filter(needsReport).sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time));
  if(!l.length)return '';
  return `<h2>มาตรวจแล้ว · รอส่งผลตรวจและยา (${l.length})</h2>`+l.map(b=>{const d=doc(b.doc);return `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><b>${acct(b.pt).name}</b><span class="tag ok">ยืนยันมาตรวจแล้ว</span></div><div class="small">${d.name} · ${dept(d.dept).n} · ${fmtD(b.date)} ${b.time}</div><div class="small">อาการ: ${b.note||'-'}</div><div style="margin-top:10px"><button class="btn sm" onclick="startReport(${b.pt},${b.id})">${ic('pencil',15)} ส่งผลตรวจและยา</button></div></div>`}).join('');
}
function openVisit(id){S.sheet={t:'visit',id};render()}
function setVisit(id,st){
  const b=BOOKS.find(x=>x.id===id);if(!b||b.status===st)return;
  if(st==='upcoming'){
    if(REPORTS.some(r=>r.bk===id)){toast('มีรายงานอ้างอิงนัดนี้แล้ว ย้อนกลับเป็นรอตรวจไม่ได้');return}
    b.status='upcoming';render();toast('ตั้งเป็นรอตรวจแล้ว');return}
  if(!isPast(b)){toast('ยังไม่ถึงเวลานัด เลือกสถานะนี้ไม่ได้');return}
  b.status=st;
  if(st==='noshow')notify('u:'+b.pt,`บันทึกว่าไม่มาตามนัด ${fmtD(b.date)} ${b.time} · ${doc(b.doc).name}`,'appts');
  render();toast(st==='seen'?'บันทึกว่าตรวจแล้ว':'บันทึกว่าไม่มาตามนัดแล้ว');
}
function viewRp(id){S.sheet={t:'report',id};render()}
function ptDetail(){
  const id=S.ptView,p=acct(id),bs=myBooks().filter(b=>b.pt===id).sort(asc2);
  const rps=REPORTS.filter(r=>r.pt===id&&r.hid===myHid()).sort((a,b)=>b.vdate.localeCompare(a.vdate)||b.id-a.id);
  const isUp=b=>['upcoming','pending','proposed'].includes(b.status)&&!isPast(slotOf(b));
  const nb=bs.map((b,i)=>({b,i})),up=nb.filter(x=>isUp(x.b)),past=nb.filter(x=>!isUp(x.b)).reverse();
  const vrows=l=>l.map(({b,i})=>{const d=doc(b.doc),lr=linkedRp(b);return `<div class="card vis" style="cursor:pointer" onclick="openVisit(${b.id})"><div class="vno">${i+1}</div><div class="vb"><div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start"><b>${fmtD(b.date)} ${b.time}-${hr(b.time)}</b>${b.status==='upcoming'?'<span class="tag amber">รอตรวจ</span>':''}</div>
   <div class="small">${d.name} · ${dept(d.dept).n}</div><div class="small">อาการ: ${b.note||'-'}</div>${lr.length?`<div class="small">${ic('file-text',14)} รายงาน ${lr.length} ฉบับ: ${lr.map(r=>r.dx).join(', ')}</div>`:''}</div><span aria-hidden="true" style="align-self:center;color:var(--muted);font-size:20px">›</span></div>`}).join('');
  return `<div class="top"><button class="back" onclick="S.ptView=null;render()" aria-label="ย้อนกลับ">‹</button><h1 style="font-size:18px">จัดการนัด</h1></div>
  <div class="card"><div class="doc"><div class="avatar">${initial(p.name)}</div><div><h3>${p.name}</h3><div class="small">${p.hn||''}${p.dob?' · เกิด '+p.dob:''}</div><div class="small">โทร ${p.phone||'-'} · ${p.email||''}</div><div class="small">แพ้ยา/อาหาร: ${p.allergy||'-'}</div></div></div>
   <button class="btn" style="margin-top:14px" onclick="startReport(${id},0)">${ic('pencil',16)} ส่งรายงานให้ผู้ป่วย</button>
   <p class="small" style="margin-top:6px;text-align:center">เลือกนัดที่อ้างอิงและบันทึกสถานะของนัดได้ในหน้าถัดไป</p></div>
  <h2>กำลังจะถึง (${up.length}) <span class="small">แตะที่นัดเพื่อเลือกสถานะ</span></h2>
  ${vrows(up)||'<div class="empty">ไม่มีนัดหมายที่กำลังจะถึง</div>'}
  <h2>ประวัติ (${past.length})</h2>
  ${vrows(past)||'<div class="empty">ยังไม่มีประวัติ</div>'}
  <h2>รายงานที่ส่งแล้ว (${rps.length})</h2>
  ${rps.map(r=>{const k=r.bk?bs.findIndex(b=>b.id===r.bk)+1:0;return `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><b>${r.dx}</b>${!r.ok?'<span class="tag amber">รอแอดมินอนุมัติ</span>':r.seen?'':'<span class="tag amber">ยังไม่เปิดอ่าน</span>'}</div>
   <div class="small">วันที่ ${fmtD(r.vdate)} · ${r.doc?doc(r.doc).name:'ไม่ระบุแพทย์'}</div><div class="small">${k?'อ้างอิงนัดที่ '+k:'ไม่ผูกกับนัดหมาย'} · ส่งโดย ${r.by}</div><div style="margin-top:6px">${r.next?`<span class="tag amber">มีนัดต่อ ${fmtD(r.next.date)} ${r.next.time}</span>`:''}</div>
   <div style="margin-top:8px"><button class="btn sec sm" onclick="viewRp(${r.id})">ดูรายงาน</button></div></div>`}).join('')||'<div class="empty">ยังไม่เคยส่งรายงานให้ผู้ป่วยคนนี้</div>'}`;
}
function setRq(k){S.rqd=k;render()}
function propChange(){S.sheet.doc=$('pr_d');S.sheet.date=$('pr_date')||'';S.sheet.reason=$('pr_r')||'';render()}
function sendProp(){
  const s=S.sheet,b=BOOKS.find(x=>x.id===s.id),dd=+$('pr_d'),date=$('pr_date'),time=$('pr_t');
  if(!date){markReq([['pr_date']]);return}
  if(!time){markReq([['pr_date',LANG==='en'?'No free time on this day':'ไม่มีเวลาว่างในวันนี้']]);return}
  if(dd===b.doc&&date===b.date&&time===b.time){toast('ตรงกับคำขอเดิม ใช้ปุ่ม "ยืนยันนัด" แทน');return}
  const x=slots(doc(dd),date,'all').find(y=>y.t===time);if(!x||!x.free){toast('ช่วงเวลานี้เต็มแล้ว');return}
  b.prop={doc:dd,date,time,reason:($('pr_r')||'').trim(),by:S.user.name,at:Date.now()};b.status='proposed';notify('u:'+b.pt,`โรงพยาบาลเสนอเปลี่ยนนัดเป็น ${doc(dd).name} ${fmtD(date)} ${time} · กรุณาตอบรับ`,'appts');S.sheet=null;render();toast('ส่งข้อเสนอให้ผู้ป่วยแล้ว รอผู้ป่วยตอบรับ');
}
function withdrawProp(id){const b=BOOKS.find(x=>x.id===id);delete b.prop;b.status='pending';notify('u:'+b.pt,'โรงพยาบาลถอนข้อเสนอเปลี่ยนนัด คำขอของคุณกลับไปรอการยืนยัน','appts');render();toast('ถอนข้อเสนอแล้ว กลับไปเป็นคำขอที่รอยืนยัน')}
function techRequests(){
  const all=myBooks().filter(b=>b.status==='pending'),sel=S.rqd||'all',L=S.view==='list';
  const l=all.filter(b=>sel==='all'||doc(b.doc).dept===sel).sort((a,b)=>(isStale(b)?1:0)-(isStale(a)?1:0)||a.date.localeCompare(b.date)||a.time.localeCompare(b.time));
  const item=b=>{const d=doc(b.doc),p=acct(b.pt),ns=noshowAll(b.pt),past=isPast(b);
    const btns=`${past?'':`<button class="btn sm" onclick="acceptReq(${b.id})">${ic('check',15)} ยืนยัน</button><button class="btn sec sm" onclick="S.sheet={t:'propose',id:${b.id},doc:'',date:'',reason:''};render()">เสนอเปลี่ยน</button>`}<button class="btn danger sm" onclick="S.sheet={t:'decline',id:${b.id}};render()">${past?'ปิดคำขอ':'ปฏิเสธ'}</button>`;
    const tags=`${past?'<span class="tag bad">เลยเวลานัดแล้ว</span>':''}${isStale(b)?`<span class="tag bad">ค้างเกิน ${waitH(b)} ชม.</span>`:''}${b.nudged?'<span class="tag bad">แอดมินแจ้งเตือน</span>':''}${ns?`<span class="tag ${ns>=3?'bad':'amber'}">ไม่มาตามนัดมาแล้ว ${ns} ครั้ง</span>`:''}`;
    if(L)return `<div class="lrow wrap"><div class="av">${initial(p.name)}</div><div class="lm"><b>${p.name} <span class="tag">${dept(d.dept).n}</span></b><div class="small">${d.name} · ${fmtD(b.date)} ${b.time}-${hr(b.time)}</div><div class="small">${b.note||'-'}${p.allergy&&p.allergy!=='-'?' · แพ้: '+p.allergy:''}</div></div><div class="lr">${tags}${btns}</div></div>`;
    return `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><h3>${p.name}</h3><span class="tag">${dept(d.dept).n}</span></div>
   <div class="small">${d.name}</div><div class="small">${fmtD(b.date)} ${b.time}-${hr(b.time)} · ${b.note||'-'}</div>
   <div class="small">โทร ${p.phone||'-'} · ${p.hn||''}${p.allergy&&p.allergy!=='-'?' · แพ้: '+p.allergy:''}</div>
   <div class="chips" style="margin-top:6px">${tags}</div>
   <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">${btns}</div></div>`};
  const body=l.map(item).join('')||`<div class="empty">ไม่มีคำขอที่รอยืนยัน${sel==='all'?'':'ในแผนกนี้'}</div>`;
  const props=myBooks().filter(b=>b.status==='proposed');
  const pb=props.length?`<h2>รอผู้ป่วยตอบรับ (${props.length})</h2>`+props.map(b=>{const p=acct(b.pt),o=doc(b.doc),n=doc(b.prop.doc);return `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><h3>${p.name}</h3><span class="tag amber">รอตอบรับ</span></div>
   <div class="small">เดิม: ${o.name} · ${fmtD(b.date)} ${b.time}</div><div class="small"><b>เสนอ: ${n.name} · ${fmtD(b.prop.date)} ${b.prop.time}-${hr(b.prop.time)}</b></div>${b.prop.reason?`<div class="small">เหตุผล: ${b.prop.reason}</div>`:''}
   <div style="margin-top:10px"><button class="btn sec sm" onclick="withdrawProp(${b.id})">ถอนข้อเสนอ</button></div></div>`}).join(''):'';
  return `<div class="top"><h1>คำขอจองจากผู้ป่วย</h1></div>${hospBanner()}
  ${pills([['all','ทุกแผนก',all.length],...DEPTS.map(d=>[d.id,ic(d.ic,16)+' '+d.n,all.filter(b=>doc(b.doc).dept===d.id).length])],sel,'setRq')}
  <div class="pad lhead2"><span class="small">รอยืนยัน ${l.length} รายการ</span>${viewToggle()}</div>${L&&l.length?`<div class="lrows">${body}</div>`:body}${pb}`;
}
function acceptReq(id){const b=BOOKS.find(x=>x.id===id);if(isPast(b)){toast('เลยเวลานัดแล้ว ยืนยันไม่ได้');return}b.status='upcoming';b.acceptedBy=S.user.name;notify('u:'+b.pt,`นัดกับ ${doc(b.doc).name} ${fmtD(b.date)} ${b.time} ได้รับการยืนยันแล้ว`,'appts');render();toast('ยืนยันนัดแล้ว ผู้ป่วยจะเห็นสถานะ "ยืนยันแล้ว"')}
function confirmDecline(id){const b=BOOKS.find(x=>x.id===id);const n=$('dc_n'),was=b.status;b.status='cancelled';b.by='hospital';b.reason=$('dc_r')+(n&&n.trim()?' — '+n.trim():'');notify('u:'+b.pt,`${was==='pending'?'โรงพยาบาลปฏิเสธคำขอจอง':'โรงพยาบาลยกเลิกนัด'} ${doc(b.doc).name} ${fmtD(b.date)} · เหตุผล: ${b.reason}`,'appts');S.sheet=null;render();toast('บันทึกแล้ว ผู้ป่วยจะเห็นเหตุผล')}
function markSeen(id){const b=BOOKS.find(x=>x.id===id);if(!isPast(b)){toast('บันทึกได้เมื่อถึงเวลานัด');return}b.status='seen';render();toast('บันทึกว่าตรวจแล้ว · กดปุ่ม "ส่งรายงาน" ด้านล่างได้เลย')}
function confirmNoShow(id){const b=BOOKS.find(x=>x.id===id);b.status='noshow';notify('u:'+b.pt,`บันทึกว่าไม่มาตามนัด ${fmtD(b.date)} ${b.time} · ${doc(b.doc).name}`,'appts');S.sheet=null;render();toast('บันทึกว่าไม่มาตามนัดแล้ว')}
function undoMark(id){const b=BOOKS.find(x=>x.id===id);if(REPORTS.some(r=>r.bk===id)){toast('มีรายงานอ้างอิงนัดนี้แล้ว ย้อนกลับไม่ได้');return}b.status='upcoming';render();toast('ย้อนกลับเป็นรอตรวจแล้ว')}
function techReport(){
  const pts=myPatients(),pid=+S.rpPt||0,p=pid?acct(pid):null,noshow=!!S.rpBk&&S.rpSt==='noshow';
  const bks=pid?myBooks().filter(b=>b.pt===pid).sort(asc2):[];
  return `<div class="top"><button class="back" onclick="closeReport()" aria-label="ย้อนกลับ">‹</button><h1 style="font-size:18px">ส่งรายงาน</h1></div>
  <div class="card"><label>ผู้ป่วย</label><select id="rp_pt" onchange="rpChange('pt')"><option value="">เลือกผู้ป่วย</option>${pts.map(e=>`<option value="${e.id}" ${pid===e.id?'selected':''}>${e.p.name} · ${e.p.hn||''}</option>`).join('')}</select>
   ${p?`<div class="small" style="margin-top:6px">แพ้ยา/อาหาร: ${p.allergy||'-'}</div>`:''}
   <label>อ้างอิงนัดหมาย (ไม่บังคับ)</label><select id="rp_bk" onchange="rpChange('bk')" ${pid?'':'disabled'}><option value="">ไม่ผูกกับนัดหมาย</option>${bks.map((b,i)=>`<option value="${b.id}" ${String(S.rpBk)===String(b.id)?'selected':''}>นัดที่ ${i+1} · ${fmtD(b.date)} ${b.time} · ${doc(b.doc).name} · ${ST[b.status][0]}</option>`).join('')}</select>
   ${S.rpBk?`<label>สถานะของนัดนี้</label><div class="seg"><button class="${S.rpSt!=='noshow'?'on':''}" onclick="rpSt('seen')">ตรวจแล้ว</button><button class="${S.rpSt==='noshow'?'on':''}" onclick="rpSt('noshow')">ไม่มาตามนัด</button></div>`:''}
   <label>วันที่ของการตรวจ</label><input type="date" id="rp_date" value="${S.rpDate||''}" max="${iso(new Date())}">
   <label>แพทย์ผู้ตรวจ (ไม่บังคับ)</label><select id="rp_doc"><option value="">ไม่ระบุ</option>${myDocs().map(d=>`<option value="${d.id}" ${String(S.rpDoc)===String(d.id)?'selected':''}>${d.name} · ${dept(d.dept).n}</option>`).join('')}</select></div>
  ${noshow?`<div class="card"><p>ผู้ป่วยไม่มาตามนัดนี้ ระบบจะบันทึกสถานะ "ไม่มาตามนัด" และแจ้งผู้ป่วย โดยไม่สร้างรายงาน</p><button class="btn danger" onclick="sendReport()">บันทึกไม่มาตามนัด</button></div>`:`<div class="card"><label style="margin-top:0">การวินิจฉัย</label><input id="rp_dx" value="${S.rpDx||''}" placeholder="เช่น กระเพาะอาหารอักเสบ">
   <label>รายการยา</label>${S.meds.map(m=>`<div class="med"><input class="mn" placeholder="ชื่อยาและขนาด" value="${m.n}"><input class="md" placeholder="วิธีใช้ เช่น 1 เม็ด เช้า-เย็น หลังอาหาร" value="${m.d}"><input class="mdays" type="number" placeholder="จำนวนวัน" value="${m.days}"></div>`).join('')}
   <button class="btn sec sm" style="margin-top:8px" onclick="addMed()">+ เพิ่มยา</button>
   <label>คำแนะนำ</label><textarea id="rp_adv" placeholder="การปฏิบัติตัว ข้อควรระวัง">${S.rpAdv||''}</textarea>
   <label>การนัดต่อ</label>${nextBlock()}
   <label>แนบไฟล์หรือรูปภาพ (รูป/PDF สูงสุด 6 ไฟล์)</label>
   <label class="upl"><input type="file" accept="image/*,application/pdf" multiple onchange="addFiles(this)" hidden>${ic('paperclip',16)} เลือกไฟล์ / ถ่ายรูป</label>
   ${S.rpFiles.length?`<div class="files">${S.rpFiles.map((f,i)=>f.type.startsWith('image/')?`<div class="fthumb"><img src="${f.url}" alt="${f.name}"><button onclick="rmFile(${i})" aria-label="ลบไฟล์">${ic('x',14)}</button></div>`:`<div class="fdoc">${ic('file',16)} ${f.name}<button onclick="rmFile(${i})" aria-label="ลบไฟล์" style="margin-left:6px">${ic('x',14)}</button></div>`).join('')}</div>`:''}
   <button class="btn" onclick="sendReport()">ส่งให้ผู้ป่วย</button></div>`}`;
}
function bkText(b){
  const p=acct(b.pt),d=doc(b.doc),[y,mo,dd]=b.date.split('-'),be=+y+543;
  const dates=[b.date,`${dd}/${mo}/${y}`,`${dd}-${mo}-${y}`,`${dd}/${mo}/${be}`,`${dd}-${mo}-${be}`,`${+dd}/${+mo}/${y}`,`${+dd}/${+mo}/${be}`,`${dd}/${mo}`,`${+dd}/${+mo}`,`${+dd} ${new Date(b.date+'T00:00').toLocaleDateString('th-TH',{month:'long'})}`,fmtD(b.date),new Date(b.date+'T00:00').toLocaleDateString('th-TH',{weekday:'long'}),`${be}`,`${y}`];
  return [p.name,p.hn,p.phone,p.phone&&p.phone.replace(/\D/g,''),p.email,d.name,dept(d.dept).n,d.room,b.time,hr(b.time),b.note,...dates].filter(Boolean).join(' | ').toLowerCase();
}
function nextBlock(){
  const n=S.rpNext,own=myDocs(),dsel=n.doc||S.rpDoc||'',d=dsel?doc(+dsel):null;
  const tm=(d&&n.date)?slots(d,n.date,'all').filter(x=>x.free&&!isPast({date:n.date,time:x.t})):[];
  return (n.on?
  `<div class="med"><label style="margin-top:0">แพทย์ที่นัด</label><select id="rp_nx_doc" onchange="rpChange('nx')"><option value="">เลือกแพทย์</option>${own.map(x=>`<option value="${x.id}" ${String(dsel)===String(x.id)?'selected':''}>${x.name} · ${dept(x.dept).n}</option>`).join('')}</select>
   <label>วันที่นัด</label><input type="date" id="rp_nx_date" min="${iso(new Date())}" value="${n.date||''}" onchange="rpChange('nx')">
   <label>เวลา</label>${!d||!n.date?'<div class="small">เลือกแพทย์และวันที่ก่อน</div>':tm.length?`<select id="rp_nx_time">${tm.map(x=>`<option value="${x.t}" ${n.time===x.t?'selected':''}>${x.t}-${hr(x.t)} (ว่าง ${x.left})</option>`).join('')}</select>`:'<div class="small">ไม่มีช่วงเวลาว่างในวันนั้น ลองเลือกวันอื่น</div>'}
   <p class="small" style="margin-top:8px">ระบบจะสร้างนัดที่ยืนยันแล้ว และแนบใบนัดไปกับรายงาน</p><button class="btn sec sm" style="margin-top:8px" onclick="rpNext(false)">ยกเลิกนัดต่อ</button></div>`
  :`<button class="btn sec sm" onclick="rpNext(true)">+ เพิ่มนัดต่อ</button>`);
}
function rpNext(on){keepReport();S.rpNext.on=on;if(on&&!S.rpNext.doc)S.rpNext.doc=S.rpDoc||'';render()}
function startReport(pt,bk){
  const b=bk?BOOKS.find(x=>x.id===bk):null,today=iso(new Date());
  S.reportBk=true;S.rpPt=pt?String(pt):'';S.rpBk=bk?String(bk):'';S.rpDate=b?(b.date>today?today:b.date):today;S.rpDoc=b?String(b.doc):'';
  S.meds=[{n:'',d:'',days:''}];S.rpDx='';S.rpAdv='';S.rpFu='';S.rpFiles=[];S.rpNext={on:false,doc:'',date:'',time:''};S.rpSt='seen';render();window.scrollTo(0,0)}
function closeReport(){S.reportBk=null;render()}
function rpSt(v){keepReport();S.rpSt=v;render()}
function rpChange(w){keepReport();if(w==='pt'||w==='bk')S.rpSt='seen';if(w==='pt')S.rpBk='';if(w==='nx')S.rpNext.time='';
  if(w==='bk'){const b=BOOKS.find(x=>String(x.id)===String(S.rpBk));if(b){const t=iso(new Date());S.rpDate=b.date>t?t:b.date;S.rpDoc=String(b.doc)}}
  render()}
function collectMeds(){const n=[...document.querySelectorAll('.mn')],d=[...document.querySelectorAll('.md')],y=[...document.querySelectorAll('.mdays')];return n.map((x,i)=>({n:x.value,d:d[i].value,days:y[i].value}))}
function keepReport(){S.meds=collectMeds();S.rpDx=$('rp_dx');S.rpAdv=$('rp_adv');const pt=$('rp_pt');if(pt!==undefined)S.rpPt=pt;S.rpBk=$('rp_bk')||'';S.rpDate=$('rp_date')||'';S.rpDoc=$('rp_doc')||'';const a=$('rp_nx_doc'),b=$('rp_nx_date'),c=$('rp_nx_time');if(a!==undefined)S.rpNext.doc=a;if(b!==undefined)S.rpNext.date=b;if(c!==undefined)S.rpNext.time=c}
function addMed(){keepReport();S.meds.push({n:'',d:'',days:''});render()}
function readFile(f){return new Promise(res=>{
  const r=new FileReader();
  r.onload=()=>{
    if(!f.type.startsWith('image/')||f.type==='image/svg+xml'||f.type==='image/gif'){res({name:f.name,type:f.type,url:r.result});return}
    const im=new Image();
    im.onload=()=>{const k=Math.min(1,1600/Math.max(im.width,im.height));const c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);res({name:f.name,type:'image/jpeg',url:c.toDataURL('image/jpeg',0.82)})};
    im.onerror=()=>res(null);im.src=r.result;
  };
  r.onerror=()=>res(null);r.readAsDataURL(f);
})}
async function addFiles(inp){
  keepReport();const list=[...inp.files];inp.value='';
  let skipped=0;
  for(const f of list){
    if(S.rpFiles.length>=6){skipped++;continue}
    if(!(f.type.startsWith('image/')||f.type==='application/pdf')||f.size>10*1024*1024){skipped++;continue}
    const x=await readFile(f);if(x)S.rpFiles.push(x);else skipped++;
  }
  render();if(skipped)toast('ข้ามบางไฟล์ (รับเฉพาะรูป/PDF ไม่เกิน 10 MB รวมไม่เกิน 6 ไฟล์)');
}
function rmFile(i){keepReport();S.rpFiles.splice(i,1);render()}
function sendReport(){
  keepReport();
  if(!S.rpPt){toast('เลือกผู้ป่วยก่อน');return}
  const bk0=S.rpBk?BOOKS.find(x=>String(x.id)===String(S.rpBk)):null;
  if(bk0&&S.rpSt==='noshow'){
    if(!isPast(bk0)){toast('ยังไม่ถึงเวลานัด บันทึกไม่มาตามนัดไม่ได้');return}
    bk0.status='noshow';notify('u:'+bk0.pt,`บันทึกว่าไม่มาตามนัด ${fmtD(bk0.date)} ${bk0.time} · ${doc(bk0.doc).name}`,'appts');
    S.reportBk=null;render();toast('บันทึกว่าไม่มาตามนัดแล้ว');return}
  if(!(S.rpDx||'').trim()){toast('กรอกการวินิจฉัยก่อน');return}
  if(!S.rpDate){toast('ระบุวันที่ของการตรวจ');return}
  const bk=S.rpBk?BOOKS.find(x=>String(x.id)===String(S.rpBk)):null,n=S.rpNext;let next=null;
  if(n.on){
    if(!n.doc||!n.date||!n.time){toast('ระบุแพทย์ วันที่ และเวลาของนัดต่อให้ครบ');return}
    const x=slots(doc(+n.doc),n.date,'all').find(y=>y.t===n.time);
    if(!x||!x.free||isPast({date:n.date,time:n.time})){toast('ช่วงเวลานัดต่อไม่ว่างแล้ว กรุณาเลือกใหม่');return}
    const nb={id:_bid++,doc:+n.doc,pt:+S.rpPt,date:n.date,time:n.time,status:'upcoming',note:'นัดติดตามผล',fu:true,fuOf:bk?bk.id:null,at:Date.now()};
    BOOKS.push(nb);next={bk:nb.id,doc:nb.doc,date:nb.date,time:nb.time};
  }
  REPORTS.push({id:_rid++,pt:+S.rpPt,hid:myHid(),bk:bk?bk.id:null,vdate:S.rpDate,doc:S.rpDoc?+S.rpDoc:(bk?bk.doc:null),dx:S.rpDx.trim(),meds:S.meds.filter(m=>m.n.trim()),adv:S.rpAdv||'',fu:'',next,closed:!next,by:S.user.name,seen:false,files:S.rpFiles.slice(),at:iso(new Date())});
  if(bk&&bk.status!=='cancelled'&&isPast(bk))bk.status='seen';
  notify('u:'+(+S.rpPt),`มีผลตรวจและยาใหม่: ${S.rpDx.trim()}`,'results');
  if(next)notify('u:'+(+S.rpPt),`มีนัดติดตาม ${doc(next.doc).name} ${fmtD(next.date)} ${next.time} · ดูใบนัดในผลตรวจ`,'appts');
  S.reportBk=null;render();toast(next?'ส่งรายงานพร้อมใบนัดให้ผู้ป่วยแล้ว':'ส่งรายงานให้ผู้ป่วยแล้ว');
}

