/* App state object S and small lookup helpers (doc, acct, dept, status tags) */
/* ================= STATE ================= */
const S={view:'card',viewR:'card',user:null,role:null,mode:'login',err:null,lu:'',rg:{},tab:'home',sub:null,
 f:{hosp:'',dept:'',date:'',time:'all'},rpFiles:[],rpNext:{on:false,doc:'',date:'',time:''},isF:'open',viewDay:null,sheet:null,toast:null,
 editProfile:false,docForm:null,reportBk:null,meds:[{n:'',d:'',days:''}],sch:'up',acctF:'all'};
const $=id=>document.getElementById(id)?.value;
const docMatch=(d,q)=>[d.name,LANG==='en'?tx(d.name):''].join(' ').toLowerCase().includes(q);
const hn=id=>(HOSPS.find(h=>h.id===id)||{}).n||'-';
const acct=id=>ACCTS.find(a=>a.id===id)||{name:'(บัญชีถูกลบ)',phone:'-'};
const doc=id=>DOCS.find(d=>d.id===id)||{name:'(แพทย์ถูกลบ)',dept:'med',room:'-',exp:'-',hid:0,wd:[]};
const dept=id=>DEPTS.find(d=>d.id===id)||{n:'-',e:''};
const schedTxt=d=>[d.s1&&d.e1?d.s1+'–'+d.e1:'',d.s2&&d.e2?d.s2+'–'+d.e2:''].filter(Boolean).join(', ')||'ยังไม่ได้ตั้งเวลา';
const initial=n=>{const t=LANG==='en'?tx(n):n;return t.replace(/^(นพ\.|พญ\.|Dr\.\s*)/,'').slice(0,1).toUpperCase()};
const ST={pending:['รอยืนยัน','amber'],proposed:['รอผู้ป่วยตอบรับ','amber'],upcoming:['รอตรวจ','amber'],seen:['ตรวจแล้ว','ok'],done:['ตรวจเสร็จ','ok'],noshow:['ไม่มาตามนัด','bad'],cancelled:['ยกเลิก','bad']};
const apptAt=b=>new Date(b.date+'T'+b.time+':00');
const isPast=b=>apptAt(b)<=new Date();
const isOver=b=>new Date(apptAt(b).getTime()+30*60000)<=new Date();
const GATE_TAG={request:'รอแอดมินตรวจสอบ',reply:'รอแอดมินส่งให้ผู้ป่วย',visit:'ผู้ป่วยยืนยันมาตรวจ · รอแอดมิน'};
const stTag=b=>{let [t,c]=ST[b.status]||['-',''];if(b.status==='cancelled')t=b.by==='hospital'?'โรงพยาบาลยกเลิก':'ยกเลิกแล้ว';return `<span class="tag ${c}">${t}</span>${b.gate?`<span class="tag amber">${GATE_TAG[b.gate]}</span>`:''}`};
