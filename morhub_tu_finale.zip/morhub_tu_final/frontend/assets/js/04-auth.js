/* Login and register screens and actions */
/* ================= AUTH ================= */
function enter(a){
  const pend=S.pending,keepF=S.f,keepSub=S.sub;S.pending=null;
  S.info=null;S.auth=false;S.user=a;S.role=a.role;S.tab=a.role==='admin'?'accts':'home';S.sub=null;S.sheet=null;S.editProfile=false;S.docForm=null;S.reportBk=null;S.err=null;S.mode='login';S.f={hosp:'',dept:'',date:'',time:'all'};
  if(pend&&a.role==='patient'){S.f=keepF;S.sub=keepSub}
  render();window.scrollTo(0,0);
  if(pend&&a.role==='patient')askBook(pend.id,pend.date,pend.time);
}
function showLogin(mode){S.auth=true;S.mode=mode||'login';S.err=null;S.sheet=null;S.rg=S.mode==='register'?{}:S.rg;render();window.scrollTo(0,0)}
function backToGuest(){S.auth=false;S.err=null;S.info=null;S.pending=null;render()}
function logout(){S.docPage=false;S.hospPage=false;S.searchPage=false;S.aboutOpen=false;S.docForm=null;S.menuOpen=false;S.imp=null;S.user=null;S.role=null;S.err=null;S.lu='';S.sheet=null;S.auth=false;S.sub=null;S.pending=null;S.f={hosp:'',dept:'',date:'',time:'all'};render();window.scrollTo(0,0)}
function doLogin(){
  const u=($('lg_u')||'').trim().toLowerCase(),p=$('lg_p')||'';S.lu=u;
  const digits=u.replace(/\D/g,'');
  const a=ACCTS.find(x=>x.email.toLowerCase()===u||(digits.length>=9&&x.phone&&x.phone.replace(/\D/g,'')===digits));
  if(!a||!a.pw||a.pw!==p){S.err='อีเมล/เบอร์โทร หรือรหัสผ่านไม่ถูกต้อง';render();return}
  if(a.pending){S.err='บัญชีนี้รอผู้ดูแลระบบอนุมัติ เมื่ออนุมัติแล้วจึงจะเข้าสู่ระบบได้';render();return}
  if(!a.on){S.err='บัญชีนี้ถูกระงับ กรุณาติดต่อผู้ดูแลระบบ';render();return}
  enter(a);
}
function keepRg(){S.rg={role:S.rg.role||'patient',name:($('rg_n')||'').trim(),phone:($('rg_p')||'').trim(),email:($('rg_u')||'').trim(),pw:$('rg_w')||'',pw2:$('rg_c')||'',hid:$('rg_h')||S.rg.hid||'',dpt:($('rg_d')||'').trim(),cf:$('rg_c')||''}}
function setRgRole(r){keepRg();S.rg.role=r;S.err=null;render()}
function doRegister(){
  keepRg();const r=S.rg;if(r.role==='tech')r.hid=1;
  if(!r.name||!r.phone||!r.email||!r.pw){S.err='กรอกข้อมูลให้ครบทุกช่อง';render();return}
  if(!/^\S+@\S+\.\S+$/.test(r.email)){S.err='รูปแบบอีเมลไม่ถูกต้อง';render();return}
  if(r.pw.length<6){S.err='รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร';render();return}
  if(r.pw!==r.pw2){S.err='ยืนยันรหัสผ่านไม่ตรงกัน';render();return}
  if(ACCTS.some(a=>a.email.toLowerCase()===r.email.toLowerCase())){S.err='อีเมลนี้มีบัญชีอยู่แล้ว';render();return}
  if(r.pw!==r.cf){S.err='รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน';render();return}
  if(r.role==='tech'&&!r.hid){S.err='เลือกโรงพยาบาลที่สังกัด';render();return}
  const wk=r.role==='patient'?ACCTS.find(x=>x.walkin&&x.role==='patient'&&digitsOf(x.phone)===digitsOf(r.phone)):null;
  if(wk){Object.assign(wk,{name:r.name,email:r.email,pw:r.pw});delete wk.walkin;S.rg={};enter(wk);toast('สร้างบัญชีสำเร็จ ยินดีต้อนรับ');return}
  const id=Math.max(...ACCTS.map(a=>a.id))+1;
  const a=r.role==='tech'
   ?{id,role:'tech',name:r.name,email:r.email,pw:r.pw,phone:r.phone,hid:+r.hid,dpt:r.dpt,on:true}
   :{id,role:'patient',name:r.name,email:r.email,pw:r.pw,phone:r.phone,dob:'',hn:'HN '+(100000+id),allergy:'',on:true};
  if(a.role==='tech'){a.on=false;a.pending=true;ACCTS.push(a);notify('admin',`${a.name} ขอสร้างบัญชีเจ้าหน้าที่`,'accts');S.rg={};S.mode='login';S.err=null;S.info='ส่งคำขอสร้างบัญชีเจ้าหน้าที่แล้ว รอผู้ดูแลระบบอนุมัติ เมื่ออนุมัติแล้วจึงจะเข้าสู่ระบบได้';render();return}
  ACCTS.push(a);S.rg={};enter(a);toast('สร้างบัญชีสำเร็จ ยินดีต้อนรับ');
}
function loginView(){
  const reg=S.mode==='register',rr=S.rg.role||'patient';
  const form=reg?`
    <div class="fgrid">
      <div class="span2"><label>ประเภทบัญชี</label>
        <div class="seg"><button class="${rr==='patient'?'on':''}" onclick="setRgRole('patient')">คนไข้</button><button class="${rr==='tech'?'on':''}" onclick="setRgRole('tech')">เจ้าหน้าที่ รพ.</button></div></div>
      <div><label>ชื่อ-นามสกุล</label><input id="rg_n" value="${S.rg.name||''}" autocomplete="name"></div>
      <div><label>เบอร์โทร</label><input id="rg_p" type="tel" value="${S.rg.phone||''}" autocomplete="tel"></div>
      ${rr==='tech'?`<div class="span2"><label>หน่วยงาน (ไม่บังคับ)</label><input id="rg_d" value="${S.rg.dpt||''}" placeholder="เช่น เวชระเบียน"></div>`:''}
      <div class="span2"><label>อีเมล</label><input id="rg_u" type="email" value="${S.rg.email||''}" autocomplete="email"></div>
      <div><label>รหัสผ่าน (อย่างน้อย 8 ตัวอักษร)</label><input id="rg_w" type="password" autocomplete="new-password"></div>
      <div><label>ยืนยันรหัสผ่าน</label><input id="rg_c" type="password" autocomplete="new-password" onkeydown="if(event.key==='Enter')doRegister()"></div>
    </div>
    <button class="btn" onclick="doRegister()">สร้างบัญชี</button>
    <button class="btn sec" onclick="S.mode='login';S.err=null;render()">มีบัญชีแล้ว เข้าสู่ระบบ</button>`:`
    <label>อีเมลหรือเบอร์โทร</label><input id="lg_u" value="${S.lu}" autocomplete="username" onkeydown="if(event.key==='Enter')document.getElementById('lg_p').focus()">
    <label>รหัสผ่าน</label><input id="lg_p" type="password" autocomplete="current-password" onkeydown="if(event.key==='Enter')doLogin()">
    <button class="btn" onclick="doLogin()">เข้าสู่ระบบ</button>
    <button class="btn sec" onclick="S.mode='register';S.rg={};S.err=null;render()">สร้างบัญชีใหม่</button>
    <p class="small" style="margin-top:14px;text-align:center">บัญชีแอดมินเป็นบัญชีที่ระบบกำหนดไว้ ไม่สามารถสร้างเองได้</p>
    ${DEV()?`<details class="hint"><summary>บัญชีสำหรับทดสอบ</summary>
     <code>แอดมิน: admin@morhubtu.co.th · Demo@1234</code>
     <code>เจ้าหน้าที่ รพ.: tech@morhubtu.co.th · Demo@1234</code>
     <code>คนไข้: somchai@mail.com · Demo@1234</code></details>`:''}
    ${!STORE_OK||DEV()?`<p class="small" style="text-align:center;margin-top:12px">${STORE_OK?'':ic('alert',14)+' เบราว์เซอร์นี้ไม่อนุญาตให้เก็บข้อมูล รีเฟรชแล้วข้อมูลจะหาย'}${DEV()?(STORE_OK?'':'<br>')+(S.rsc?'<button class="link" style="margin:4px 0 0;color:var(--danger)" onclick="resetData()">กดอีกครั้งเพื่อยืนยัน ล้างข้อมูลทั้งหมด</button>':'<button class="link" style="margin:4px 0 0" onclick="S.rsc=true;render()">รีเซ็ตกลับเป็นข้อมูลตัวอย่าง</button>'):''}</p>`:''}`;
  return `<div class="auth">
   <aside class="auth-brand">
     <div><div class="bl big">${ic('heart-plus',34)}</div><h2>${APP_NAME}</h2><p>จองนัดพบแพทย์ โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ</p></div>
     <ul><li><span>${ic('search',20)}</span>ค้นหาแผนก วัน และเวลา</li><li><span>${ic('clock',20)}</span>เลือกช่วงเวลาตรวจได้ทีละ 30 นาที</li><li><span>${ic('pill',20)}</span>รับผลตรวจ ยา และไฟล์แนบจากแพทย์ในแอป</li></ul>
   </aside>
   <section class="auth-side"><div class="login">
     <div class="mhead"><div class="bl">${ic('heart-plus',22)}</div><b>${APP_NAME}</b></div>
     <h1>${reg?'สร้างบัญชีใหม่':'เข้าสู่ระบบ'}</h1>
     <p class="small" style="margin-top:4px">${reg?'เลือกประเภทบัญชีแล้วกรอกข้อมูลให้ครบ':'ค้นหาแผนก เลือกแพทย์ จองเวลาได้ในไม่กี่ขั้นตอน'}</p>
     ${S.err?`<div class="err" role="alert">${S.err}</div>`:''}${S.info&&!reg?`<div class="info">${S.info}</div>`:''}
     ${form}
   </div></section>
  </div>`;
}

