/* Constants: departments, icons, date helpers, sample data (replaced by the API on load) */
/* ================= DATA ================= */
const APP_NAME='MorHub TU';
const DEV=()=>location.hash==='#dev';
window.addEventListener('hashchange',()=>{try{render()}catch(e){}});
const DEPT_C={"ortho": {"c": "--amber", "bg": "--amber-bg"}, "med": {"c": "--brand", "bg": "--mint"}, "surg": {"c": "--rose", "bg": "--rose-bg"}, "ped": {"c": "--cyan", "bg": "--cyan-bg"}, "ob": {"c": "--violet-a", "bg": "--indigo-bg"}, "ent": {"c": "--cyan", "bg": "--cyan-bg"}, "eye": {"c": "--indigo", "bg": "--indigo-bg"}, "psy": {"c": "--violet-a", "bg": "--indigo-bg"}};
const dStyle=id=>{const x=DEPT_C[id];return x?`--dc:var(${x.c});--db:var(${x.bg})`:''};
const DEPTS=[
 {id:'ortho',n:'ศัลยกรรมกระดูก',ic:'bone'},{id:'med',n:'อายุรกรรม',ic:'stethoscope'},{id:'surg',n:'ศัลยกรรมทั่วไป',ic:'scissors'},{id:'ped',n:'กุมารเวช',ic:'smile'},
 {id:'ob',n:'สูติ-นรีเวช',ic:'heart'},{id:'ent',n:'หู คอ จมูก',ic:'ear'},{id:'eye',n:'จักษุ',ic:'eye'},{id:'psy',n:'จิตเวช',ic:'brain'}
];
const ICONS={"plus": "<path d=\"M12 5v14M5 12h14\"/>", "arrow-left": "<path d=\"M19 12H5M11 18l-6-6 6-6\"/>", "chevron-left": "<path d=\"m15 18-6-6 6-6\"/>", "settings": "<path d=\"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>", "power": "<path d=\"M12 2v10\"/><path d=\"M18.4 6.6a9 9 0 1 1-12.8 0\"/>", "chevron-right": "<path d=\"m9 18 6-6-6-6\"/>", "chevron-down": "<path d=\"m6 9 6 6 6-6\"/>", "log-out": "<path d=\"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4\"/><path d=\"M16 17l5-5-5-5M21 12H9\"/>", "heart-plus": "<path d=\"M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6c-2.5 4.5-9.5 9-9.5 9z\"/><path d=\"M12 9v6M9 12h6\"/>", "home": "<path d=\"M3 10.5 12 3l9 7.5\"/><path d=\"M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5\"/>", "calendar": "<rect x=\"3\" y=\"4.5\" width=\"18\" height=\"16\" rx=\"3\"/><path d=\"M8 2.5v4M16 2.5v4M3 10h18\"/>", "calendar-check": "<rect x=\"3\" y=\"4.5\" width=\"18\" height=\"16\" rx=\"3\"/><path d=\"M8 2.5v4M16 2.5v4M3 10h18M9 15l2 2 4-4\"/>", "pill": "<path d=\"M10.5 20.5l10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7z\"/><path d=\"M8.5 8.5l7 7\"/>", "bell": "<path d=\"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9\"/><path d=\"M10.3 21a1.94 1.94 0 0 0 3.4 0\"/>", "user": "<circle cx=\"12\" cy=\"8\" r=\"4\"/><path d=\"M4 21a8 8 0 0 1 16 0\"/>", "users": "<circle cx=\"9\" cy=\"8\" r=\"3.5\"/><path d=\"M2.5 20a6.5 6.5 0 0 1 13 0M16 4.6a3.5 3.5 0 0 1 0 6.8M17.5 14a6.5 6.5 0 0 1 4 6\"/>", "inbox": "<path d=\"M22 12h-6l-2 3h-4l-2-3H2\"/><path d=\"M5.5 5h13L22 12v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z\"/>", "megaphone": "<path d=\"M3 11v2a1 1 0 0 0 1 1h3l7 4V6L7 10H4a1 1 0 0 0-1 1z\"/><path d=\"M18 8.5a5 5 0 0 1 0 7\"/>", "file-text": "<path d=\"M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z\"/><path d=\"M14 3v6h6M8 13h8M8 17h5\"/>", "file": "<path d=\"M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z\"/><path d=\"M14 3v6h6\"/>", "stethoscope": "<path d=\"M5 3v5a5 5 0 0 0 10 0V3\"/><path d=\"M10 13v2a5 5 0 0 0 10 0v-3\"/><circle cx=\"20\" cy=\"10\" r=\"2\"/>", "building": "<path d=\"M4 21V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16\"/><path d=\"M2 21h20M12 7v6M9 10h6M10 21v-4h4v4\"/>", "search": "<circle cx=\"11\" cy=\"11\" r=\"7\"/><path d=\"M21 21l-4.3-4.3\"/>", "clock": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 7v5l3 2\"/>", "alert": "<path d=\"M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z\"/><path d=\"M12 9v4M12 17h.01\"/>", "paperclip": "<path d=\"M21 11l-8.6 8.6a5 5 0 0 1-7-7l8.5-8.6a3.3 3.3 0 0 1 4.7 4.7l-8.6 8.6a1.7 1.7 0 0 1-2.3-2.3L16.5 7\"/>", "pencil": "<path d=\"M12 20h9\"/><path d=\"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z\"/>", "camera": "<path d=\"M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z\"/><circle cx=\"12\" cy=\"13\" r=\"4\"/>", "trash": "<path d=\"M3 6h18M8 6V4h8v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6\"/>", "x": "<path d=\"M18 6 6 18M6 6l12 12\"/>", "eye": "<path d=\"M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>", "key": "<circle cx=\"7.5\" cy=\"15.5\" r=\"5.5\"/><path d=\"m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3\"/>", "mail": "<rect x=\"2\" y=\"4\" width=\"20\" height=\"16\" rx=\"2\"/><path d=\"m22 7-10 6L2 7\"/>", "check": "<path d=\"M20 6 9 17l-5-5\"/>", "check-circle": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"m8 12 3 3 5-6\"/>", "arrow-right": "<path d=\"M5 12h14M13 6l6 6-6 6\"/>", "map-pin": "<path d=\"M12 21s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z\"/><circle cx=\"12\" cy=\"9\" r=\"2.5\"/>", "phone": "<path d=\"M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z\"/>", "grid": "<rect x=\"3\" y=\"3\" width=\"7\" height=\"7\" rx=\"2\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"7\" rx=\"2\"/><rect x=\"3\" y=\"14\" width=\"7\" height=\"7\" rx=\"2\"/><rect x=\"14\" y=\"14\" width=\"7\" height=\"7\" rx=\"2\"/>", "bone": "<path d=\"M17 10c.7-.7 1.7-.6 2.5-.6a2.5 2.5 0 1 0-2.9-2.9c0 .8.1 1.8-.6 2.5l-6.5 6.5c-.7.7-1.7.6-2.5.6a2.5 2.5 0 1 0 2.9 2.9c0-.8-.1-1.8.6-2.5z\"/>", "scissors": "<rect x=\"2.5\" y=\"7.5\" width=\"19\" height=\"9\" rx=\"4.5\" transform=\"rotate(-45 12 12)\"/><path d=\"M10 10h.01M14 14h.01M10 14h.01M14 10h.01\"/>", "smile": "<circle cx=\"12\" cy=\"9\" r=\"4\"/><path d=\"M8 10a4 4 0 0 0 8 0M4 21a8 8 0 0 1 16 0\"/>", "heart": "<circle cx=\"12\" cy=\"8\" r=\"4\"/><path d=\"M12 12v8M9 17h6\"/>", "ear": "<path d=\"M6 8.5a6 6 0 0 1 12 0c0 3.5-3.5 4.5-3.5 8a3.5 3.5 0 0 1-6.5 1.8\"/><path d=\"M15 8.5a3 3 0 0 0-6 0\"/>", "brain": "<path d=\"M9 3a3 3 0 0 0-3 3 3 3 0 0 0-1 5 3 3 0 0 0 2 5 3 3 0 0 0 5 1 3 3 0 0 0 5-1 3 3 0 0 0 2-5 3 3 0 0 0-1-5 3 3 0 0 0-3-3 3 3 0 0 0-3-1 3 3 0 0 0-3 1z\"/><path d=\"M12 4v16\"/>"};
const ic=(n,sz=18)=>`<svg class="ic" width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n]||''}</svg>`;
let LANG=(()=>{try{return localStorage.getItem('morhubtu_lang')==='th'?'th':'en'}catch(e){return 'en'}})();
const LOC=()=>LANG==='en'?'en-GB':'th-TH';
const WD_TH=['อา','จ','อ','พ','พฤ','ศ','ส'],WD_EN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const WD=(LANG==='en'?WD_EN:WD_TH).slice();
const ROLES={patient:'คนไข้',tech:'เจ้าหน้าที่ รพ.',admin:'แอดมิน'};
const iso=d=>{const x=new Date(d);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')};
const addDays=n=>{const d=new Date();d.setDate(d.getDate()+n);return iso(d)};
const fmtD=s=>new Date(s+'T00:00').toLocaleDateString(LOC(),{weekday:'short',day:'numeric',month:'short',year:LANG==='en'?'numeric':'2-digit'});
const toM=t=>+t.slice(0,2)*60+ +t.slice(3);
const fm=m=>String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0');
const hr=t=>fm(toM(t)+30);
const timeLabel=t=>({all:'ทุกเวลา',am:'ช่วงเช้า',pm:'ช่วงบ่าย'})[t]||(t+'-'+hr(t));

let HOSPS=[
 {id:1,n:'โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ',p:'ปทุมธานี',addr:'95 หมู่ 7 ถ.พหลโยธิน ต.คลองหนึ่ง อ.คลองหลวง ปทุมธานี 12120',tel:'02-926-9999',hours:'ผู้ป่วยนอก จ-ศ 08:00-16:00'},
];
let ACCTS=[
 {id:1,role:'admin',name:'ผู้ดูแลระบบ MorHub TU',email:'admin@morhubtu.co.th',pw:'Admin@1234',phone:'02-999-0000',co:'MorHub TU',on:true},
 {id:2,role:'tech',name:'สมศักดิ์ ช่างเทค',email:'tech@morhubtu.co.th',pw:'123456',phone:'02-926-0001',hid:1,dpt:'เวชระเบียน',on:true},
 {id:3,role:'tech',name:'อรุณี วงศ์ล้านนา',email:'tech2@morhubtu.co.th',pw:'123456',phone:'02-926-0002',hid:1,dpt:'เวชระเบียน',on:true},
 {id:4,role:'tech',name:'ปรีชา สายสยาม',email:'tech3@morhubtu.co.th',pw:'123456',phone:'02-926-0003',hid:1,dpt:'IT',on:true},
 {id:5,role:'tech',name:'ณัฐพล รัตนะ',email:'tech4@morhubtu.co.th',pw:'123456',phone:'02-926-0004',hid:1,dpt:'เวชระเบียน',on:false},
 {id:6,role:'patient',name:'สมชาย ใจดี',email:'somchai@mail.com',pw:'123456',phone:'081-234-5678',dob:'1990-05-14',hn:'HN 100006',allergy:'Penicillin',on:true},
 {id:7,role:'patient',name:'วิภา สุขสันต์',email:'wipa@mail.com',pw:'123456',phone:'089-111-2222',dob:'1985-11-02',hn:'HN 100007',allergy:'-',on:true},
 {id:8,role:'patient',name:'ประเสริฐ มั่นคง',email:'prasert@mail.com',pw:'123456',phone:'086-333-4444',dob:'1972-03-21',hn:'HN 100008',allergy:'-',on:true},
 {id:9,role:'patient',name:'นภัสสร แสงทอง',email:'napat@mail.com',pw:'123456',phone:'082-555-6666',dob:'1998-08-30',hn:'HN 100009',allergy:'อาหารทะเล',on:true},
 {id:10,role:'patient',name:'อดิศร เจริญสุข',email:'adisorn@mail.com',pw:'123456',phone:'091-777-8888',dob:'1965-01-09',hn:'HN 100010',allergy:'-',on:true},
];
const R=(a,b,c,d,e,f)=>({n:a,d:b,days:c});
let DOCS=[
 {id:1,hid:1,name:'นพ.ธนา วงศ์สว่าง',dept:'med',room:'อาคาร A ชั้น 3 ห้อง 304',exp:'12 ปี',wd:[1,2,4],s1:'08:00',e1:'12:00',s2:'13:00',e2:'16:00',cap:3},
 {id:2,hid:1,name:'พญ.ปรียา ศรีสุข',dept:'med',room:'อาคาร A ชั้น 3 ห้อง 306',exp:'9 ปี',wd:[1,3,5],s1:'09:00',e1:'12:00',s2:'',e2:'',cap:2},
 {id:3,hid:1,name:'นพ.กิตติ รัตนา',dept:'ortho',room:'อาคาร B ชั้น 2 ห้อง 201',exp:'15 ปี',wd:[2,3,5],s1:'13:00',e1:'17:00',s2:'',e2:'',cap:2},
 {id:4,hid:1,name:'พญ.มัลลิกา ใจดี',dept:'ped',room:'อาคาร C ชั้น 1 ห้อง 105',exp:'7 ปี',wd:[1,2,3,4,5],s1:'08:00',e1:'12:00',s2:'13:00',e2:'16:00',cap:4},
 {id:5,hid:1,name:'นพ.ศุภชัย พงษ์ไพร',dept:'ent',room:'อาคาร B ชั้น 3 ห้อง 310',exp:'10 ปี',wd:[2,4],s1:'09:00',e1:'12:00',s2:'13:00',e2:'15:00',cap:2},
 {id:6,hid:1,name:'พญ.วริษา แก้วมณี',dept:'ob',room:'อาคาร C ชั้น 2 ห้อง 214',exp:'11 ปี',wd:[1,3,5],s1:'08:30',e1:'12:00',s2:'',e2:'',cap:3},
 {id:7,hid:1,name:'นพ.อนุชา ภูพิงค์',dept:'med',room:'อาคารหลัก ชั้น 2 ห้อง 21',exp:'14 ปี',wd:[1,2,3,4,5],s1:'08:00',e1:'12:00',s2:'',e2:'',cap:3},
 {id:8,hid:1,name:'พญ.สุนิสา ล้านนา',dept:'ped',room:'อาคารเด็ก ชั้น 1 ห้อง 3',exp:'8 ปี',wd:[1,3,5],s1:'09:00',e1:'12:00',s2:'13:00',e2:'15:30',cap:3},
 {id:9,hid:1,name:'นพ.ชัยวัฒน์ ดอยสุเทพ',dept:'ortho',room:'อาคารหลัก ชั้น 3 ห้อง 32',exp:'16 ปี',wd:[2,4,6],s1:'08:00',e1:'12:00',s2:'',e2:'',cap:2},
 {id:10,hid:1,name:'พญ.เพ็ญศรี นิมมาน',dept:'eye',room:'อาคารหลัก ชั้น 1 ห้อง 12',exp:'6 ปี',wd:[1,4],s1:'13:00',e1:'16:00',s2:'',e2:'',cap:2},
 {id:11,hid:1,name:'นพ.วีระพงษ์ อีสานดี',dept:'surg',room:'อาคาร 1 ชั้น 2 ห้อง 5',exp:'18 ปี',wd:[1,2,3,4,5],s1:'08:00',e1:'12:00',s2:'',e2:'',cap:2},
 {id:12,hid:1,name:'พญ.กนกวรรณ ขอนแก่น',dept:'med',room:'อาคาร 1 ชั้น 1 ห้อง 8',exp:'10 ปี',wd:[2,4,6],s1:'08:00',e1:'12:00',s2:'13:00',e2:'16:00',cap:3},
 {id:13,hid:1,name:'นพ.ธีรพล สายธาร',dept:'psy',room:'อาคาร 2 ชั้น 2 ห้อง 4',exp:'9 ปี',wd:[3,5],s1:'13:00',e1:'17:00',s2:'',e2:'',cap:1},
 {id:14,hid:1,name:'พญ.ณิชา อันดามัน',dept:'ob',room:'อาคาร A ชั้น 2 ห้อง 9',exp:'12 ปี',wd:[1,2,4],s1:'09:00',e1:'12:00',s2:'',e2:'',cap:2},
 {id:15,hid:1,name:'นพ.ปกรณ์ ทะเลใส',dept:'ent',room:'อาคาร A ชั้น 3 ห้อง 14',exp:'11 ปี',wd:[3,5,6],s1:'10:00',e1:'15:00',s2:'',e2:'',cap:2},
 {id:16,hid:1,name:'พญ.รัชนีกร เกาะงาม',dept:'eye',room:'อาคาร B ชั้น 1 ห้อง 2',exp:'7 ปี',wd:[1,2,3],s1:'08:30',e1:'12:00',s2:'',e2:'',cap:2},
];
let BOOKS=[];let _bid=1;let REPORTS=[];let _rid=1;let TICKETS=[];let _tid=1;let NOTIFS=[];let _nid=1;
function nextDate(d,off){let n=off;for(let i=0;i<21;i++){const x=addDays(n);if(d.wd.includes(new Date(x+'T00:00').getDay()))return x;n+=off<0?-1:1}return addDays(off)}
function seed(docId,pt,off,time,status,note,report){
  const d=DOCS.find(x=>x.id===docId),date=nextDate(d,off),bk={id:_bid++,doc:docId,pt,date,time,status:status==='done'?'seen':status,note};
  BOOKS.push(bk);
  if(report)REPORTS.push({id:_rid++,pt,hid:d.hid,bk:bk.id,vdate:date,doc:docId,dx:report.dx,meds:report.meds,adv:report.adv||'',fu:report.fuOff?nextDate(d,report.fuOff):'',by:'เจ้าหน้าที่ รพ.',seen:report.seen!==false,files:[],closed:!report.fuOff,at:date});
}
seed(1,6,-10,'09:00','done','ปวดท้องเรื้อรัง',{dx:'กระเพาะอาหารอักเสบ',meds:[R('Omeprazole 20 mg','1 เม็ด เช้า ก่อนอาหาร 30 นาที',14),R('Alum milk','10 ml หลังอาหารและก่อนนอน',7)],adv:'งดอาหารเผ็ด ชา กาแฟ นัดติดตามอาการใน 2 สัปดาห์',fuOff:7});
seed(3,6,3,'13:30','upcoming','ปวดเข่าขวา');
seed(12,6,-3,'14:00','cancelled','ตรวจเบาหวาน');
seed(4,7,1,'10:00','upcoming','ตรวจพัฒนาการบุตร');
seed(2,7,-5,'09:30','done','ตรวจสุขภาพประจำปี',{dx:'สุขภาพโดยรวมปกติ ไขมันในเลือดสูงเล็กน้อย',meds:[],adv:'ควบคุมอาหารไขมันสูง ออกกำลังกายสัปดาห์ละ 3 ครั้ง ตรวจซ้ำใน 3 เดือน',fuOff:60,seen:false});
seed(14,7,6,'09:30','upcoming','ฝากครรภ์');
seed(4,8,1,'10:00','upcoming','ไข้หวัด');
seed(7,8,2,'08:30','upcoming','เวียนศีรษะ');
seed(15,8,-8,'11:00','done','คัดจมูกเรื้อรัง',{dx:'ไซนัสอักเสบ',meds:[R('Amoxicillin 500 mg','1 เม็ด วันละ 3 ครั้ง หลังอาหาร',7),R('Loratadine 10 mg','1 เม็ด ก่อนนอน',10)],adv:'ล้างจมูกด้วยน้ำเกลือวันละ 2 ครั้ง หลีกเลี่ยงควัน/ฝุ่น',fuOff:0});
seed(4,9,1,'10:00','upcoming','ตรวจเด็กสุขภาพดี');
seed(11,9,5,'08:00','upcoming','ปวดท้องน้อยด้านขวา');
seed(1,9,-20,'13:00','done','ปวดศีรษะบ่อย',{dx:'ไมเกรน',meds:[R('Paracetamol 500 mg','1-2 เม็ด เมื่อปวด ห่างกัน 6 ชม.',5)],adv:'จดบันทึกอาการ งดนอนดึก',fuOff:0});
seed(7,10,-14,'08:00','done','ความดันโลหิตสูง',{dx:'ความดันโลหิตสูง ระยะที่ 1',meds:[R('Amlodipine 5 mg','1 เม็ด เช้า หลังอาหาร',30)],adv:'ลดเค็ม วัดความดันที่บ้านทุกวัน',fuOff:14});
seed(8,10,4,'09:00','upcoming','ตรวจพัฒนาการหลาน');
seed(10,10,7,'13:00','upcoming','สายตาพร่ามัว');
seed(1,7,-1,'09:00','upcoming','ติดตามผลเลือด');
seed(7,9,-1,'09:00','upcoming','ตรวจความดัน');
seed(2,8,-2,'09:00','seen','ปวดหลังส่วนล่าง');
seed(9,6,-4,'09:00','seen','เจ็บเข่าหลังเล่นกีฬา');
seed(3,10,-3,'14:00','noshow','ปวดข้อมือ');
seed(4,10,-9,'10:00','noshow','ตรวจพัฒนาการ');
seed(8,7,-6,'13:30','noshow','ไข้ ไอ');
seed(4,6,2,'11:00','pending','ไอเรื้อรัง 2 สัปดาห์');
seed(5,9,3,'09:00','pending','เจ็บคอ มีไข้');
seed(6,10,4,'08:30','pending','ตรวจมะเร็งปากมดลูกประจำปี');
seed(3,8,5,'13:00','pending','ปวดไหล่ซ้าย');
seed(7,6,3,'10:00','pending','ปวดศีรษะบ่อย');
seed(10,9,4,'14:00','pending','ตาแห้ง ระคายเคือง');
seed(11,7,2,'09:00','cancelled','ปวดท้อง');
Object.assign(BOOKS[BOOKS.length-1],{by:'hospital',reason:'แพทย์ติดภารกิจฉุกเฉิน กรุณาเลือกเวลาใหม่'});
REPORTS.push({id:_rid++,pt:6,hid:1,bk:null,vdate:addDays(-30),doc:1,dx:'ผลตรวจเลือดประจำปี ค่าปกติ',meds:[],adv:'ตรวจซ้ำปีละ 1 ครั้ง ดูแลอาหารและออกกำลังกายต่อเนื่อง',fu:'',by:'เจ้าหน้าที่ รพ.',seen:true,files:[],closed:true,at:addDays(-30)});
[3,30,50,5,27,8].forEach((h,i)=>{const l=BOOKS.filter(b=>b.status==='pending');if(l[i])l[i].at=Date.now()-h*36e5});
seed(4,8,3,'11:30','pending','เด็กมีไข้ ไอ');
{const b=BOOKS[BOOKS.length-1];b.at=Date.now()-6*36e5;b.status='proposed';b.prop={doc:4,date:nextDate(DOCS.find(x=>x.id===4),5),time:'14:00',reason:'แพทย์ติดภารกิจในช่วงเวลาเดิม ขอเสนอเป็นช่วงบ่าย',by:'เจ้าหน้าที่ รพ.',at:Date.now()-2*36e5}}
ACCTS.push({id:11,role:'tech',name:'ศิริพร ใหม่เมือง',email:'siriporn@morhubtu.co.th',pw:'123456',phone:'02-926-0005',hid:1,dpt:'คลินิกเด็ก',on:false,pending:true});
TICKETS.push({id:_tid++,pt:7,bk:(BOOKS.find(b=>b.pt===7&&b.status==='pending')||{}).id||null,hid:1,text:'รอการยืนยันนานเกินไป โทรไปที่โรงพยาบาลก็ไม่มีคนรับสาย',status:'open',at:Date.now()-20*36e5});
TICKETS.push({id:_tid++,pt:9,bk:null,hid:1,text:'อยากเปลี่ยนวันนัดแต่ไม่พบปุ่มแก้ไข',status:'resolved',note:'แจ้งวิธียกเลิกและจองใหม่ให้แล้ว',at:Date.now()-72*36e5});
NOTIFS.push({id:_nid++,to:'u:6',text:'นัดกับ นพ.กิตติ รัตนา ได้รับการยืนยันแล้ว',tab:'appts',at:Date.now()-5*36e5,readBy:[]});
NOTIFS.push({id:_nid++,to:'h:1',text:'คำขอจองใหม่จาก อดิศร เจริญสุข · พญ.วริษา แก้วมณี',tab:'requests',at:Date.now()-50*36e5,readBy:[]});
NOTIFS.push({id:_nid++,to:'admin',text:'ศิริพร ใหม่เมือง ขอสร้างบัญชีเจ้าหน้าที่',tab:'accts',at:Date.now()-30*36e5,readBy:[]});

