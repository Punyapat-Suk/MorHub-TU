/* Every pop-up sheet (booking, reports, notifications, decline, propose, forms ...) */
/* ================= SHEETS ================= */
// Clear-history popup: [title, what disappears]
const CLEAR_TX={
  notifications:['ล้างการแจ้งเตือนทั้งหมด','การแจ้งเตือนทั้งหมดตอนนี้จะหายไปจากรายการของคุณ การแจ้งเตือนใหม่จะยังเข้ามาตามปกติ'],
  appointments:['ล้างประวัตินัดหมาย','นัดที่ตรวจแล้ว ยกเลิก หรือไม่มาตามนัด จะหายไปจากรายการของคุณ นัดที่กำลังจะถึงและผลตรวจ/ยายังอยู่ครบ'],
  tickets:['ล้างเรื่องที่ดำเนินการแล้ว','เรื่องที่ดำเนินการแล้วจะหายไปจากรายการของคุณ เรื่องที่ยังค้างอยู่ยังแสดงตามเดิม']};
function sheetView(){
  const s=S.sheet; if(!s)return '';
  const wrap=h=>`<div class="scrim" onclick="if(event.target===this){S.sheet=null;render()}"><div class="sheet">${h}</div></div>`;
  const close=`<button class="btn sec" onclick="S.sheet=null;render()">ยกเลิก</button>`;
  if(s.t==='book'&&S.role==='tech'){const d=doc(s.id);return wrap(`<h1 style="font-size:19px">จองนัดให้ผู้ป่วย</h1>
   ${apptKV(d,s.date,s.time)}
   <label>ชื่อ-นามสกุลผู้ป่วย</label><input id="bk_pn" autocomplete="off">
   <label>เบอร์โทรผู้ป่วย</label><input id="bk_pp" type="tel" inputmode="tel" oninput="bkLookup()" autocomplete="off">
   <label>เลข HN (ถ้ามี)</label><input id="bk_ph" oninput="bkLookup()" autocomplete="off">
   <div id="bk_hint" class="small" style="display:none;color:var(--teal);margin-top:6px"></div>
   <label>วันเกิด</label><input id="bk_pd" type="date">
   <label>แพ้ยา / แพ้อาหาร</label><input id="bk_pa" autocomplete="off">
   <label>อาการหรือเหตุผลที่มาพบ</label><textarea id="bk_note" placeholder="เช่น ปวดเข่าข้างขวา 3 วัน"></textarea>
   <p class="small" style="margin-top:10px">นัดจะถูกยืนยันทันที ผู้ป่วยที่มีบัญชีจะได้รับแจ้งเตือน ผู้ป่วยใหม่จะถูกลงทะเบียนให้อัตโนมัติ</p>
   <button class="btn" onclick="confirmStaffBook()">ยืนยันการจอง</button>${close}`)}
  if(s.t==='deldoc'){const d=doc(s.id);return wrap(`<h1 style="font-size:19px">ลบแพทย์</h1><p style="margin:8px 0"><b>${d.name}</b></p><p class="small">ลบแพทย์คนนี้ออกจากระบบ การลบไม่สามารถย้อนกลับได้ ลบไม่ได้ถ้ายังมีนัดที่รอยืนยันหรือรอตรวจ</p><button class="btn danger" onclick="delDoc(${d.id})">ยืนยันการลบ</button>${close}`)}
  if(s.t==='sched'){const d=doc(s.id),{win,out}=schedDates(d,s.w,s.k),cur=out.find(o=>o.dt===s.date)||out[0];
    return wrap(`<h1 style="font-size:19px">${d.name}</h1><p class="small">${WD[s.w]} ${win[0]} - ${win[1]} · ${d.room}</p>
    ${out.length?`<label>เลือกวันและเวลา</label><div class="days">${out.map(o=>{const dt=new Date(o.dt+'T00:00');return `<button class="day ${o.dt===cur.dt?'on':''}" onclick="S.sheet.date='${o.dt}';render()">${WD[dt.getDay()]}<b>${dt.getDate()}</b>${dt.toLocaleDateString(LOC(),{month:'short'})}</button>`}).join('')}</div>
    <h3 style="margin-top:12px">${fmtD(cur.dt)}</h3><div class="chips">${cur.f.map(x=>chipHtml(d,cur.dt,x)).join('')}</div>`:`<div class="empty">ยังไม่มีเวลาว่างในช่วงนี้</div>`}${close.replace('ยกเลิก','ปิด')}`)}
  if(s.t==='book'){const d=doc(s.id);return wrap(`<h1 style="font-size:19px">ส่งคำขอจอง</h1>
   ${apptKV(d,s.date,s.time)}
   <label>อาการหรือเหตุผลที่มาพบ</label><textarea id="bk_note" placeholder="เช่น ปวดเข่าข้างขวา 3 วัน"></textarea>
   <p class="small" style="margin-top:10px">โรงพยาบาลจะตรวจสอบและยืนยันนัดให้ คุณดูสถานะได้ที่เมนู "นัดหมาย" ช่วงเวลานี้จะถูกกันไว้ให้คุณระหว่างรอ</p>
   <button class="btn" onclick="confirmBook()">ส่งคำขอจอง</button>${close}`)}
  if(s.t==='report'){const r=REPORTS.find(x=>x.id===s.id),d=r.doc?doc(r.doc):null;return wrap(`<div class="rcard">${rdate(r.vdate)}<div><h1 style="font-size:19px">ผลตรวจและยา</h1><p class="small">${fmtD(r.vdate)}</p><p class="small">${d?d.name:''}</p></div></div>
   <h3 style="margin-top:14px">การวินิจฉัย</h3><p>${r.dx}</p>
   <h3 style="margin-top:14px">รายการยา</h3>${r.meds.length?r.meds.map(m=>`<div class="med"><b>${m.n}</b><div class="small">${m.d}${m.days?` · ${m.days} วัน`:''}</div></div>`).join(''):'<p class="small">ไม่มียาที่สั่ง</p>'}
   <h3 style="margin-top:14px">คำแนะนำ</h3><p>${r.adv||'-'}</p>${r.fu&&!r.next?`<p style="margin-top:8px"><span class="tag amber">นัดติดตาม ${fmtD(r.fu)}</span></p>`:''}${r.next?slipHtml(r):''}
   ${r.files&&r.files.length?`<h3 style="margin-top:14px">ไฟล์แนบ</h3><div class="files">${r.files.map((f,i)=>f.type.startsWith('image/')?`<img class="att" src="${f.url}" alt="${f.name}" onclick="S.sheet={t:'img',rid:${r.id},i:${i}};render()">`:`<a class="fdoc" href="${f.url}" target="_blank" rel="noopener" download="${f.name}">${ic('file',16)} ${f.name}</a>`).join('')}</div>`:''}
   <button class="btn sec" onclick="S.sheet=null;render()">ปิด</button>`)}
  if(s.t==='img'){const r=REPORTS.find(x=>x.id===s.rid),f=r.files[s.i];return `<div class="scrim" onclick="if(event.target===this){S.sheet={t:'report',id:${r.id}};render()}"><div class="sheet"><img src="${f.url}" alt="${f.name}" style="width:100%;border-radius:12px"><p class="small" style="margin-top:8px">${f.name}</p><button class="btn sec" onclick="S.sheet={t:'report',id:${r.id}};render()">กลับ</button></div></div>`}
  if(s.t==='notifs'){const l=myNotifs().slice(0,40),un=unreadN();return wrap(`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h1 style="font-size:19px">การแจ้งเตือน</h1><div style="display:flex;gap:14px">${un?`<button class="link" style="margin:0" onclick="readAll()">อ่านทั้งหมด</button>`:''}${l.length?`<button class="link" style="margin:0" onclick="S.sheet={t:'clear',k:'notifications'};render()">ล้างทั้งหมด</button>`:''}</div></div>
   ${l.length?l.map(n=>`<button class="nrow ${n.readBy.includes(S.user.id)?'':'unread'}" onclick="readN(${n.id})"><span class="nd"></span><span class="nt">${n.text}<small>${ago(n.at)}</small></span><span aria-hidden="true">›</span></button>`).join(''):'<div class="empty">ยังไม่มีการแจ้งเตือน</div>'}${close.replace('ยกเลิก','ปิด')}`)}
  if(s.t==='search')return wrap(`<h1 style="font-size:19px">ค้นหาแพทย์</h1><input id="sr_in" type="search" placeholder="ค้นหาด้วยชื่อ หรือแผนก" oninput="srRefresh()" autocomplete="off" style="margin-top:10px"><div id="sr_out">${srList()}</div>
   <p class="small" style="margin:14px 0 8px;text-align:center"><b>หรือเลือกตามบริการ</b></p><div class="chips" style="justify-content:center">${DEPTS.map(d=>`<button class="pill" onclick="srDept('${d.id}')">${ic(d.ic,16)} ${d.n}</button>`).join('')}</div>${close.replace('ยกเลิก','ปิด')}`);
  if(s.t==='info'){
    const hh=HOSPS[0];
    const T={
     hospital:['ข้อมูลโรงพยาบาล',`<div class="kv"><span>ชื่อโรงพยาบาล</span><span style="text-align:right">${hh.n}</span></div><div class="kv"><span>จังหวัด</span><span>${hh.p}</span></div><div class="kv"><span>ที่อยู่</span><span style="text-align:right;max-width:65%">${hh.addr}</span></div><div class="kv"><span>เบอร์โทร</span><span>${hh.tel}</span></div><div class="kv" style="border:0"><span>เวลาทำการ</span><span style="text-align:right">${hh.hours}</span></div>`],
     howto:['วิธีการจอง',howSteps()],
     faq:['คำถามที่พบบ่อย','<div class="med"><b>ต้องมีบัญชีก่อนดูตารางแพทย์ไหม</b><div class="small">ไม่ต้อง ดูได้เลย ต้องมีบัญชีเมื่อจะส่งคำขอจองเท่านั้น</div></div><div class="med"><b>ยกเลิกนัดได้ไหม</b><div class="small">ได้ก่อนถึงเวลานัด ที่เมนู "นัดหมาย"</div></div><div class="med"><b>ถ้าไม่ไปตามนัดจะเป็นอย่างไร</b><div class="small">โรงพยาบาลบันทึกว่าไม่มาตามนัด ถ้าพลาดครบ 3 ครั้งใน 90 วัน จะจองนัดใหม่ไม่ได้ชั่วคราว</div></div><div class="med"><b>ผลตรวจและยาดูที่ไหน</b><div class="small">เมนู "ผลตรวจ/ยา" จะมีจุดแดงเมื่อมีรายงานใหม่</div></div>'],
     privacy:['ข้อมูลและความเป็นส่วนตัว','<p>MorHub TU ใช้ข้อมูลของคุณเพื่อจองนัดและประสานงานการรักษากับโรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติเท่านั้น</p><p style="margin-top:8px">ผู้ป่วยเห็นได้เฉพาะข้อมูลของตัวเอง เจ้าหน้าที่โรงพยาบาลเห็นข้อมูลของผู้ป่วยที่มีนัดกับโรงพยาบาล และผู้ดูแลระบบจัดการบัญชีผู้ใช้ ข้อมูลของคุณถูกเก็บไว้ในเบราว์เซอร์ของอุปกรณ์นี้</p><p style="margin-top:8px">หากต้องการขอดู แก้ไข หรือลบข้อมูล กรุณาติดต่อโรงพยาบาล</p>']};
    const t=T[s.k]||T.howto;return wrap(`<h1 style="font-size:19px">${t[0]}</h1>${t[1]}${close.replace('ยกเลิก','ปิด')}`)}
  if(s.t==='visit'){const b=BOOKS.find(x=>x.id===s.id),d=doc(b.doc),p=acct(b.pt),st=b.status;
   const opt=(k,l)=>`<button class="${st===k?'on':''}" onclick="setVisit(${b.id},'${k}')">${l}</button>`;
   const details=apptKV(d,b.date,b.time,{pt:p.name,note:b.note});
   const mid=st==='upcoming'&&needsReport(b)
     ?`<p><span class="tag ok">ผู้ป่วยยืนยันว่ามาตรวจแล้ว</span></p><button class="btn" onclick="S.sheet=null;startReport(${b.pt},${b.id})">ส่งผลตรวจและยา</button>`
     :st==='upcoming'
     ?`<button class="btn danger" onclick="S.sheet={t:'decline',id:${b.id}};render()">ยกเลิกนัด</button>`
     :(st==='seen'||st==='noshow')
       ?`<label>สถานะของนัด</label><div class="seg">${opt('upcoming','รอตรวจ')}${opt('seen','ตรวจแล้ว')}${opt('noshow','ไม่มาตามนัด')}</div>`
       :`<label>สถานะของนัด</label><p><span class="tag ${ST[st][1]}">${st==='cancelled'?(b.by==='hospital'?'โรงพยาบาลยกเลิก':'ยกเลิกแล้ว'):ST[st][0]}</span></p><p class="small" style="margin-top:6px">${st==='pending'||st==='proposed'?'คำขอนี้จัดการได้ที่เมนู "คำขอจอง"':st==='cancelled'&&b.reason?'เหตุผล: '+b.reason:''}</p>`;
   return wrap(`<h1 style="font-size:19px">รายละเอียดนัดหมาย</h1>${details}${mid}${close.replace('ยกเลิก','ปิด')}`)}
  if(s.t==='needlogin'){const d=doc(s.id);return wrap(`<h1 style="font-size:19px">เข้าสู่ระบบเพื่อจอง</h1>
   <p class="small">คุณเลือกนัดนี้</p>${apptKV(d,s.date,s.time)}
   <p style="margin-top:10px">ดูข้อมูลและตารางแพทย์ได้โดยไม่ต้องเข้าสู่ระบบ แต่การส่งคำขอจองต้องมีบัญชีผู้ป่วย เมื่อเข้าสู่ระบบแล้ว ระบบจะพากลับมาที่ช่วงเวลานี้ให้ทันที</p>
   <button class="btn" onclick="showLogin('login')">เข้าสู่ระบบ</button><button class="btn sec" onclick="showLogin('register')">สมัครสมาชิกใหม่</button>${close.replace('ยกเลิก','ดูต่อโดยไม่เข้าสู่ระบบ')}`)}
  if(s.t==='propose'){const b=BOOKS.find(x=>x.id===s.id),p=acct(b.pt),own=myDocs(),dsel=+(s.doc||b.doc),d=doc(dsel);
   const tm=s.date?slots(d,s.date,'all').filter(x=>x.free&&!isPast({date:s.date,time:x.t})):[];
   return wrap(`<h1 style="font-size:19px">เสนอเปลี่ยนหมอหรือวันนัด</h1><p class="small">คำขอเดิม</p>${apptKV(doc(b.doc),b.date,b.time,{pt:p.name})}
   <label>แพทย์</label><select id="pr_d" onchange="propChange()">${own.map(x=>`<option value="${x.id}" ${x.id===dsel?'selected':''}>${x.name} · ${dept(x.dept).n}</option>`).join('')}</select>
   <label>วันที่</label><input type="date" id="pr_date" min="${iso(new Date())}" value="${s.date||''}" onchange="propChange()">
   <label>เวลา</label>${!s.date?'<div class="small">เลือกวันที่ก่อน</div>':tm.length?`<select id="pr_t">${tm.map(x=>`<option value="${x.t}">${x.t}-${hr(x.t)} (ว่าง ${x.left})</option>`).join('')}</select>`:`<div class="small">ไม่มีช่วงเวลาว่างของแพทย์ท่านนี้ในวันนั้น (แพทย์ตรวจวัน ${d.wd.map(w=>WD[w]).join(' ')||'—'})</div>`}
   <label>เหตุผล (ผู้ป่วยจะเห็น)</label><input id="pr_r" value="${s.reason||''}" placeholder="เช่น แพทย์ไม่ว่างช่วงเวลาที่ขอ">
   <button class="btn" onclick="sendProp()">ส่งข้อเสนอให้ผู้ป่วย</button>${close}`)}
  if(s.t==='issue')return wrap(`<h1 style="font-size:19px">แจ้งปัญหา</h1><p class="small">เรื่องจะส่งถึงผู้ดูแลระบบเพื่อตรวจสอบ</p>
   <label>หัวข้อ</label><select id="is_k"><option>จองนัดไม่ได้ / ระบบขัดข้อง</option><option>โรงพยาบาลไม่ตอบหรือยืนยันช้า</option><option>ผลตรวจหรือยาไม่ถูกต้อง</option><option>บัญชีผู้ใช้</option><option>ข้อมูลโรงพยาบาลหรือแพทย์ไม่ถูกต้อง</option><option>อื่น ๆ</option></select>
   <label>รายละเอียด</label><textarea id="is_t" placeholder="อธิบายปัญหาที่พบ"></textarea>
   ${S.user?`<p class="small" style="margin-top:8px">ผู้แจ้ง: ${S.user.name} (บัญชีของคุณ)</p>`:`<label>ชื่อ</label><input id="is_n" autocomplete="name"><label>ช่องทางติดต่อกลับ (อีเมลหรือเบอร์โทร)</label><input id="is_c" autocomplete="email">`}
   <button class="btn" onclick="submitIssue()">ส่งเรื่อง</button>${close}`);
  if(s.t==='clear'){const k=CLEAR_TX[s.k];return wrap(`<h1 style="font-size:19px">${k[0]}</h1><p>${k[1]}</p><p class="small" style="margin-top:8px">ข้อมูลในระบบยังเก็บไว้ตามเดิม แต่ล้างแล้วจะย้อนกลับไม่ได้</p>
   <button class="btn danger" onclick="clearHistory('${s.k}')">ยืนยันล้างประวัติ</button>${close}`)}
  if(s.t==='mytickets'){const l=TICKETS.filter(t=>t.pt===S.user.id).sort((a,b)=>b.at-a.at);return wrap(`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h1 style="font-size:19px">เรื่องที่แจ้งไว้</h1>${l.some(t=>t.status==='resolved')?`<button class="link" style="margin:0" onclick="S.sheet={t:'clear',k:'tickets'};render()">ล้างเรื่องที่ดำเนินการแล้ว</button>`:''}</div>${l.length?l.map(t=>`<div class="med"><b>${t.topic||'แจ้งปัญหา'}</b> <span class="small">· ${ago(t.at)}</span><div>${t.text}</div><div class="small" style="margin-top:4px">${t.status==='open'?ic('clock',14)+' รอผู้ดูแลระบบตรวจสอบ':ic('check',14)+' ดำเนินการแล้ว'+(t.note?' — '+t.note:'')}</div></div>`).join(''):'<div class="empty">ยังไม่เคยแจ้งปัญหา</div>'}${close.replace('ยกเลิก','ปิด')}`)}
  if(s.t==='resolve'){const t=TICKETS.find(x=>x.id===s.id);return wrap(`<h1 style="font-size:19px">ดำเนินการเรื่องร้องเรียน</h1><p class="small">${tname(t)} · ${t.text}</p><label>บันทึกการดำเนินการ (ผู้ป่วยจะเห็น)</label><textarea id="rs_n" placeholder="เช่น ติดต่อโรงพยาบาลแล้ว ยืนยันนัดให้เรียบร้อย"></textarea><button class="btn" onclick="resolveTicket(${t.id})">บันทึกว่าดำเนินการแล้ว</button>${close}`)}
  if(s.t==='decline'){const b=BOOKS.find(x=>x.id===s.id),p=acct(b.pt),d=doc(b.doc),pend=b.status==='pending';
   return wrap(`<h1 style="font-size:19px">${pend?'ปฏิเสธคำขอจอง':'ยกเลิกนัดหมาย'}</h1>${apptKV(d,b.date,b.time,{pt:p.name})}
   <label>เหตุผล (ผู้ป่วยจะเห็นข้อความนี้)</label><select id="dc_r"><option>ช่วงเวลานี้เต็ม</option><option>แพทย์ไม่สะดวก / ติดภารกิจ</option><option>ข้อมูลผู้ป่วยไม่ครบ</option><option>ควรพบแพทย์แผนกอื่น</option><option>อื่น ๆ</option></select>
   <label>หมายเหตุเพิ่มเติม (ไม่บังคับ)</label><input id="dc_n">
   <button class="btn danger" onclick="confirmDecline(${b.id})">${pend?'ยืนยันปฏิเสธ':'ยืนยันยกเลิกนัด'}</button>${close}`)}
  if(s.t==='mystaff')return wrap(`<h1 style="font-size:19px">เพิ่มบัญชีเจ้าหน้าที่</h1><p class="small">บัญชีใหม่จะสังกัด ${hn(myHid())} และเห็นข้อมูลเดียวกันกับบัญชีอื่นของโรงพยาบาลนี้</p>
   <label>ชื่อ-นามสกุล</label><input id="ms_n"><label>อีเมล (ใช้เข้าสู่ระบบ)</label><input id="ms_e" type="email"><label>เบอร์โทร</label><input id="ms_p" type="tel">
   <label>รหัสผ่านเริ่มต้น (อย่างน้อย 8 ตัวอักษร)</label><input id="ms_w">
   <button class="btn" onclick="addMyStaff()">เพิ่มบัญชี</button>${close}`);
  if(s.t==='noshow'){const b=BOOKS.find(x=>x.id===s.id),p=acct(b.pt);return wrap(`<h1 style="font-size:19px">บันทึกว่าไม่มาตามนัด</h1>${apptKV(doc(b.doc),b.date,b.time,{pt:p.name})}
   <p style="margin-top:12px">ผู้ป่วยจะเห็นสถานะนี้ในนัดหมายของเขา และนับเป็นการพลาดนัด 1 ครั้ง หากพลาดครบ 3 ครั้งภายใน 90 วัน จะจองนัดใหม่ไม่ได้ชั่วคราว ถ้าบันทึกผิดสามารถย้อนกลับได้</p>
   <button class="btn danger" onclick="confirmNoShow(${b.id})">ยืนยัน ไม่มาตามนัด</button>${close}`)}
  if(s.t==='staff')return wrap(`<h1 style="font-size:19px">สร้างบัญชีเจ้าหน้าที่ / แอดมิน</h1>
   <label>ประเภทบัญชี</label><select id="iv_r" onchange="S.sheet.r=this.value;render()"><option value="tech" ${s.r!=='admin'?'selected':''}>เจ้าหน้าที่ รพ.</option><option value="admin" ${s.r==='admin'?'selected':''}>แอดมิน</option></select>
   <label>ชื่อ-นามสกุล</label><input id="iv_n"><label>อีเมล (ใช้เข้าสู่ระบบ)</label><input id="iv_e" type="email"><label>เบอร์โทร</label><input id="iv_p" type="tel">
   <label>รหัสผ่านเริ่มต้น (อย่างน้อย 8 ตัวอักษร)</label><input id="iv_w">
   <button class="btn" onclick="addStaff()">สร้างบัญชี</button>${close}`);
  if(s.t==='hosp')return wrap(`<h1 style="font-size:19px">เพิ่มโรงพยาบาล</h1><label>ชื่อโรงพยาบาล</label><input id="hp_n"><label>จังหวัด</label><input id="hp_p">
   <button class="btn" onclick="addHosp()">เพิ่มโรงพยาบาล</button>${close}`);
  if(s.t==='pw')return wrap(`<h1 style="font-size:19px">เปลี่ยนรหัสผ่าน</h1><label>รหัสผ่านเดิม</label><input id="pw_o" type="password" autocomplete="current-password"><label>รหัสผ่านใหม่</label><input id="pw_n" type="password" autocomplete="new-password"><label>ยืนยันรหัสผ่านใหม่</label><input id="pw_c" type="password" autocomplete="new-password">
   <button class="btn" onclick="changePw()">บันทึก</button>${close}`);
  return '';
}
function changePw(){
  if(S.imp){toast('ขณะใช้งานแทนผู้อื่น เปลี่ยนรหัสผ่านไม่ได้');return}
  if($('pw_o')!==S.user.pw){toast('รหัสผ่านเดิมไม่ถูกต้อง');return}
  if(($('pw_n')||'').length<6){toast('รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร');return}
  if($('pw_n')!==$('pw_c')){toast('ยืนยันรหัสผ่านไม่ตรงกัน');return}
  S.user.pw=$('pw_n');S.sheet=null;render();toast('เปลี่ยนรหัสผ่านแล้ว');
}

