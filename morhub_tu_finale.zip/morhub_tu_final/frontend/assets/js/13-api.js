/* ================= API CONNECTOR =================
   Loaded after the main script in index.html. It replaces the prototype's localStorage
   storage and every action that changes data with calls to the Node.js API (/api/...).
   The rendering code is untouched: data from the API is mapped into the same arrays
   (HOSPS, DOCS, ACCTS, BOOKS, REPORTS, TICKETS, NOTIFS) the screens already read. */

const API='/api',TKEY='morhubtu_token',AKEY='morhubtu_admin_token';
let TOKEN=null,ADMIN_TOKEN=null,SLOT_USED=new Map(),BUSY=false,CLEARED={};   // CLEARED: kind -> ms when this account last cleared it
try{TOKEN=sessionStorage.getItem(TKEY);ADMIN_TOKEN=sessionStorage.getItem(AKEY)}catch(e){}
function setToken(t){TOKEN=t;try{t?sessionStorage.setItem(TKEY,t):sessionStorage.removeItem(TKEY)}catch(e){}}
function setAdminToken(t){ADMIN_TOKEN=t;try{t?sessionStorage.setItem(AKEY,t):sessionStorage.removeItem(AKEY)}catch(e){}}

async function api(path,opts={}){
  const res=await fetch(API+path,{method:opts.method||'GET',
    headers:{'Content-Type':'application/json',...(TOKEN?{Authorization:'Bearer '+TOKEN}:{})},
    body:opts.body!==undefined?JSON.stringify(opts.body):undefined});
  let data={};try{data=await res.json()}catch(e){}
  if(!res.ok){
    const err=new Error((LANG==='en'?data.message_en:data.message)||data.message||(LANG==='en'?'Something went wrong':'เกิดข้อผิดพลาด'));
    err.status=res.status;
    if(res.status===401&&TOKEN&&!opts.noLogout){setToken(null);setAdminToken(null);logout();toast(err.message)}
    throw err;
  }
  return data;
}
const okMsg=r=>(LANG==='en'?r.message_en:r.message)||r.message||'';
// Wraps an action: one request at a time, errors shown as a toast.
const action=fn=>async function(...args){
  if(BUSY)return;BUSY=true;document.body.style.cursor='progress';
  try{return await fn.apply(this,args)}
  catch(e){if(e.status!==401)toast(e.message)}
  finally{BUSY=false;document.body.style.cursor=''}
};

/* ---------- API rows -> the objects the screens use ----------
   The screens build HTML with innerHTML, so every free-text field typed by a user
   (names, notes, reasons, diagnoses ...) is HTML-escaped here. Without this, one
   patient could put a <script> in their name and run it in a staff/admin browser. */
const num=v=>v==null?null:Number(v);
const esc=v=>v==null?'':String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mapHosp=h=>({id:h.hospital_id,n:esc(h.hospital_name),p:esc(h.province),addr:esc(h.address),tel:esc(h.phone),hours:esc(h.opening_hours),img:h.photo||undefined});
function mapDoctor(d){
  const sess=[...new Map(d.schedules.map(s=>[s.start_time+'-'+s.end_time,[s.start_time,s.end_time]])).values()].sort((a,b)=>a[0].localeCompare(b[0]));
  return {id:d.doctor_id,hid:d.hospital_id,name:esc((d.title||'')+d.full_name),dept:d.dept_code,room:esc(d.room)||'-',
    exp:d.experience_years!=null?d.experience_years+' ปี':'-',wd:[...new Set(d.schedules.map(s=>s.weekday))].sort(),
    s1:sess[0]?sess[0][0]:'',e1:sess[0]?sess[0][1]:'',s2:sess[1]?sess[1][0]:'',e2:sess[1]?sess[1][1]:'',cap:d.slot_capacity,
    img:d.photo||'',title:esc(d.headline),edu:d.education_en==null?null:esc(d.education_en),eduTh:d.education_th==null?null:esc(d.education_th),eduSeeded:true};
}
const mapAcct=a=>({id:a.account_id,role:a.role==='staff'?'tech':a.role,name:esc(a.full_name),email:esc(a.email),phone:esc(a.phone),
  hid:a.hospital_id||undefined,dpt:esc(a.work_unit),hn:esc(a.hn),dob:a.date_of_birth||'',allergy:esc(a.allergies),
  photo:a.photo||undefined,on:a.status==='active',pending:a.status==='pending',co:a.role==='admin'?'MorHub TU':undefined});
function mapBook(a){
  const b={id:a.appointment_id,doc:a.doctor_id,pt:a.patient_id,date:a.appt_date,time:a.appt_time,status:a.status,note:esc(a.symptom_note),
    at:num(a.created_ms),fu:!!a.is_follow_up,fuOf:a.follow_up_of,nudged:!!a.nudged,staleNoti:true,gate:a.admin_gate||null,visited:!!a.visited_at,upd:num(a.updated_ms)};
  if(a.cancelled_by){b.by=a.cancelled_by;b.reason=esc(a.cancel_reason)}
  if(Number(a.changed))b.changedFrom={};
  if(a.new_doctor_id)b.prop={doc:a.new_doctor_id,date:a.new_date,time:a.new_time,reason:esc(a.proposal_reason),by:esc(a.proposed_by_name),at:num(a.proposed_ms)};
  if(b.status==='proposed'&&!b.prop)b.status='pending';
  return b;
}
const mapReport=r=>({id:r.report_id,pt:r.patient_id,hid:r.hospital_id,bk:r.appointment_id,vdate:r.visit_date,doc:r.doctor_id,dx:esc(r.diagnosis),
  meds:r.meds.map(m=>({n:esc(m.drug_name),d:esc(m.dosage),days:m.duration_days||''})),adv:esc(r.advice),fu:'',
  next:r.next_appointment_id&&r.next_date?{bk:r.next_appointment_id,doc:r.next_doctor_id,date:r.next_date,time:r.next_time}:null,
  closed:!!r.is_closed,by:esc(r.created_by_name),seen:!!r.seen_by_patient,ok:!!Number(r.admin_ok),files:r.files.map(f=>({name:esc(f.file_name),type:f.mime_type,url:f.data_url})),at:r.created_date});
const mapTicket=t=>({id:t.ticket_id,pt:t.patient_id,name:esc(t.guest_name),contact:esc(t.guest_contact||t.patient_email),topic:esc(t.topic),
  bk:t.appointment_id,hid:t.hospital_id,text:esc(t.message),status:t.status,note:esc(t.resolution_note),at:num(t.created_ms),done:num(t.resolved_ms)});
const mapNotif=uid=>n=>({id:n.notification_id,text:esc(n.message),tab:n.link_tab||'',at:num(n.created_ms),readBy:Number(n.is_read)?[uid]:[],
  to:n.target_type==='account'?'u:'+n.target_account_id:n.target_type==='hospital'?'h:'+n.target_hospital_id:'admin',
  rq:n.target_type==='admin'&&String(n.message).startsWith('คำขอจองค้างนาน')?'stale':undefined});

async function loadAll(){
  const [h,d,s]=await Promise.all([api('/hospitals'),api('/doctors'),api('/appointments/slots')]);
  HOSPS=h.data.map(mapHosp);DOCS=d.data.map(mapDoctor);
  SLOT_USED=new Map(s.data.map(x=>[x.doctor_id+'|'+x.date+'|'+x.time,Number(x.used)]));
  if(!TOKEN){S.user=null;S.role=null;ACCTS=[];BOOKS=[];REPORTS=[];TICKETS=[];NOTIFS=[];return}
  const me=(await api('/auth/me')).user,role=me.role,none=Promise.resolve({data:[]});
  const [appts,notifs,reports,accounts,tickets,cleared]=(await Promise.all([api('/appointments'),api('/notifications'),
    api('/reports'),role!=='patient'?api('/accounts'):none,role!=='staff'?api('/tickets'):none,api('/history')])).map(r=>r.data);
  // Cleared history only leaves this account's lists; handled complaints and old notifications stay in the database
  CLEARED=cleared;
  const after=(k,ms)=>!CLEARED[k]||!ms||Number(ms)>CLEARED[k];
  const user=mapAcct(me),byId=new Map([[user.id,user]]);
  accounts.forEach(a=>{if(!byId.has(a.account_id))byId.set(a.account_id,mapAcct(a))});
  appts.forEach(a=>{if(!byId.has(a.patient_id))byId.set(a.patient_id,{id:a.patient_id,role:'patient',name:esc(a.patient_name),email:esc(a.patient_email),
    phone:esc(a.patient_phone),hn:esc(a.hn),dob:a.date_of_birth||'',allergy:esc(a.allergies),on:true})});
  ACCTS=[...byId.values()];BOOKS=appts.map(mapBook);REPORTS=reports.map(mapReport);
  TICKETS=tickets.filter(t=>t.status!=='resolved'||after('tickets',t.resolved_ms)).map(mapTicket);
  NOTIFS=notifs.filter(n=>after('notifications',n.created_ms)).map(mapNotif(user.id));
  S.user=user;S.role=user.role;S.imp=me.act_by?{adminId:me.act_by}:null;
}
async function refresh(){await loadAll();render()}

/* ---------- replace localStorage persistence ---------- */
saveData=function(){};
loadData=function(){return false};
resetData=function(){location.reload()};
notify=function(){};              // the server creates notifications
checkStale=function(){return 0};  // the server flags overdue requests
// Free seats come from the server, so every patient sees the same availability.
slots=function(d,date,per){
  if(!d.wd.includes(new Date(date+'T00:00').getDay()))return [];
  const cap=d.cap||1;
  return slotTimes(d,per).map(t=>{const left=Math.max(cap-(SLOT_USED.get(d.id+'|'+date+'|'+t)||0),0);return {t,left,free:left>0}});
};
const uiBusy=()=>typing()||S.sheet||S.auth||S.docForm||S.reportBk||S.editProfile||S.editHosp||S.calOpen||S.menuOpen||S.aboutOpen||S.langMenu||S.apMenu||BUSY;
applyRemote=function(){if(TOKEN&&!uiBusy()&&!document.hidden)refresh().catch(()=>{})};

/* ---------- auth ---------- */
doLogin=action(async function(){
  const u=($('lg_u')||'').trim(),p=$('lg_p')||'';S.lu=u;
  try{setToken((await api('/auth/login',{method:'POST',body:{email:u,password:p},noLogout:true})).token)}
  catch(e){S.err=e.message;render();return}
  await loadAll();enter(S.user);
});
doRegister=action(async function(){
  keepRg();const r=S.rg;
  if(!r.name||!r.phone||!r.email||!r.pw){S.err='กรอกข้อมูลให้ครบทุกช่อง';render();return}
  if(r.pw!==r.pw2){S.err='ยืนยันรหัสผ่านไม่ตรงกัน';render();return}
  let res;
  try{res=await api('/auth/register',{method:'POST',noLogout:true,body:{role:r.role==='tech'?'staff':'patient',full_name:r.name,email:r.email,password:r.pw,phone:r.phone,work_unit:r.dpt||null,hospital_id:1}})}
  catch(e){S.err=e.message;render();return}
  S.rg={};
  if(res.pending){S.mode='login';S.err=null;S.info=okMsg(res);render();return}
  setToken((await api('/auth/login',{method:'POST',body:{email:r.email,password:r.pw}})).token);
  await loadAll();enter(S.user);toast('สร้างบัญชีสำเร็จ ยินดีต้อนรับ');
});
const _logout=logout;
logout=function(){setToken(null);setAdminToken(null);CLEARED={};ACCTS=[];BOOKS=[];REPORTS=[];TICKETS=[];NOTIFS=[];_logout()};
changePw=action(async function(){
  if($('pw_n')!==$('pw_c')){toast('ยืนยันรหัสผ่านไม่ตรงกัน');return}
  const r=await api('/auth/change-password',{method:'PATCH',body:{current_password:$('pw_o'),new_password:$('pw_n')}});
  S.sheet=null;render();toast(okMsg(r));
});

/* ---------- profile, hospital, photos ---------- */
const PF_API={name:'full_name',phone:'phone',dob:'date_of_birth',allergy:'allergies',dpt:'work_unit'};
saveProfile=action(async function(){
  const body={};document.querySelectorAll('.pf').forEach(i=>{if(!i.readOnly&&PF_API[i.dataset.k])body[PF_API[i.dataset.k]]=i.value.trim()});
  if(!body.full_name){toast('กรุณากรอกชื่อ');return}
  const r=await api('/auth/me',{method:'PATCH',body});S.editProfile=false;await refresh();toast(okMsg(r));
});
setMyPhoto=action(async function(inp){
  const f=inp.files[0];inp.value='';if(!f)return;
  if(!f.type.startsWith('image/')){toast('เลือกไฟล์รูปภาพ');return}
  const url=await readImg(f,400,.8);if(!url){toast('อ่านรูปไม่สำเร็จ');return}
  await api('/auth/me',{method:'PATCH',body:{photo:url}});await refresh();toast('อัปเดตรูปโปรไฟล์แล้ว');
});
delMyPhoto=action(async function(){await api('/auth/me',{method:'PATCH',body:{photo:null}});await refresh()});
saveHosp=action(async function(){
  const map={addr:'address',tel:'phone',hours:'opening_hours'},body={};
  document.querySelectorAll('.hf').forEach(i=>{body[map[i.dataset.k]]=i.value.trim()});
  const r=await api('/hospitals/'+S.user.hid,{method:'PATCH',body});S.editHosp=false;await refresh();toast(okMsg(r));
});
setHospImg=action(async function(inp,id){
  const f=inp.files[0];inp.value='';if(!f)return;
  if(!f.type.startsWith('image/')){toast('เลือกไฟล์รูปภาพ');return}
  const url=await readImg(f,900,.78);if(!url){toast('อ่านรูปไม่สำเร็จ');return}
  await api('/hospitals/'+id,{method:'PATCH',body:{photo:url}});await refresh();toast('อัปเดตรูปโรงพยาบาลแล้ว');
});
addHosp=action(async function(){
  const r=await api('/hospitals',{method:'POST',body:{hospital_name:($('hp_n')||'').trim(),province:($('hp_p')||'').trim()}});
  S.sheet=null;await refresh();toast(okMsg(r));
});

/* ---------- patient: booking, cancelling, proposals, problems ---------- */
confirmBook=action(async function(){
  if(S.role==='tech'){BUSY=false;return confirmStaffBook()}
  const s=S.sheet,note=($('bk_note')||'').trim();
  if(!note){markReq([['bk_note']]);return}
  try{await api('/appointments',{method:'POST',body:{doctor_id:s.id,appt_date:s.date,appt_time:s.time,symptom_note:note}})}
  catch(e){await loadAll();throw e}
  S.sheet=null;S.sub=null;S.tab='appts';await refresh();window.scrollTo(0,0);toast('ส่งคำขอจองแล้ว รอแอดมินตรวจสอบ');
});
confirmStaffBook=action(async function(){
  const s=S.sheet,name=($('bk_pn')||'').trim(),phone=($('bk_pp')||'').trim(),note=($('bk_note')||'').trim();
  const miss=[];if(name.length<2)miss.push(['bk_pn']);
  if(!phone)miss.push(['bk_pp']);else if(digitsOf(phone).length<9)miss.push(['bk_pp',LANG==='en'?'Invalid phone number':'เบอร์โทรไม่ถูกต้อง']);
  if(!note)miss.push(['bk_note']);
  if(miss.length){markReq(miss);return}
  const r=await api('/appointments/staff-book',{method:'POST',body:{doctor_id:s.id,appt_date:s.date,appt_time:s.time,symptom_note:note,
    name,phone,hn:($('bk_ph')||'').trim(),dob:$('bk_pd')||null,allergies:($('bk_pa')||'').trim()||null}});
  S.sheet=null;S.sub=null;await loadAll();go('patients');openPt(r.patient_id);toast(okMsg(r));
});
const clearHistory=action(async function(k){const r=await api(`/history/${k}/clear`,{method:'POST'});S.sheet=null;await refresh();toast(okMsg(r))});
const confirmVisit=action(async function(id){const r=await api(`/appointments/${id}/visited`,{method:'POST'});await refresh();toast(okMsg(r))});
cancelBk=action(async function(id){await api(`/appointments/${id}/cancel`,{method:'PATCH',body:{}});await refresh();toast('ยกเลิกนัดแล้ว')});
acceptProp=action(async function(id){const r=await api(`/appointments/${id}/proposal/accept`,{method:'POST'});await refresh();toast(okMsg(r))});
declineProp=action(async function(id){const r=await api(`/appointments/${id}/proposal/decline`,{method:'POST'});await refresh();toast(okMsg(r))});
submitIssue=action(async function(){
  const r=await api('/tickets',{method:'POST',body:{topic:$('is_k')||'',message:($('is_t')||'').trim(),
    appointment_id:S.sheet&&S.sheet.bk||null,guest_name:($('is_n')||'').trim(),guest_contact:($('is_c')||'').trim()}});
  S.sheet=null;if(TOKEN)await refresh();else render();toast(okMsg(r));
});
const _openReport=openReport;
openReport=function(id){
  const r=REPORTS.find(x=>x.id===id),unseenBefore=r&&!r.seen&&S.role==='patient';
  _openReport(id);
  if(unseenBefore)api(`/reports/${id}/seen`,{method:'PATCH'}).catch(()=>{});
};

/* ---------- notifications ---------- */
const _readN=readN,_readAll=readAll;
readN=function(id){api(`/notifications/${id}/read`,{method:'POST'}).catch(()=>{});_readN(id)};
readAll=function(){api('/notifications/read-all',{method:'POST'}).catch(()=>{});_readAll()};

/* ---------- staff: doctors ---------- */
saveDoc=action(async function(){
  keepForm();const f=S.docForm;
  if(!f.name){toast('กรอกชื่อแพทย์ก่อน');return}
  if(!f.wd||!f.wd.length){toast('เลือกวันที่ตรวจอย่างน้อย 1 วัน');return}
  if(!f.s1||!f.e1||f.s1>=f.e1){toast('ตั้งเวลาตรวจช่วงที่ 1 ให้ถูกต้อง');return}
  if((f.s2||f.e2)&&(!f.s2||!f.e2||f.s2>=f.e2)){toast('เวลาตรวจช่วงที่ 2 ไม่ถูกต้อง');return}
  const body={name:f.name,dept:f.dept,room:f.room,exp:f.exp,cap:f.cap,wd:f.wd,img:f.img||'',title:(f.title||'').trim(),
    sessions:[[f.s1,f.e1],...(f.s2&&f.e2?[[f.s2,f.e2]]:[])]};
  body[LANG==='th'?'eduTh':'edu']=(f.eduTxt||'').trim();
  const r=await api(f.edit?'/doctors/'+f.id:'/doctors',{method:f.edit?'PUT':'POST',body});
  S.tdept=f.dept;S.docForm=null;await refresh();
  toast(okMsg(r)+(r.conflicts?` · มี ${r.conflicts} นัดที่ไม่ตรงกับตารางใหม่ กรุณาตรวจสอบ`:''));
});
delDoc=action(async function(id){
  try{await api('/doctors/'+id,{method:'DELETE'})}catch(e){S.sheet=null;render();throw e}
  S.sheet=null;S.docForm=null;S.sub=null;S.docPage=true;S.backTo=null;await refresh();window.scrollTo(0,0);toast('ลบแพทย์แล้ว');
});

/* ---------- staff: requests, visits, reports ---------- */
const VISIT_MSG={upcoming:'ตั้งเป็นรอตรวจแล้ว',seen:'บันทึกว่าตรวจแล้ว',noshow:'บันทึกว่าไม่มาตามนัดแล้ว'};
const setStatus=async(id,status)=>{await api(`/appointments/${id}/status`,{method:'PATCH',body:{status}});S.sheet=null;await refresh();toast(VISIT_MSG[status])};
setVisit=action(async function(id,st){const b=BOOKS.find(x=>x.id===id);if(!b||b.status===st)return;await setStatus(id,st)});
markSeen=action(async function(id){await setStatus(id,'seen')});
confirmNoShow=action(async function(id){await setStatus(id,'noshow')});
undoMark=action(async function(id){await setStatus(id,'upcoming')});
acceptReq=action(async function(id){const r=await api(`/appointments/${id}/confirm`,{method:'PATCH'});await refresh();toast(okMsg(r))});
confirmDecline=action(async function(id){
  const n=($('dc_n')||'').trim();
  await api(`/appointments/${id}/cancel`,{method:'PATCH',body:{reason:$('dc_r')+(n?' — '+n:'')}});
  S.sheet=null;await refresh();toast(S.role==='tech'?'บันทึกแล้ว รอแอดมินส่งเหตุผลให้ผู้ป่วย':'บันทึกแล้ว ผู้ป่วยจะเห็นเหตุผล');
});
sendProp=action(async function(){
  const s=S.sheet,b=BOOKS.find(x=>x.id===s.id),dd=+$('pr_d'),date=$('pr_date'),time=$('pr_t');
  if(!date){markReq([['pr_date']]);return}
  if(!time){markReq([['pr_date',LANG==='en'?'No free time on this day':'ไม่มีเวลาว่างในวันนี้']]);return}
  if(dd===b.doc&&date===b.date&&time===b.time){toast('ตรงกับคำขอเดิม ใช้ปุ่ม "ยืนยันนัด" แทน');return}
  const r=await api(`/appointments/${s.id}/propose`,{method:'POST',body:{doctor_id:dd,date,time,reason:($('pr_r')||'').trim()}});
  S.sheet=null;await refresh();toast(okMsg(r));
});
withdrawProp=action(async function(id){const r=await api(`/appointments/${id}/proposal/withdraw`,{method:'POST'});await refresh();toast(okMsg(r))});
sendReport=action(async function(){
  keepReport();
  if(!S.rpPt){toast('เลือกผู้ป่วยก่อน');return}
  if(S.rpBk&&S.rpSt==='noshow'){
    await api(`/appointments/${S.rpBk}/status`,{method:'PATCH',body:{status:'noshow'}});
    S.reportBk=null;await refresh();toast('บันทึกว่าไม่มาตามนัดแล้ว');return}
  const n=S.rpNext;
  if(n.on&&(!n.doc||!n.date||!n.time)){toast('ระบุแพทย์ วันที่ และเวลาของนัดต่อให้ครบ');return}
  const r=await api('/reports',{method:'POST',body:{patient_id:+S.rpPt,appointment_id:S.rpBk?+S.rpBk:null,visit_date:S.rpDate,
    doctor_id:S.rpDoc?+S.rpDoc:null,diagnosis:(S.rpDx||'').trim(),advice:S.rpAdv||'',meds:S.meds,files:S.rpFiles,
    next:n.on?{doctor_id:+n.doc,date:n.date,time:n.time}:null}});
  S.reportBk=null;await refresh();toast(okMsg(r));
});
addMyStaff=action(async function(){
  const r=await api('/accounts',{method:'POST',body:{name:($('ms_n')||'').trim(),email:($('ms_e')||'').trim(),phone:($('ms_p')||'').trim(),password:$('ms_w')||''}});
  S.sheet=null;await refresh();toast(okMsg(r));
});

/* ---------- admin ---------- */
addStaff=action(async function(){
  const r=await api('/accounts',{method:'POST',body:{role:S.sheet.r==='admin'?'admin':'staff',hid:S.sheet.hid||1,
    name:($('iv_n')||'').trim(),email:($('iv_e')||'').trim(),phone:($('iv_p')||'').trim(),password:$('iv_w')||''}});
  if(S.sheet.r==='admin')S.acctF='admin';S.sheet=null;await refresh();toast(okMsg(r));
});
approveAcct=action(async function(id){await api(`/accounts/${id}/status`,{method:'PATCH',body:{status:'active'}});await refresh();toast('อนุมัติบัญชีแล้ว เข้าสู่ระบบได้ทันที')});
rejectAcct=action(async function(id){const r=await api(`/accounts/${id}`,{method:'DELETE'});await refresh();toast(okMsg(r))});
togAcct=action(async function(id){
  const a=ACCTS.find(x=>x.id===id);
  const r=await api(`/accounts/${id}/status`,{method:'PATCH',body:{status:a.on?'disabled':'active'}});await refresh();toast(okMsg(r));
});
resolveTicket=action(async function(id){
  const r=await api(`/tickets/${id}/resolve`,{method:'PATCH',body:{note:($('rs_n')||'').trim()}});S.sheet=null;await refresh();toast(okMsg(r));
});
nudgeHosp=action(async function(id){const r=await api(`/appointments/${id}/nudge`,{method:'POST'});await refresh();toast(okMsg(r))});
// The admin is the middle step: forward requests to the hospital, release answers and reports to the patient
const fwdReq=action(async function(id){const r=await api(`/appointments/${id}/forward`,{method:'POST'});await refresh();toast(okMsg(r))});
const releaseReply=action(async function(id){const r=await api(`/appointments/${id}/release`,{method:'POST'});await refresh();toast(okMsg(r))});
const approveReport=action(async function(id){const r=await api(`/reports/${id}/approve`,{method:'PATCH'});S.sheet=null;await refresh();toast(okMsg(r))});
enterAs=action(async function(id){
  const r=await api(`/accounts/${id}/act-as`,{method:'POST',body:{}});
  setAdminToken(TOKEN);setToken(r.token);await loadAll();
  S.tab='home';S.sub=null;S.sheet=null;S.docForm=null;S.reportBk=null;S.ptView=null;S.acctHosp=null;S.editProfile=false;S.f={hosp:'',dept:'',date:'',time:'all'};
  render();window.scrollTo(0,0);
});
exitImp=action(async function(){
  if(!ADMIN_TOKEN){logout();return}
  setToken(ADMIN_TOKEN);setAdminToken(null);await loadAll();
  S.tab='accts';S.sub=null;S.sheet=null;S.docForm=null;S.reportBk=null;S.ptView=null;render();window.scrollTo(0,0);
});

/* ---------- start ---------- */
addTx({'รหัสผ่าน (อย่างน้อย 8 ตัวอักษร)':'Password (at Least 8 Characters)','รหัสผ่านเริ่มต้น (อย่างน้อย 8 ตัวอักษร)':'Initial Password (at Least 8 Characters)',
  'กำลังโหลดข้อมูล...':'Loading...','เชื่อมต่อเซิร์ฟเวอร์ไม่ได้':'Cannot reach the server'});
// Admin as the middle step: inbox, status tags, buttons and the server's notification texts
addTx({'รอแอดมินดำเนินการ':'Waiting for Admin','คำขอใหม่ → ส่งต่อ รพ.':'New requests → forward to hospital','คำตอบ รพ. → ส่งผู้ป่วย':"Hospital answers → send to patient",
  'มาตรวจแล้ว → ส่งต่อ รพ.':'Visited → forward to hospital','ผลตรวจ/ยา → อนุมัติ':'Results & meds → approve','คำขอที่อยู่กับโรงพยาบาล':'Requests with the Hospital',
  'ส่งต่อให้ รพ. เพื่อส่งผลตรวจและยา':'Forward to Hospital for Results & Medication','ส่งต่อให้ รพ.':'Forward to Hospital','โรงพยาบาลเสนอเวลาใหม่:':'Hospital proposed a new time:',
  'โรงพยาบาลปฏิเสธ/ยกเลิก':'Hospital declined/cancelled','โรงพยาบาลยืนยันนัดแล้ว':'Hospital confirmed the appointment','ผู้ป่วยยืนยันว่ามาตรวจแล้ว':'Patient confirmed the visit',
  'วันที่ตรวจ':'Visit date','ส่งโดย':'Sent by','การวินิจฉัย:':'Diagnosis:','ยา: ไม่มี':'Meds: none','อนุมัติและส่งให้ผู้ป่วย':'Approve & Send to Patient','ดูรายงานเต็ม':'View Full Report',
  'ไม่มีคำขอใหม่จากผู้ป่วย':'No new requests from patients','ไม่มีคำตอบจากโรงพยาบาลที่รอส่ง':'No hospital answers waiting to be sent',
  'ไม่มีผู้ป่วยที่ยืนยันมาตรวจรอส่งต่อ':'No confirmed visits waiting to be forwarded','ไม่มีรายงานที่รออนุมัติ':'No reports waiting for approval',
  'รอแอดมินตรวจสอบ':'Waiting for admin review','รอแอดมินส่งให้ผู้ป่วย':'Waiting for admin to send to patient','ผู้ป่วยยืนยันมาตรวจ · รอแอดมิน':'Patient confirmed visit · waiting for admin',
  'รอแอดมินอนุมัติ':'Waiting for admin approval','ยืนยันมาตรวจแล้ว · รอแอดมิน':'Visit confirmed · waiting for admin','รอผลตรวจและยาจากโรงพยาบาล':'Waiting for results & medication from the hospital',
  'ยืนยันว่ามาตรวจแล้ว':'Confirm I Visited','มาตรวจแล้ว · รอส่งผลตรวจและยา':'Visited · Results & Medication Needed','ยืนยันมาตรวจแล้ว':'Visit confirmed','ส่งผลตรวจและยา':'Send Results & Medication',
  'ส่งคำขอจองแล้ว รอแอดมินตรวจสอบ':'Booking request sent. Waiting for admin review','บันทึกแล้ว รอแอดมินส่งเหตุผลให้ผู้ป่วย':'Saved. Waiting for the admin to send the reason to the patient',
  // notification texts written by the server
  '· รอส่งต่อให้โรงพยาบาล':'· waiting to be forwarded to the hospital','· รอส่งให้ผู้ป่วย':'· waiting to be sent to the patient','โรงพยาบาลยืนยันนัดกับ':'Hospital confirmed the appointment with',
  'คำขอจองถูกปฏิเสธ':'Booking request declined','นัดถูกยกเลิก':'Appointment cancelled','แอดมินยกเลิกนัด':'Admin cancelled the appointment',
  'โรงพยาบาลถอนข้อเสนอเปลี่ยนนัดก่อนส่งถึงผู้ป่วย':'Hospital withdrew its proposal before it reached the patient','ยืนยันว่ามาตรวจแล้ว ·':'confirmed the visit ·',
  'มาตรวจแล้ว ·':'visited ·','· กรุณาส่งผลตรวจและยา':'· please send results & medication','รายงานผลตรวจและยาใหม่ของ':'New results & medication report for',
  '· รออนุมัติ':'· waiting for approval','· การนัดครั้งนี้เสร็จสิ้นแล้ว':'· this appointment is complete'});
// Clear history
addTx({'ล้างการแจ้งเตือนทั้งหมด':'Clear All Notifications','การแจ้งเตือนทั้งหมดตอนนี้จะหายไปจากรายการของคุณ การแจ้งเตือนใหม่จะยังเข้ามาตามปกติ':'All current notifications will be removed from your list. New notifications will still arrive as usual.',
  'ล้างประวัตินัดหมาย':'Clear Appointment History','นัดที่ตรวจแล้ว ยกเลิก หรือไม่มาตามนัด จะหายไปจากรายการของคุณ นัดที่กำลังจะถึงและผลตรวจ/ยายังอยู่ครบ':'Completed, cancelled and missed appointments will be removed from your list. Upcoming appointments and your results & medication stay.',
  'ล้างประวัติเรื่องที่ดำเนินการแล้ว':'Clear Resolved History','ล้างเรื่องที่ดำเนินการแล้ว':'Clear Resolved Items','เรื่องที่ดำเนินการแล้วจะหายไปจากรายการของคุณ เรื่องที่ยังค้างอยู่ยังแสดงตามเดิม':'Resolved items will be removed from your list. Open items stay.',
  'ข้อมูลในระบบยังเก็บไว้ตามเดิม แต่ล้างแล้วจะย้อนกลับไม่ได้':'The records stay in the system, but clearing cannot be undone.','ยืนยันล้างประวัติ':'Confirm Clear','ล้างประวัติ':'Clear History','ล้างทั้งหมด':'Clear All'});
(async function boot(){
  document.getElementById('app').innerHTML='<div class="empty">กำลังโหลดข้อมูล...</div>';
  try{await loadAll()}
  catch(e){
    if(e.status===401||e.status===403){setToken(null);setAdminToken(null);try{await loadAll()}catch(e2){}}
    else{document.getElementById('app').innerHTML=`<div class="empty">${ic('alert',20)}<br>เชื่อมต่อเซิร์ฟเวอร์ไม่ได้<br><small>${e.message}</small></div>`;return}
  }
  try{const o=JSON.parse(sessionStorage.getItem(SKEY)||'null');
    if(o&&S.user){S.tab=NAVS[S.role].some(t=>t[0]===o.tab)?o.tab:NAVS[S.role][0][0];S.view=o.view||'card'}
    else if(S.user)S.tab=NAVS[S.role][0][0];
  }catch(e){}
  render();
  setInterval(applyRemote,30000);
  document.addEventListener('visibilitychange',applyRemote);
})();
