/* Profile pages for patient, staff (hospital profile) and admin */
/* ================= PROFILE ================= */
const PF={
 patient:[['name','ชื่อ-นามสกุล'],['phone','เบอร์โทร'],['email','อีเมล (ใช้เข้าสู่ระบบ)',1],['dob','วันเกิด'],['hn','เลขผู้ป่วย (HN)',1],['allergy','แพ้ยา / แพ้อาหาร']],
 tech:[['name','ชื่อ-นามสกุล'],['phone','เบอร์โทร'],['email','อีเมล (ใช้เข้าสู่ระบบ)',1],['hosp','โรงพยาบาล',1],['dpt','หน่วยงาน']],
 admin:[['name','ชื่อ-นามสกุล'],['phone','เบอร์โทร'],['email','อีเมล (ใช้เข้าสู่ระบบ)',1],['co','บริษัท',1]],
};
function profileView(){
  const u=S.user,defs=PF[u.role];const val=k=>k==='hosp'?hn(u.hid):(u[k]||'');
  return `<div class="top"><h1>โปรไฟล์</h1></div>
  <div class="card" style="display:flex;gap:14px;align-items:center">${avatarHtml(u,72)}<div><h3>${u.name}</h3><span class="tag">${ROLES[u.role]}</span>${u.role==='tech'?`<div class="small" style="margin-top:4px">${hn(u.hid)}</div>`:''}${photoBtns(u)}</div></div>
  <div class="card">${S.editProfile?
    defs.map(([k,l,lock])=>`<label>${l}${lock?' · แก้ไขไม่ได้':''}</label><input data-k="${k}" class="pf" value="${val(k)}" ${lock?'readonly':''} ${k==='dob'?'type="date"':''}>`).join('')+`<button class="btn" onclick="saveProfile()">บันทึกการเปลี่ยนแปลง</button><button class="btn sec" onclick="S.editProfile=false;render()">ยกเลิก</button>`:
    defs.map(([k,l])=>`<div class="kv"><span>${l.replace(' (ใช้เข้าสู่ระบบ)','')}</span><span>${val(k)||'—'}</span></div>`).join('')+`<button class="btn" onclick="S.editProfile=true;render()">แก้ไขโปรไฟล์</button>`}</div>
  <div class="card"><div class="sw" style="border:0"><span>รหัสผ่าน</span><button class="btn sec sm" onclick="S.sheet={t:'pw'};render()">เปลี่ยนรหัสผ่าน</button></div></div>
  <div style="padding:0 16px"><button class="btn danger" style="margin-top:0" onclick="logout()">ออกจากระบบ</button></div>`;
}
function techProfile(){
  const u=S.user,h=HOSPS.find(x=>x.id===u.hid)||{n:'-'},staff=ACCTS.filter(a=>a.role==='tech'&&a.hid===u.hid);
  const mine=PF.tech.filter(d=>d[0]!=='hosp'),val=k=>u[k]||'';
  return `<div class="top"><h1>โปรไฟล์โรงพยาบาล</h1></div>
  ${hospHero(h,'tech')}
  <div class="pcols"><div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h3>บัญชีเจ้าหน้าที่ของโรงพยาบาล</h3><button class="btn sm" onclick="S.sheet={t:'mystaff'};render()">+ เพิ่มบัญชี</button></div>
   <p class="small" style="margin-top:4px">ทุกบัญชีเห็นแพทย์ คำขอจอง และรายงานของโรงพยาบาลนี้ร่วมกัน เพิ่มบัญชีได้ แต่การระงับหรือเปิดใช้บัญชีทำได้โดยผู้ดูแลระบบเท่านั้น</p>
   ${staff.map(a=>`<div class="sw"><div><b>${a.name}${a.id===u.id?' (คุณ)':''}</b><div class="small">${a.email}</div></div><span class="tag ${a.on?'ok':'bad'}">${a.on?'ใช้งานอยู่':'ระงับ'}</span></div>`).join('')}</div>
  <div class="card"><h3>บัญชีของฉัน</h3><div style="display:flex;gap:12px;align-items:center;margin:10px 0">${avatarHtml(u,56)}<div><b>${u.name}</b>${photoBtns(u)}</div></div>${S.editProfile?
    mine.map(([k,l,lock])=>`<label>${l}${lock?' · แก้ไขไม่ได้':''}</label><input data-k="${k}" class="pf" value="${val(k)}" ${lock?'readonly':''}>`).join('')+`<button class="btn" onclick="saveProfile()">บันทึก</button><button class="btn sec" onclick="S.editProfile=false;render()">ยกเลิก</button>`:
    mine.map(([k,l])=>`<div class="kv"><span>${l.replace(' (ใช้เข้าสู่ระบบ)','')}</span><span>${val(k)||'—'}</span></div>`).join('')+`<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn sec sm" style="margin-top:14px" onclick="S.editProfile=true;render()">แก้ไขโปรไฟล์</button><button class="btn sec sm" style="margin-top:14px" onclick="S.sheet={t:'pw'};render()">เปลี่ยนรหัสผ่าน</button></div>`}</div></div>
  <div style="padding:0 16px"><button class="btn danger" style="margin-top:0;max-width:320px" onclick="logout()">ออกจากระบบ</button></div>`;
}
function saveHosp(){const h=HOSPS.find(x=>x.id===S.user.hid);document.querySelectorAll('.hf').forEach(i=>{h[i.dataset.k]=i.value.trim()});S.editHosp=false;render();toast('บันทึกข้อมูลโรงพยาบาลแล้ว')}
function togStaff(id){toast('การระงับหรือเปิดใช้บัญชีทำได้โดยผู้ดูแลระบบเท่านั้น')}
function addMyStaff(){
  const n=($('ms_n')||'').trim(),e=($('ms_e')||'').trim(),w=$('ms_w')||'';
  if(!n||!e||!w){toast('กรอกข้อมูลให้ครบ');return}
  if(!/^\S+@\S+\.\S+$/.test(e)){toast('รูปแบบอีเมลไม่ถูกต้อง');return}
  if(w.length<6){toast('รหัสผ่านอย่างน้อย 6 ตัวอักษร');return}
  if(ACCTS.some(a=>a.email.toLowerCase()===e.toLowerCase())){toast('อีเมลนี้ถูกใช้แล้ว');return}
  ACCTS.push({id:Math.max(...ACCTS.map(a=>a.id))+1,role:'tech',name:n,email:e,pw:w,phone:($('ms_p')||'').trim(),hid:S.user.hid,dpt:'',on:true});
  S.sheet=null;render();toast('เพิ่มบัญชีเจ้าหน้าที่แล้ว');
}
function saveProfile(){
  const u=S.user;const vals={};document.querySelectorAll('.pf').forEach(i=>{if(!i.readOnly)vals[i.dataset.k]=i.value.trim()});
  if(!vals.name){toast('กรุณากรอกชื่อ');return}
  Object.assign(u,vals);S.editProfile=false;render();toast('บันทึกแล้ว');
}

